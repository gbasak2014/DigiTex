package com.gb.wf.server.dto;

import java.util.List;

public class UserDetails {
	String status;
	String userName;
	String userId;
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	List<String> roles;
	ProjectDetail[] projects;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public ProjectDetail[] getProjects() {
		return projects;
	}

	public void setProjects(ProjectDetail[] projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "{" + this.userId + ", " + this.userName + ", " + this.roles + ", " + this.projects + "}";
	}
}
