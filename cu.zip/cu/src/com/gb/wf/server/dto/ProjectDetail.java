package com.gb.wf.server.dto;

public class ProjectDetail {
	long id;
	String name;
	String description;

	String clusterUser;
	String clusterPwd;
	String clusterHost;
	String clusterPort;
	String clusterHome;

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "{" + this.id + ", " + this.name + ", " + this.description + "}";
	}

	public String getClusterUser() {
		return clusterUser;
	}

	public void setClusterUser(String clusterUser) {
		this.clusterUser = clusterUser;
	}

	public String getClusterPwd() {
		return clusterPwd;
	}

	public void setClusterPwd(String clusterPwd) {
		this.clusterPwd = clusterPwd;
	}

	public String getClusterHost() {
		return clusterHost;
	}

	public void setClusterHost(String clusterHost) {
		this.clusterHost = clusterHost;
	}

	public String getClusterPort() {
		return clusterPort;
	}

	public void setClusterPort(String clusterPort) {
		this.clusterPort = clusterPort;
	}

	public String getClusterHome() {
		return clusterHome;
	}

	public void setClusterHome(String clusterHome) {
		this.clusterHome = clusterHome;
	}
}
