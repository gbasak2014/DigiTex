package com.gb.wf.server.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class RestClient {

	static HttpURLConnection getConnection(String cnnUrl, String method) throws Exception {
		System.out.println("URL:" + cnnUrl);
		URL url = new URL(cnnUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);
		conn.setRequestMethod(method);
		conn.setRequestProperty("Content-Type", "application/json");

		return conn;
	}

	public static String postRequest(String url, String jsonData) throws Exception {
		HttpURLConnection cnn = getConnection(url, "POST");
		OutputStream os = cnn.getOutputStream();
		os.write(jsonData.getBytes());
		os.flush();

		if (cnn.getResponseCode() != HttpURLConnection.HTTP_OK) {
			throw new RuntimeException("Failed : HTTP error code : " + cnn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((cnn.getInputStream())));

		String output;
		StringBuffer sb = new StringBuffer();
		while ((output = br.readLine()) != null) {
			sb.append(output);
		}

		cnn.disconnect();

		return sb.toString();
	}

	public static String getRequest(String url) throws Exception {
		HttpURLConnection conn = getConnection(url, "GET");
		if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
			throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
		}

		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

		String output;
		StringBuffer sb = new StringBuffer();
		while ((output = br.readLine()) != null) {
			sb.append(output);
		}

		conn.disconnect();
		return sb.toString();
	}
}
