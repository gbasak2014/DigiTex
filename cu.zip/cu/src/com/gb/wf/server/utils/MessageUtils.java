package com.gb.wf.server.utils;

public class MessageUtils {
	public static String getResponseMessage(String status, Object data) {
		
		String sts = "\"status\":\"" + status + "\"";
		String dt = "\"data\":\"" + data + "\"";
		return "{" + sts + "," + dt + "}";
	}
}
