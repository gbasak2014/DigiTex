package com.gb.wf.server.utils;

import java.util.Properties;

public class ServiceConfig {
	static Properties config;
	
	public static void set(Properties conf)
	{
		config = conf;
	}
	
	public static String get(String key)
	{
		return config.getProperty(key);
	}
}
