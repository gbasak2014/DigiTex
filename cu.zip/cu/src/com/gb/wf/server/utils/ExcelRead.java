package com.gb.wf.server.utils;

import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead {
	
	public void getFileSourceFromExcel(String excelPath) throws Exception
	{
		XSSFWorkbook book = new XSSFWorkbook(excelPath);
		XSSFSheet sheetFile = book.getSheetAt(0);
		
		
		int lastRow = sheetFile.getLastRowNum();
	
		
	}
	
	public static void main(String[] args) throws Exception{
		System.out.println("aaa");
		XSSFWorkbook book = new XSSFWorkbook("C:/SparkWF/tst/tst.xlsx");
		
		XSSFSheet s = book.getSheetAt(0);
		System.out.println(s.getFirstRowNum());
		System.out.println(s.getLastRowNum());
		
		System.out.println(s.getRow(4).getCell(1).getStringCellValue());
	}
}
