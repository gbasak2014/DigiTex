package com.gb.wf.server.servlet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.JSONObject;

import com.gb.wf.server.utils.MessageUtils;
import com.gb.wf.server.utils.RestClient;
import com.gb.wf.server.utils.ServiceConfig;

//com.gb.wf.server.servlet.FileUploadServlet
public class FileUploadServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Entered doPost");
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");
		String msg = null;
		try {
			DiskFileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);

			Enumeration<String> e = req.getParameterNames();
			while (e.hasMoreElements()) {
				System.out.println(req.getParameter(e.nextElement()));
			}

			long ssId = 0;
			if (req.getParameter("sourceSystem") != null)
				ssId = Long.parseLong(req.getParameter("sourceSystem"));

			List<FileItem> lst = upload.parseRequest(req);
			String filePath = ServiceConfig.get("service.tmp.path");
			for (FileItem fi : lst) {
				if (!fi.isFormField()) {
					filePath = filePath + "/" + System.currentTimeMillis() + "-" + fi.getName();
					OutputStream io = new FileOutputStream(filePath);
					InputStream in = fi.getInputStream();
					byte[] bff = new byte[10240];
					while (in.read(bff) > 0) {
						io.write(bff);
					}
					io.close();
				} else {
					if ("sourceSystem".equalsIgnoreCase(fi.getFieldName())) {
						System.out.println("fi.getString()>>" + fi.getString());
						ssId = Long.parseLong(fi.getString());
					}
				}
			}

			msg = postToMDM(filePath, ssId);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (msg == null) {
			msg = MessageUtils.getResponseMessage("ERROR", "Error Uploading File!!");
		}

		OutputStream out = resp.getOutputStream();
		out.write(msg.getBytes());
		out.close();
		System.out.println("Exiting doPost");
	}

	String postToMDM(String filePath, long ssId) {
		System.out.println("Entered postToMDM");
		String resp = null;
		try {
			String url = ServiceConfig.get("mdm.service.url") + "/metadata/importfile";
			System.out.println(url);
			JSONObject req = new JSONObject();
			req.put("sourceSystem", ssId);
			req.put("excelPath", filePath);

			resp = RestClient.postRequest(url, req.toString());

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error communicating with MDM!!");
		}
		System.out.println("Exiting postToMDM");
		return resp;
	}

}
