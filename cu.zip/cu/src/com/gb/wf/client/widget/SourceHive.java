package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceHivePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.util.JSONUtil;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceHive extends SDPWidget {
	long metaId = 0;
	String schema;
	String table;
	String condition;

	public SourceHive(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-hive.jpg", "srcHive", ComponentTypes.SOURCE_HIVE, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTableName() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("metaId", new JSONNumber(this.getMetaId()));
		json.put("schema", new JSONString(this.getSchema()));
		json.put("table", new JSONString(this.getTableName()));
		json.put("condition", new JSONString(this.getCondition()));

		return json;
	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}

	public String getTable() {
		return table;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.setSchema(JSONUtil.getEmptyIfNull("schema", json));
		this.setTable(JSONUtil.getEmptyIfNull("table", json));
		this.setCondition(JSONUtil.getEmptyIfNull("condition", json));
	}
	
	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SourceHivePropDlg(this);
	}
}
