package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class TargetHive extends SDPWidget {
	String schema;
	String table;
	boolean overwrite;
	String partition;
	String path;

	public TargetHive(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/trg-hive.jpg", "HDFS File Source", ComponentTypes.TARGET_HIVE, ComponentTypes.DESTINATION, popupMenu, clickHandler);
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTableName() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public boolean isOverwrite() {
		return overwrite;
	}

	public void setOverwrite(boolean overwrite) {
		this.overwrite = overwrite;
	}

	public String getPartition() {
		return partition;
	}

	public void setPartition(String partition) {
		this.partition = partition;
	}

	public String getTable() {
		return table;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("schema", new JSONString(this.getSchema()));
		json.put("table", new JSONString(this.getTable()));
		json.put("partition", new JSONString(this.getPartition()));
		json.put("path", new JSONString(this.getPath()));
		json.put("overwrite", new JSONString(this.isOverwrite() ? "true" : "false"));

		return json;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		// TODO Auto-generated method stub
		return null;
	}

}
