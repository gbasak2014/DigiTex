package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.ParamRow;
import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.StartPropDlg;
import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.handler.TitleChangeListener;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class Start extends SDPWidget {
	String jobName;
	String desc;
	long projectId;
	long jobId;

	TitleChangeListener titleChangeListener;
	List<ParamDto> params = new ArrayList<ParamDto>();

	public Start(SDPPopupMenu popupMenu, ClickHandler clickHandler, TitleChangeListener titleChangeListener, long projectId) {
		super("images/start-wf.jpg", "start", ComponentTypes.START, ComponentTypes.START, popupMenu, clickHandler);
		this.titleChangeListener = titleChangeListener;
		this.projectId = projectId;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.jobName = json.get("jobName") != null ? json.get("jobName").isString().stringValue() : null;
		this.desc = json.get("jobDesc") != null ? json.get("jobDesc").isString().stringValue() : null;
		this.projectId = json.get("projectId") != null ? (int) json.get("projectId").isNumber().doubleValue() : -1;
		this.jobId = json.get("jobId") != null ? (int) json.get("jobId").isNumber().doubleValue() : -1;

		JSONArray prms = json.get("params").isArray();
		if (prms != null) {
			for (int i = 0; i < prms.size(); i++) {
				JSONObject obj = prms.get(i).isObject();

				long id = (long) (obj.get("id") != null ? obj.get("id").isNumber().doubleValue() : -1);
				String param = obj.get("param") != null ? obj.get("param").isString().stringValue() : "";
				String type = obj.get("type") != null ? obj.get("type").isString().stringValue() : "";

				ParamDto p = new ParamDto(id, param, type, 0);
				this.params.add(p);
			}
		}
	}

	public void addParams(List<ParamRow> params) {
		this.params.clear();
		for (ParamRow r : params) {
			this.params.add(new ParamDto(r.getId(), r.getParam(), r.getParamType(), 0));
		}
	}

	public List<ParamDto> getParams() {
		return this.params;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("id", new JSONNumber(this.getId()));
		json.put("jobId", new JSONNumber(this.getJobId()));
		json.put("jobName", new JSONString(this.getJobName()));
		json.put("jobDesc", new JSONString(this.getDesc()));
		json.put("projectId", new JSONNumber(this.getProjectId()));
		json.put("name", new JSONString(this.getName()));
		json.put("componentType", new JSONNumber(this.getType()));
		json.put("successors", this.getSuccessorJSON());
		json.put("absolutePos", new JSONString(this.getAbsoluteLeft() + ":" + this.getAbsoluteTop()));
		json.put("left", new JSONNumber(this.left));
		json.put("top", new JSONNumber(this.top));

		JSONArray prm = new JSONArray();
		for (int i = 0; i < this.params.size(); i++) {
			prm.set(i, this.params.get(i).getJSON());
		}
		json.put("params", prm);

		return json;

	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		this.projectId = projectId;
		return new StartPropDlg(this);
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
		this.titleChangeListener.titleChanged(jobName);
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public long getProjectId() {
		return this.projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	public long getJobId() {
		return jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public void setParams(List<ParamDto> params) {
		this.params = params;
	}
}
