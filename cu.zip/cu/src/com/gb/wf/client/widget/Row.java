package com.gb.wf.client.widget;

import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.RowPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class Row extends SDPWidget {

	List<String> dataTypes;

	public Row(SDPPopupMenu popupMenu, ClickHandler clickHandler, List<String> dataTypes) {
		super("images/row.jpg", "Row", ComponentTypes.ROW, ComponentTypes.ROW, popupMenu, clickHandler);
		this.dataTypes = dataTypes;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();

		return json;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	public List<String> getDataTypes() {
		return this.dataTypes;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long id) {
		return new RowPropDlg(this);
	}

}