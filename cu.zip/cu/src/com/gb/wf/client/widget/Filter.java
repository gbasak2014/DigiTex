package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.FilterPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class Filter extends SDPWidget {

	String conditions;

	public Filter(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/filter-wf.jpg", "Filter", ComponentTypes.FILTER, ComponentTypes.FILTER, popupMenu, clickHandler);
		this.setStyleName("btnFilter");
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.conditions = json.get("conditions") != null ? json.get("conditions").isString().stringValue() : null;
	}
	
	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("conditions", new JSONString(this.getConditions()));

		return json;
	}

	public String getConditions() {
		return conditions;
	}

	public void setConditions(String conditions) {
		this.conditions = conditions;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long id) {
		 SDPWidget p = this.getPredecessors().get(0);
		 while(!"start".equalsIgnoreCase(p.getName()))
		 {
			 p = p.getPredecessors().get(0);
		 }
		 
		 if (!"start".equalsIgnoreCase(p.getName()))
		 {
			 Window.alert("Please add start node...");
			 return null;
		 }

		 Start s = (Start)p;
		 return new FilterPropDlg(this, s.getParams());
	}
}