package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceKafkaPropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceKafka extends SDPWidget {
	long metaId;
	String brokers="";
	String topics="";
	int interval=1;
	String recordType="";
	String delimiter="";

	public SourceKafka(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-kafka.jpg", "Kafka Streaming source", ComponentTypes.SOURCE_KAFKA, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	public String getBrokers() {
		return brokers;
	}

	public void setBrokers(String brokers) {
		this.brokers = brokers;
	}

	public String getTopics() {
		return topics;
	}

	public void setTopics(String topics) {
		this.topics = topics;
	}

	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("metaId", new JSONNumber(this.getMetaId()));
		json.put("brokers", new JSONString(this.getBrokers()));
		json.put("topics", new JSONString(this.getTopics()));
		json.put("interval", new JSONNumber(this.getInterval()));
		json.put("recordType", new JSONString(this.getRecordType()));
		json.put("delimiter", new JSONString(this.getDelimiter()));

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SourceKafkaPropDlg(this);
	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}
}
