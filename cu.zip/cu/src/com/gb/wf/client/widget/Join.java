package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.JoinPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dto.JoinDto;
import com.gb.wf.client.dto.TransformationDto;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Joining multiple RDD
 * 
 * @author Gouranga Basak
 *
 */
public class Join extends SDPWidget {

	List<JoinDto> links = new ArrayList<JoinDto>();
	List<TransformationDto> transformations = new ArrayList<TransformationDto>();

	public Join(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/join-wf.jpg", "Join Sources", ComponentTypes.JOIN, ComponentTypes.JOIN, popupMenu, clickHandler);
	}

	public void linkSchema(JoinDto dto) {
		this.links.add(dto);
	}

	public List<JoinDto> getLinks() {
		return this.links;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		JSONArray arr = json.get("transformations") != null ? json.get("transformations").isArray() : null;
		if (arr != null)
		{
			for (int i=0; i<arr.size(); i++)
			{
				JSONObject obj = arr.get(i).isObject();
				int idx = obj.get("index") != null ? (int)obj.get("index").isNumber().doubleValue() : -1;
				String trns = obj.get("transform") != null ? obj.get("transform").isString().stringValue() : null;
				String tf = obj.get("targetField") != null ? obj.get("targetField").isString().stringValue() : null;
				this.transformations.add(new TransformationDto(idx, trns, tf));
			}
		}
		
		JSONArray arrLnk = json.get("join") != null ? json.get("join").isArray() : null;
		if (arrLnk != null)
		{
			for (int i=0; i< arrLnk.size(); i++)
			{
				JSONObject obj = arrLnk.get(i).isObject();
				String leftSchema = obj.get("leftSchema") != null ? obj.get("leftSchema").isString().stringValue() : null;
				String rightSchema = obj.get("rightSchema") != null ? obj.get("rightSchema").isString().stringValue() : null;
				String leftColumn = obj.get("leftColumn") != null ? obj.get("leftColumn").isString().stringValue() : null;
				String rightColumn = obj.get("rightColumn") != null ? obj.get("rightColumn").isString().stringValue() : null;
				String joinType = obj.get("joinType") != null ? obj.get("joinType").isString().stringValue() : null;
				String joinCondition = obj.get("joinCondition") != null ? obj.get("joinCondition").isString().stringValue() : null;
				this.links.add(new JoinDto(leftSchema, rightSchema, joinType, leftColumn, rightColumn, joinCondition));
			}
		}
	}
	
	
	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		JSONArray arr = new JSONArray();
		int idx = 0;
		for (TransformationDto dto : transformations) {
			JSONObject obj = new JSONObject();
			obj.put("index", new JSONNumber(dto.getIndex()));
			obj.put("transform", new JSONString(dto.getFunction()));
			obj.put("targetField", new JSONString(dto.getFieldName()));
			arr.set(idx, obj);
			idx++;
		}

		json.put("transformations", arr);

		JSONArray arrJoin = new JSONArray();
		idx = 0;
		for (JoinDto joinDto : links) {
			JSONObject obj = new JSONObject();
			obj.put("leftSchema", new JSONString(joinDto.getLeftSchema()));
			obj.put("rightSchema", new JSONString(joinDto.getRightSchema()));
			obj.put("leftColumn", new JSONString(joinDto.getLeftColumn()));
			obj.put("rightColumn", new JSONString(joinDto.getRightColumn()));
			obj.put("joinType", new JSONString(joinDto.getJoinType()));
			obj.put("joinCondition", new JSONString(joinDto.getJoinCondition()));
			arrJoin.set(idx, obj);
			idx++;
		}
		json.put("join", arrJoin);

		return json;
	}

	public List<TransformationDto> getTransformations() {
		return transformations;
	}

	public void setTransformations(List<TransformationDto> transformations) {
		this.transformations = transformations;
	}

	public void setLinks(List<JoinDto> links) {
		this.links = links;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new JoinPropDlg(this);
	}
}
