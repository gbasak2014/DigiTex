package com.gb.wf.client.widget;

import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.PrimeTypePropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class PrimeType extends SDPWidget {

	List<String> dataTypes;
	String dataType;
	String parentColumn;

	public PrimeType(SDPPopupMenu popupMenu, ClickHandler clickHandler, List<String> dataTypes) {
		super("images/prime_type.jpg", "PrimeType", ComponentTypes.PRIME_TYPE, ComponentTypes.PRIME_TYPE, popupMenu, clickHandler);
		this.dataTypes = dataTypes;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.dataType = json.get("dataType") != null ? json.get("dataType").isString().stringValue() : "String";
		this.parentColumn = json.get("parentColumn") != null ? json.get("parentColumn").isString().stringValue() : "";
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("dataType", new JSONString(this.dataType));
		json.put("parentColumn", new JSONString(this.parentColumn));

		return json;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long id) {
		return new PrimeTypePropDlg(this);
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public List<String> getDataTypeList() {
		return dataTypes;
	}

	@Override
	public List<ColumnDto> getFields() {
		return null;
	}

	public String getParentColumn() {
		return parentColumn;
	}

	public void setParentColumn(String parentColumn) {
		this.parentColumn = parentColumn;
	}
}