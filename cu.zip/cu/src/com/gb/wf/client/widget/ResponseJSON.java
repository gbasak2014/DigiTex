package com.gb.wf.client.widget;

import java.util.HashMap;
import java.util.Map;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.ResponsePropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent SORT Dataset
 * 
 * @author Gouranga Basak
 *
 */
public class ResponseJSON extends SDPWidget {
	String targetUrl;
	String targetTable;
	String targetKeyColumn;
	String targetValColumn;
	String targetKey;
	String targetUser;
	String targetPwd;
	
	String responseRoot;
	Map<String, String> dfResponseMap = new HashMap<String, String>();

	public ResponseJSON(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/response-json.jpg", "Response Generator", ComponentTypes.RESPONSE_JSON, ComponentTypes.RESPONSE_JSON, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);

		this.targetUrl = json.get("targetUrl") != null ? json.get("targetUrl").isString().stringValue() : null;
		this.targetTable = json.get("targetTable") != null ? json.get("targetTable").isString().stringValue() : null;
		this.targetKeyColumn = json.get("targetKeyColumn") != null ? json.get("targetKeyColumn").isString().stringValue() : null;
		this.targetValColumn = json.get("targetValColumn") != null ? json.get("targetValColumn").isString().stringValue() : null;
		this.targetKey = json.get("targetKey") != null ? json.get("targetKey").isString().stringValue() : null;
		this.responseRoot = json.get("responseRoot") != null ? json.get("responseRoot").isString().stringValue() : null;
		this.targetUser = json.get("targetUser") != null ? json.get("targetUser").isString().stringValue() : null;
		this.targetPwd = json.get("targetPwd") != null ? json.get("targetPwd").isString().stringValue() : null;
		
		JSONArray arr = json.get("responseMap").isArray();
		int len = arr.size();
		this.dfResponseMap.clear();
		for (int i = 0; i < len; i++) {
			JSONObject obj = arr.get(i).isObject();
			String k = obj.keySet().iterator().next();
			String v = obj.get(k).isString().stringValue();
			this.dfResponseMap.put(k, v);
		}
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		
		json.put("targetUrl", new JSONString(this.targetUrl));
		json.put("targetTable", new JSONString(this.targetTable));
		json.put("targetKeyColumn", new JSONString(this.targetKeyColumn));
		json.put("targetValColumn", new JSONString(this.targetValColumn));
		json.put("targetKey", new JSONString(this.targetKey));
		json.put("responseRoot", new JSONString(this.responseRoot));
		json.put("targetUser", new JSONString(this.targetUser));
		json.put("targetPwd", new JSONString(this.targetPwd));
		
		int idx = 0;
		JSONArray arr = new JSONArray();
		for (String k : dfResponseMap.keySet()) {
			JSONObject obj = new JSONObject();
			obj.put(k, new JSONString(this.dfResponseMap.get(k)));
			arr.set(idx, obj);
			idx++;
		}

		json.put("responseMap", arr);

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	public Map<String, String> getDfResponseMap() {
		return dfResponseMap;
	}

	public void setDfResponseMap(Map<String, String> dfResponseMap) {
		this.dfResponseMap = dfResponseMap;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getTargetTable() {
		return targetTable;
	}

	public void setTargetTable(String targetTable) {
		this.targetTable = targetTable;
	}

	public String getTargetKeyColumn() {
		return targetKeyColumn;
	}

	public void setTargetKeyColumn(String targetKeyColumn) {
		this.targetKeyColumn = targetKeyColumn;
	}

	public String getTargetValColumn() {
		return targetValColumn;
	}

	public void setTargetValColumn(String targetValColumn) {
		this.targetValColumn = targetValColumn;
	}

	public String getTargetKey() {
		return targetKey;
	}

	public void setTargetKey(String targetKey) {
		this.targetKey = targetKey;
	}

	public String getResponseRoot() {
		return responseRoot;
	}

	public void setResponseRoot(String responseRoot) {
		this.responseRoot = responseRoot;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new ResponsePropDlg(this);
	}

	public String getTargetUser() {
		return targetUser;
	}

	public void setTargetUser(String targetUser) {
		this.targetUser = targetUser;
	}

	public String getTargetPwd() {
		return targetPwd;
	}

	public void setTargetPwd(String targetPwd) {
		this.targetPwd = targetPwd;
	}
}
