package com.gb.wf.client.widget;

import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

public class TransformationHeader extends FlowPanel {
	VerticalPanel parent;

	public TransformationHeader() {
		super();
		Label lbl = new Label("Index");
		lbl.getElement().getStyle().setWidth(40, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.add(lbl);

		lbl = new Label("Function");
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.add(lbl);

		lbl = new Label("Arguments");
		lbl.getElement().getStyle().setWidth(320, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.add(lbl);

		lbl = new Label("Sel Arg");
		lbl.getElement().getStyle().setWidth(100, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.add(lbl);
		
		lbl = new Label("Column Name");
		lbl.getElement().getStyle().setWidth(100, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.add(lbl);
		
		lbl = new Label("Action");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.add(lbl);
		
		this.getElement().getStyle().setWidth(800, Unit.PX);
		this.getElement().getStyle().setBorderColor("#000");
		this.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		this.getElement().getStyle().setBorderWidth(1, Unit.PX);

	}
}
