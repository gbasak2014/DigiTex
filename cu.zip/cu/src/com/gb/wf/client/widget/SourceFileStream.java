package com.gb.wf.client.widget;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceFilePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceFileStream extends SDPWidget {
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);
	long metaId;
	String path;
	String delimiter;
	String recordType;
	int interval;
	long projectId;
	public SourceFileStream(SDPPopupMenu popupMenu, ClickHandler clickHandler, long projectId) {
		super("images/src-file-stream.jpg", "Local File Source", ComponentTypes.SOURCE_FILE_STREAM, ComponentTypes.SOURCE, popupMenu, clickHandler);
		this.projectId = projectId;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();

		json.put("path", new JSONString(this.getPath()));
		json.put("recordType", new JSONString(this.getRecordType()));
		json.put("delimiter", new JSONString(this.getDelimiter()));
		json.put("interval", new JSONNumber(this.getInterval()));

		return json;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		try{
		return new SourceFilePropDlg(this, this.projectId);
		}catch(Exception e)
		{
			Window.alert("ERROR:" + e.getMessage());
		}
		return null;
	}

	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}

	public long getProjectId() {
		return projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}
}
