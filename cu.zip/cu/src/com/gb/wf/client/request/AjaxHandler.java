package com.gb.wf.client.request;

/**
 * Handler to process AJAX request, processResponse method will be invoked with
 * response message when server send response to the client.
 * 
 * @author Gouranga Basak
 *
 */
public interface AjaxHandler {
	/**
	 * Method is invoked when server send response to client.
	 * 
	 * @param response
	 */
	void processResponse(AjaxResponse response);
}
