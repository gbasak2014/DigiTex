package com.gb.wf.client.request;

import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.Response;
import com.google.gwt.http.client.URL;

/**
 * Making AJAX Post request to REST service with JSON data and process response.
 * 
 * @author Gouranga Basak
 *
 */
public class AjaxPostRequest {
	public AjaxPostRequest(String data, String url, final AjaxHandler handler) {

		RequestBuilder rb = new RequestBuilder(RequestBuilder.POST, URL.encode(url));
		rb.setHeader("Content-Type", "application/json");

		try {

			rb.sendRequest(data, new RequestCallback() {

				@Override
				public void onResponseReceived(Request request, Response resp) {
					handler.processResponse(new AjaxResponse(AjaxResponse.SUCCESS, resp.getText()));
				}

				@Override
				public void onError(Request request, Throwable exception) {
					handler.processResponse(new AjaxResponse(AjaxResponse.SUCCESS, "ERROR from server"));
				}
			});
		} catch (Exception e) {
			handler.processResponse(new AjaxResponse(AjaxResponse.SUCCESS, "ERROR processing request"));
		}
	}
}
