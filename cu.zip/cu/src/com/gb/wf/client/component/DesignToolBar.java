package com.gb.wf.client.component;

import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

@Deprecated
public class DesignToolBar extends FlowPanel {

	public DesignToolBar(ClickHandler handler) {
		VerticalPanel vp = new VerticalPanel();

		HorizontalPanel hp = new HorizontalPanel();
		hp.add(new ImageButton("images/start-wf.jpg", ComponentTypes.START, "Start of workflow", handler, 20, 20));
		hp.add(new ImageButton("images/end-wf.jpg", ComponentTypes.END, "End of workflow", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/src-local.jpg", ComponentTypes.SOURCE_LOCAL, "Local source files", handler, 20, 20));
		hp.add(new ImageButton("images/src-hdfs.jpg", ComponentTypes.SOURCE_HDFS, "HDFS source files", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/src-hive.jpg", ComponentTypes.SOURCE_HIVE, "Hive source", handler, 20, 20));
		hp.add(new ImageButton("images/src-rdbms.jpg", ComponentTypes.SOURCE_RDBMS, "RDBMS source", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/src-hbase.jpg", ComponentTypes.SOURCE_HBASE, "HBase source", handler, 20, 20));
		hp.add(new ImageButton("images/src-cassandra.jpg", ComponentTypes.SOURCE_CASSANDRA, "Cassandra source", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/src-kafka.jpg", ComponentTypes.SOURCE_KAFKA, "Kafka source - Streaming", handler, 20, 20));
		hp.add(new ImageButton("images/src-flume.jpg", ComponentTypes.SOURCE_FLUME, "Flume source - Streaming", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/src-file-stream.jpg", ComponentTypes.SOURCE_FILE_STREAM, "File source - Streaming", handler, 20, 20));
		hp.add(new ImageButton("images/src-tcp.jpg", ComponentTypes.SOURCE_TCP, "TCP source - Streaming", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/transform-wf.jpg", ComponentTypes.TRANSFORMATION, "Transformation source", handler, 20, 20));
		hp.add(new ImageButton("images/filter-wf.jpg", ComponentTypes.FILTER, "Filter source", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/join-wf.jpg", ComponentTypes.JOIN, "Join sources", handler, 20, 20));
		hp.add(new ImageButton("images/group-wf.jpg", ComponentTypes.GROUP, "Group source", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/split-wf.jpg", ComponentTypes.SPLIT, "Split sources", handler, 20, 20));
		hp.add(new ImageButton("images/sort-wf.jpg", ComponentTypes.SORT, "Sort Data", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/trg-hive.jpg", ComponentTypes.TARGET_HIVE, "Save to hive", handler, 20, 20));
		hp.add(new ImageButton("images/trg-hbase.jpg", ComponentTypes.TARGET_HBASE, "Save to HBase", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/trg-cassandra.jpg", ComponentTypes.TARGET_CASSANDRA, "Save to Cassandra", handler, 20, 20));
		hp.add(new ImageButton("images/trg-hdfs.jpg", ComponentTypes.TARGET_HDFS, "Save to HDFS", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/trg-json.jpg", ComponentTypes.TARGET_JSON, "Target JSON Converter", handler, 20, 20));
		hp.add(new ImageButton("images/trg-xml.jpg", ComponentTypes.TARGET_XML, "Target XML Converter", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/trg-csv.jpg", ComponentTypes.TARGET_DELIM, "Target Delimited Converter", handler, 20, 20));
		hp.add(new ImageButton("images/response-json.jpg", ComponentTypes.RESPONSE_JSON, "Generate Response JSON and Save", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/custom-action.jpg", ComponentTypes.CUSTOM_ACTION, "Custom Java/Scala code", handler, 20, 20));
		hp.add(new ImageButton("images/sqoop.jpg", ComponentTypes.SQOOP, "Sqoop Import", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/copy.jpg", ComponentTypes.HDFS_COPY, "Copy files to target in HDFS", handler, 20, 20));
		hp.add(new ImageButton("images/dedup.jpg", ComponentTypes.DEDUP, "Dedup Records", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/branch.jpg", ComponentTypes.BRANCH, "Branching", handler, 20, 20));
		hp.add(new ImageButton("images/value.jpg", ComponentTypes.VALUE, "Function Value", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/function.jpg", ComponentTypes.FUNCTION, "Function Evaluate", handler, 20, 20));
		hp.add(new ImageButton("images/common-service.jpg", ComponentTypes.CUSTOM_SERVICES, "Custom Services", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/subwf.jpg", ComponentTypes.SUB_WF, "Sub Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/dataframe.jpg", ComponentTypes.DATAFRAME, "Dataframe", handler, 20, 20));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new ImageButton("images/row.jpg", ComponentTypes.ROW, "Spark Sql Row", handler, 20, 20));
		hp.add(new ImageButton("images/prime_type.jpg", ComponentTypes.PRIME_TYPE, "Prime Data Type (String, Long, Double)", handler, 20, 20));
		vp.add(hp);
		
		this.add(vp);
		this.setStyleName("designtoolbar");
	}
}
