package com.gb.wf.client.component;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.VerticalPanel;

public class DFAboutDialogBox extends DialogBox {
	public DFAboutDialogBox() {
		VerticalPanel dialogContents = new VerticalPanel();
		this.ensureDebugId("cwDialogBox");
		this.setText("Shristi - The Creator");
		this.setSize("600px", "500px");
		dialogContents.setSize("600px", "500px");
		dialogContents.setSpacing(4);
		this.setWidget(dialogContents);
		this.getElement().getStyle().setBackgroundColor("#204060");
		dialogContents.getElement().getStyle().setBackgroundColor("#204060");
		// Add some text to the top of the dialog
		String msg = "<body bgcolor=\"#204060\"><font color=\"#0070C0\">"
				   + "<h1 align=\"right\">Shristi - The Creator</h1>"
				   + "<h2 align=\"right\">Automation Tool to Create Data Ingestion and Processing Job</h2>"
				   + "<h2 align=\"right\">Designed and Developed by: Gouranga Basak</h2>"
				   + "<h2 align=\"right\">goubasak@in.ibm.com</h2>"
				   + "</font></body>";
		HTML html = new HTML(msg);
		dialogContents.add(html);

		Button closeButton = new Button("Close", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		dialogContents.add(closeButton);
		if (LocaleInfo.getCurrentLocale().isRTL()) {
			dialogContents.setCellHorizontalAlignment(closeButton, HasHorizontalAlignment.ALIGN_LEFT);

		} else {
			dialogContents.setCellHorizontalAlignment(closeButton, HasHorizontalAlignment.ALIGN_RIGHT);
		}
	}
}
