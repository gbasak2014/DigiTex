package com.gb.wf.client.component;

import com.gb.wf.client.dlg.IfElseDlg;
import com.gb.wf.client.handler.TransRowSelectionHandler;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.TextBox;

public class TransformationRow extends FlowPanel {
	TextBox txtSlNo = new TextBox();
	TextBox txtTransformation = new TextBox();
	TextBox txtFieldName = new TextBox();
	TransRowSelectionHandler handler;
	String bgColor;

	String function;
	String ColumnType;
		
	public TransformationRow(TransRowSelectionHandler handler, boolean isFunction) {
		this.handler = handler;

		this.txtSlNo.getElement().getStyle().setWidth(30, Unit.PX);
		this.txtSlNo.getElement().getStyle().setHeight(20, Unit.PX);
		this.txtTransformation.getElement().getStyle().setWidth(300, Unit.PX);
		this.txtTransformation.getElement().getStyle().setHeight(20, Unit.PX);
		this.txtFieldName.getElement().getStyle().setWidth(100, Unit.PX);
		this.txtFieldName.getElement().getStyle().setHeight(20, Unit.PX);

		this.txtSlNo.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTransformation.getElement().getStyle().setFloat(Float.LEFT);
		this.txtFieldName.getElement().getStyle().setFloat(Float.LEFT);

		this.add(this.txtSlNo);
		this.add(this.txtTransformation);
		this.add(this.txtFieldName);

		this.txtFieldName.addMouseDownHandler(new MouseDownHandler() {
			@Override
			public void onMouseDown(MouseDownEvent event) {
				fireEvent();
			}
		});
		this.txtSlNo.addMouseDownHandler(new MouseDownHandler() {
			@Override
			public void onMouseDown(MouseDownEvent event) {
				fireEvent();
			}
		});

		this.txtTransformation.addMouseDownHandler(new MouseDownHandler() {
			@Override
			public void onMouseDown(MouseDownEvent event) {
				fireEvent();
			}
		});

		if (isFunction) {
			this.txtTransformation.setEnabled(false);
			Button btn = new Button("...");
			btn.getElement().getStyle().setFloat(Float.LEFT);
			this.add(btn);
			btn.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent arg0) {
					addFunction();
				}
			});
		}

		this.bgColor = this.txtSlNo.getElement().getStyle().getBackgroundColor();
	}

	void fireEvent() {
		this.handler.rowSelected(this);
	}

	public void setSlNo(int slno) {
		this.txtSlNo.setText(String.valueOf(slno));
	}

	public void setFieldName(String fieldName) {
		this.txtFieldName.setText(fieldName);
	}

	public void setTransformation(String transformation) {
		this.txtTransformation.setText(transformation);
	}

	public int getSlNo() {
		return Integer.parseInt(this.txtSlNo.getText());
	}

	public String getTransformation() {
		return this.txtTransformation.getText();
	}

	public String getFieldName() {
		return this.txtFieldName.getText();
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("slNo", new JSONString(this.txtSlNo.getText()));
		String txt = this.txtTransformation.getText();
		if (txt.startsWith("If-Else-If")) {
			txt = txt + "#" + this.function;
		}
		json.put("transformation", new JSONString(txt));

		json.put("fieldName", new JSONString(this.txtFieldName.getText()));

		return json;
	}

	public String getJSONString() {
		return getJSON().toString();
	}

	public void selectRow() {
		this.txtFieldName.getElement().getStyle().setBackgroundColor("#ffff00");
		this.txtSlNo.getElement().getStyle().setBackgroundColor("#ffff00");
		this.txtTransformation.getElement().getStyle().setBackgroundColor("#ffff00");
	}

	public void deselectRow() {
		this.txtFieldName.getElement().getStyle().setBackgroundColor(bgColor);
		this.txtSlNo.getElement().getStyle().setBackgroundColor(bgColor);
		this.txtTransformation.getElement().getStyle().setBackgroundColor(bgColor);
	}

	void addFunction() {
		IfElseDlg dialogBox = new IfElseDlg(this);
		dialogBox.setModal(false);
		dialogBox.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dialogBox.setGlassEnabled(true);
		dialogBox.setAnimationEnabled(true);
		dialogBox.center();
		dialogBox.show();
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getColumnType() {
		return ColumnType;
	}

	public void setColumnType(String columnType) {
		ColumnType = columnType;
	}
}
