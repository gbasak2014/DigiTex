package com.gb.wf.client.component;

import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;

public class SPDFToolBar extends FlowPanel {

	public SPDFToolBar(ClickHandler handler) {

		this.setStyleName("toolbar");
		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(1, Unit.PX);
		hp.add(new Image("images/space.jpg"));

		SDFMenu menu = new SDFMenu(" File ");
		menu.addMenuItem("New Workflow", DFConstants.WF_NEW, handler);
		menu.addMenuItem("New Sub Workflow", DFConstants.SWF_NEW, handler);
		menu.addMenuItem("Open Workflow", DFConstants.WF_OPEN, handler);
		menu.addMenuItem("Open Sub Workflow", DFConstants.SWF_OPEN, handler);
		menu.addMenuItem("Open Project", DFConstants.SELECT_PROJECT, handler);
		menu.addMenuItem("Save Workflow", DFConstants.WF_SAVE, handler);
		menu.addMenuItem("Save Sub Workflow", DFConstants.SWF_SAVE, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" Service ");
		menu.addMenuItem("Create Common Service", DFConstants.ADD_COMMON_SERVICES, handler);
		menu.addMenuItem("Open Common Service", DFConstants.OPEN_COMMON_SERVICES, handler);
		menu.addMenuItem("Create UDF", DFConstants.ADD_UDF, handler);
		menu.addMenuItem("Open UDF", DFConstants.OPEN_UDF, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" Workflow ");
		menu.addMenuItem("Compile and Generate Workflow", DFConstants.WF_COMPILE, handler);
		menu.addMenuItem("Execute Workflow in Cluster", DFConstants.WF_RUN, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" View ");
		menu.addMenuItem("Show Design Tools", DFConstants.SHOW_DESIN_TOOL, handler);
		menu.addMenuItem("Show / Hide Grid", DFConstants.WF_GRID, handler);
		menu.addMenuItem("Resize", DFConstants.WF_RESIZE, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" Administrator ");
		menu.addMenuItem("Create User", DFConstants.ADD_USER, handler);
		menu.addMenuItem("Create Project", DFConstants.ADD_PROJECT, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" Meta Data ");
		menu.addMenuItem("Create Meta Data", DFConstants.ADD_META, handler);
		menu.addMenuItem("View Meta Data", DFConstants.VIEW_SOURCE, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" Navigate ");
		menu.addMenuItem("Next", DFConstants.NEXT, handler);
		menu.addMenuItem("Previous", DFConstants.PREVIOUS, handler);
		hp.add(menu);
		
		menu = new SDFMenu(" Help ");
		menu.addMenuItem("Help", DFConstants.HELP, handler);
		menu.addMenuItem("Abour", DFConstants.ABOUT, handler);
		hp.add(menu);
		
		hp.add(new ImageButton("images/btn-resize.jpg", DFConstants.WF_RESIZE, "Resize Design", handler, 20, 20));
		hp.add(new ImageButton("images/btn-grid.jpg", DFConstants.WF_GRID, "Show / Hide Grid", handler, 20, 20));
		hp.add(new ImageButton("images/select-prg.jpg", DFConstants.SELECT_PROJECT, "Select Project", handler, 20, 20));
		hp.add(new ImageButton("images/compile-wf.jpg", DFConstants.WF_COMPILE, "Compile Workflow to generate code", handler, 20, 20));
		hp.add(new ImageButton("images/run-wf.jpg", DFConstants.WF_RUN, "Execute Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/prev.jpg", DFConstants.PREVIOUS, "Previous Job/Process", handler, 20, 20));
		hp.add(new ImageButton("images/next.jpg", DFConstants.NEXT, "Next Job/Process", handler, 20, 20));
		hp.add(new ImageButton("images/view.jpg", DFConstants.SHOW_DESIN_TOOL, "Show / Hide Drawing Toolss", handler, 20, 20));

		this.add(hp);
	}

}
