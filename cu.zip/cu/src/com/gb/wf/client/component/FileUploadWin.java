package com.gb.wf.client.component;

import com.gb.wf.client.handler.MdmReqHandler;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.FormPanel;
import com.google.gwt.user.client.ui.FormPanel.SubmitCompleteEvent;
import com.google.gwt.user.client.ui.Hidden;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class FileUploadWin extends PopupPanel {
	FormPanel form = new FormPanel();
	MdmReqHandler handler;
	ProgressBar pb = new ProgressBar();

	public FileUploadWin(MdmReqHandler handler, long ssId) {
		this.handler = handler;

		VerticalPanel vp = new VerticalPanel();

		try {
			form.setAction(GWT.getHostPageBaseURL() + "fileUpload");
			form.setEncoding(FormPanel.ENCODING_MULTIPART);
			form.setMethod(FormPanel.METHOD_POST);
			form.addSubmitCompleteHandler(new FormPanel.SubmitCompleteHandler() {
				@Override
				public void onSubmitComplete(SubmitCompleteEvent sce) {
					submitComplete(sce.getResults());
				}
			});

			form.add(vp);

			FileUpload upload = new FileUpload();
			upload.getElement().getStyle().setColor("WHITE");
			upload.setName("file");
			Hidden hSsId = new Hidden();
			hSsId.setName("sourceSystem");
			hSsId.setValue(String.valueOf(ssId));

			vp.add(new Label("Upload File"));
			vp.add(upload);
			vp.add(hSsId);

			FlowPanel fp = new FlowPanel();

			Button btn = new Button("Close", new ClickHandler() {
				@Override
				public void onClick(ClickEvent arg0) {
					closeMe();
				}
			});
			btn.getElement().getStyle().setFloat(Float.RIGHT);
			fp.add(btn);

			btn = new Button("Upload", new ClickHandler() {
				@Override
				public void onClick(ClickEvent arg0) {
					submitForm();
				}
			});
			btn.getElement().getStyle().setFloat(Float.RIGHT);
			fp.add(btn);

			vp.add(fp);

			this.getElement().getStyle().setBorderColor("WHITE");
			this.getElement().getStyle().setBorderWidth(2.0, Unit.PX);
		} catch (Exception e) {
			Window.alert(e.getMessage());
		}

		this.add(form);
		this.setWidth("400px");
		this.setHeight("200px");
		this.getElement().getStyle().setBorderColor("#ffffff");
		this.getElement().getStyle().setBorderWidth(2, Unit.PX);
		this.getElement().getStyle().setBackgroundColor("#1F3D47");
		this.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);
	}

	void submitComplete(String data) {
		this.handler.processFileMeta(data);
		this.hide();
		pb.stopProgress();
	}

	void submitForm() {
		pb.setText("Please wait, Uploading file...");
		pb.startProgress();
		this.form.submit();
	}

	void closeMe() {
		this.hide();
	}

	public void showMe() {
		this.center();
		this.show();
	}
}
