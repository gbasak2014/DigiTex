package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.dto.UserDto;
import com.gb.wf.client.handler.PopUpHandler;
import com.gb.wf.client.handler.WFActionClickHandler;
import com.gb.wf.client.handler.WFActionHandler;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.util.JSONUtil;
import com.gb.wf.client.widget.Branch;
import com.gb.wf.client.widget.CommonService;
import com.gb.wf.client.widget.CustomAction;
import com.gb.wf.client.widget.DataFrame;
import com.gb.wf.client.widget.Dedup;
import com.gb.wf.client.widget.End;
import com.gb.wf.client.widget.Filter;
import com.gb.wf.client.widget.Function;
import com.gb.wf.client.widget.FunctionValue;
import com.gb.wf.client.widget.Group;
import com.gb.wf.client.widget.HDFSCopy;
import com.gb.wf.client.widget.ImageButton;
import com.gb.wf.client.widget.Join;
import com.gb.wf.client.widget.PrimeType;
import com.gb.wf.client.widget.ResponseJSON;
import com.gb.wf.client.widget.Row;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Sort;
import com.gb.wf.client.widget.SourceCassandra;
import com.gb.wf.client.widget.SourceFileStream;
import com.gb.wf.client.widget.SourceFlume;
import com.gb.wf.client.widget.SourceHBase;
import com.gb.wf.client.widget.SourceHDFS;
import com.gb.wf.client.widget.SourceHive;
import com.gb.wf.client.widget.SourceKafka;
import com.gb.wf.client.widget.SourceLocal;
import com.gb.wf.client.widget.SourceRDBMS;
import com.gb.wf.client.widget.SourceTcp;
import com.gb.wf.client.widget.Sqoop;
import com.gb.wf.client.widget.Start;
import com.gb.wf.client.widget.SubWf;
import com.gb.wf.client.widget.TargetDelim;
import com.gb.wf.client.widget.TargetJSON;
import com.gb.wf.client.widget.TargetXML;
import com.gb.wf.client.widget.Transformation;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.ScrollPanel;

public class WFDesignerPage extends DockLayoutPanel implements ClickHandler, PopUpHandler {
	public static final int TYPE_WF = 1;
	public static final int TYPE_SUB_WF = 2;

	SDPTitleBar titleBar;
	SPDFToolBar toolBar;
	//DesignToolBar designToolBar;
	DrawingToolWin toolWin;

	DrawingController drawingController;

	SDPPopupMenu popupMenu;

	WFActionClickHandler wfActionClickHandler;

	SDPWidget selectedWidget;

	String username;
	UserDto user;

	Start startNode;

	ProgressBar progressBar = new ProgressBar();

	WFActionHandler wfActionHandler;

	List<String> sourceType = new ArrayList<String>();
	List<String> recordType = new ArrayList<String>();
	List<String> dataType = new ArrayList<String>();

	long jobId;
	String jobName;
	String jobType;

	long prevId;

	long selectedPId;

	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	int wfType;

	public WFDesignerPage(UserDto user) {
		super(Unit.PX);
		this.user = user;
		this.username = user.getUserName();
		initModule();
		initMetaData();
	}

	public void initModule() {
		this.wfActionHandler = new WFActionHandler(this);
		ScrollPanel scrollPanel = initDrawingPane();

		this.titleBar = new SDPTitleBar(this.username);
		this.toolBar = new SPDFToolBar(this.wfActionHandler);
		//this.designToolBar = new DesignToolBar(this);
		{
			this.toolWin = new DrawingToolWin(this);
			toolWin.setModal(false);
			toolWin.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			toolWin.setGlassEnabled(true);
			toolWin.setAnimationEnabled(true);
			toolWin.center();
		}
		this.popupMenu = new SDPPopupMenu(this);
		this.wfActionClickHandler = new WFActionClickHandler(this);

		int h = Window.getClientHeight();
		this.setSize("100%", h + "px");
		this.addNorth(this.titleBar, 30);
		this.addNorth(this.toolBar, 25);
		//this.designToolBar.setSize("45px", (h - 50) + "px");
		//this.addWest(this.designToolBar, 65);
		this.add(scrollPanel);
	}

	ScrollPanel initDrawingPane() {
		this.drawingController = new DrawingController(Window.getClientWidth() - 65, Window.getClientHeight());
		ScrollPanel scrollPanel = new ScrollPanel(this.drawingController.getDiagramController().getView());
		scrollPanel.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DRAWING_SCROLLPANE);
		this.drawingController.getDiagramController().getView().getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DRAWING_VIEW);

		return scrollPanel;
	}

	void initMetaData() {
		this.service.getSourceConfig(new AsyncCallback<String>() {
			@Override
			public void onSuccess(String data) {
				refreshMetaList(data);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server ERROR!!!");
			}
		});
	}

	void refreshMetaList(String data) {
		JSONObject json = JSONParser.parseStrict(data).isObject();
		this.sourceType.clear();
		this.recordType.clear();
		this.dataType.clear();

		JSONArray arr = json.get("sourceTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			sourceType.add(arr.get(i).isString().stringValue());
		}

		arr = json.get("recordTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			recordType.add(arr.get(i).isString().stringValue());
		}

		arr = json.get("dataTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			dataType.add(arr.get(i).isString().stringValue());
		}
	}

	@Override
	public void onClick(ClickEvent event) {
		ImageButton btn = (ImageButton) event.getSource();
		int cmd = btn.getCommand();
		SDPWidget widget = null;
		try {
			widget = this.getWidget(cmd);
		} catch (Exception e) {
			Window.alert(e.getMessage());
			return;
		}

		if (widget != null) {
			this.drawingController.add(widget, 50, 50);
		}
	}

	public DrawingController getDrawingController() {
		return drawingController;
	}

	@Override
	public SDPWidget getSelectedWidget() {
		return selectedWidget;
	}

	public SDPTitleBar getTitleBar() {
		return titleBar;
	}

	public SPDFToolBar getToolBar() {
		return toolBar;
	}

/*	public DesignToolBar getDesignToolBar() {
		return designToolBar;
	}
*/
	public SDPPopupMenu getPopupMenu() {
		return popupMenu;
	}

	public WFActionClickHandler getWfActionClickHandler() {
		return wfActionClickHandler;
	}

	@Override
	public void setSelectedWidget(SDPWidget selectedWidget) {
		try {
			this.selectedWidget = selectedWidget;
		} catch (Exception e) {
			Window.alert(e.getMessage());
		}
	}

	@Override
	public void showPropertiesDialog() {
		try {
			SDPWidget w = (SDPWidget) this.getSelectedWidget();
			long projectId = 0;
			try {
				projectId = this.getSelectedProjectId();
			} catch (Exception e) {
				Window.alert(e.getMessage());
				return;
			}
			SdpDialogBox dialogBox = w.getPropertyEditor(projectId);
			if (dialogBox != null) {
				dialogBox.setModal(false);
				dialogBox.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
				dialogBox.setGlassEnabled(true);
				dialogBox.setAnimationEnabled(true);
				dialogBox.center();
				dialogBox.show();
				dialogBox.postProcess();
			}
		} catch (Exception e) {
			Window.alert("Error opening Properties window:" + e.getMessage());
		}
	}

	@Override
	public void deleteSelected() {
		SDPWidget w = (SDPWidget) this.getSelectedWidget();
		if (w.getPredecessors().size() > 0 || w.getSuccessors().size() > 0) {
			Window.alert("Delete link first!!!");
		} else {
			this.drawingController.remove(w);
		}
	}

	@Override
	public void openEditor(long id) {
		this.prevId = this.jobId;
		this.jobId = id;
		this.wfActionHandler.openWorkflow(id);
	}

	public void deleteAll() {
		this.drawingController.removeAll();
	}

	public void addConnection(SDPWidget startWidget, SDPWidget endWidget) {
		this.drawingController.dc.drawStraightArrowConnection(startWidget, endWidget);
	}

	public SDPWidget getWidget(int cmd) {
		long pId = 0;
		try {
			pId = this.getSelectedProjectId();
		} catch (Exception e) {
			Window.alert("Please select project!!");
			return null;
		}

		switch (cmd) {
		case ComponentTypes.START:
			this.startNode = new Start(popupMenu, wfActionClickHandler, titleBar, pId);
			return this.startNode;
		case ComponentTypes.END:
			return new End(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_LOCAL:
			return new SourceLocal(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_HDFS:
			return new SourceHDFS(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_HIVE:
			return new SourceHive(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_RDBMS:
			return new SourceRDBMS(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_HBASE:
			return new SourceHBase(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_CASSANDRA:
			return new SourceCassandra(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_KAFKA:
			return new SourceKafka(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_TCP:
			return new SourceTcp(popupMenu, wfActionClickHandler);
		case ComponentTypes.SOURCE_FILE_STREAM:
			try {
				return new SourceFileStream(popupMenu, wfActionClickHandler, this.getSelectedProjectId());
			} catch (Exception e) {
				Window.alert("Error creating task" + e.getMessage());
				return null;
			}
		case ComponentTypes.SOURCE_FLUME:
			return new SourceFlume(popupMenu, wfActionClickHandler);
		case ComponentTypes.GROUP:
			return new Group(popupMenu, wfActionClickHandler);
		case ComponentTypes.JOIN:
			return new Join(popupMenu, wfActionClickHandler);
		case ComponentTypes.FILTER:
			return new Filter(popupMenu, wfActionClickHandler);
		case ComponentTypes.SORT:
			return new Sort(popupMenu, wfActionClickHandler);
		case ComponentTypes.TRANSFORMATION:
			return new Transformation(popupMenu, wfActionClickHandler);
		case ComponentTypes.TARGET_DELIM:
			return new TargetDelim(popupMenu, wfActionClickHandler);
		case ComponentTypes.TARGET_JSON:
			return new TargetJSON(popupMenu, wfActionClickHandler);
		case ComponentTypes.TARGET_XML:
			return new TargetXML(popupMenu, wfActionClickHandler);
		case ComponentTypes.RESPONSE_JSON:
			return new ResponseJSON(popupMenu, wfActionClickHandler);
		case ComponentTypes.CUSTOM_ACTION:
			return new CustomAction(popupMenu, wfActionClickHandler);
		case ComponentTypes.SQOOP:
			return new Sqoop(popupMenu, wfActionClickHandler, this.wfActionHandler);
		case ComponentTypes.HDFS_COPY:
			return new HDFSCopy(popupMenu, wfActionClickHandler);
		case ComponentTypes.DEDUP:
			return new Dedup(popupMenu, wfActionClickHandler);
		case ComponentTypes.FUNCTION:
			return new Function(popupMenu, wfActionClickHandler);
		case ComponentTypes.VALUE:
			return new FunctionValue(popupMenu, wfActionClickHandler);
		case ComponentTypes.BRANCH:
			return new Branch(popupMenu, wfActionClickHandler);
		case ComponentTypes.CUSTOM_SERVICES:
			return new CommonService(popupMenu, wfActionClickHandler);
		case ComponentTypes.SUB_WF:
			return new SubWf(this, popupMenu, wfActionClickHandler, pId);
		case ComponentTypes.DATAFRAME:
			return new DataFrame(popupMenu, wfActionClickHandler, this.getDataType());
		case ComponentTypes.ROW:
			return new Row(popupMenu, wfActionClickHandler, this.dataType);
		case ComponentTypes.PRIME_TYPE:
			return new PrimeType(popupMenu, wfActionClickHandler, this.dataType);

		default:
			return new Start(popupMenu, wfActionClickHandler, titleBar, pId);
		}
	}

	public void processOpenWorkFlow(String json) {
		JSONObject msg = (JSONObject) JSONParser.parseStrict(json);
		if ("ERROR".equalsIgnoreCase(msg.get("status").isString().stringValue())) {
			Window.alert(msg.get("data").isString().stringValue());
			return;
		}
		this.getDrawingController().removeAll();
		this.selectedWidget = null;
		JSONObject jsonJob = msg.get("data").isObject();
		JSONObject start = jsonJob.get("start").isObject();
		Map<String, SDPWidget> map = new HashMap<String, SDPWidget>();
		List<JSONObject> stack = new ArrayList<JSONObject>();
		stack.add(start);
		while (stack.size() > 0) {
			JSONObject obj = null;
			try {
				obj = stack.remove(0);
				String name = obj.get("name").isString().stringValue().trim();
				int ct = (int) obj.get("componentType").isNumber().doubleValue();
				if (!map.containsKey(name)) {
					SDPWidget w = this.getWidget(ct);
					w.setProperties(obj);
					if (ComponentTypes.START == w.getType()) {
						this.startNode = (Start) w;
					}
					if (w != null) {
						this.drawingController.add(w, w.getLeft(), w.getTop());
						map.put(name, w);
					}
					if (obj.get("successors") != null) {
						JSONArray arr = obj.get("successors").isArray();
						for (int i = 0; i < arr.size(); i++) {
							String s = arr.get(i).isString().stringValue();
							if (!map.containsKey(s)) {
								stack.add(jsonJob.get(s).isObject());
							}
						}
					}
				}
			} catch (Exception e) {
				Window.alert("ERROR - parsing JSON - " + obj.toString());

			}
		}
		for (SDPWidget w : map.values()) {
			setRelations(jsonJob.get(w.getName()).isObject(), w, map);
			w.postProcess();
		}

		for (SDPWidget w : map.values()) {
			for (SDPWidget s : w.getSuccessors()) {
				this.addConnection(w, s);
			}
		}

		try {
			this.jobName = JSONUtil.getEmptyIfNull("jobName", start);
			this.jobType = JSONUtil.getEmptyIfNull("jobType", start);
			this.jobId = (long) start.get("jobId").isNumber().doubleValue();
		} catch (Exception e) {
			Window.alert(e.getMessage());
		}
		this.setTitle(this.jobName);
	}

	public boolean isNewJob() {
		if (this.jobId <= 0)
			return true;
		if (!this.jobName.equals(this.startNode.getJobName()))
			return true;

		return false;
	}

	public boolean isSubWorkflow() {
		return !"JOB".equalsIgnoreCase(this.jobType);
	}

	private void setRelations(JSONObject jsonObj, SDPWidget widget, Map<String, SDPWidget> map) {

		if (ComponentTypes.END != widget.getType()) {
			try {

				JSONArray arr = jsonObj.get("successors").isArray();
				if (arr != null) {
					for (int i = 0; i < arr.size(); i++) {
						String child = arr.get(i).isString().stringValue().trim();
						SDPWidget childWidget = map.get(child);
						widget.getSuccessors().add(childWidget);
					}
				}

			} catch (Exception e) {
				Window.alert("ERROR setting task successors - " + e.getMessage());
			}
		}

		if (ComponentTypes.START != widget.getType()) {
			try {

				JSONArray arr = jsonObj.get("predecessors").isArray();
				if (arr != null) {
					for (int i = 0; i < arr.size(); i++) {
						String parent = arr.get(i).isString().stringValue().trim();
						SDPWidget parentWidget = map.get(parent);
						widget.getPredecessors().add(parentWidget);
					}
				}

			} catch (Exception e) {
				Window.alert("ERROR setting task predecessors - " + e.getMessage());
			}
		}

	}

	public WFActionHandler getWfActionHandler() {
		return this.wfActionHandler;
	}

	public UserDto getUser() {
		return this.user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

	public Long getSelectedProjectId() {
		return this.selectedPId;
	}

	public String getSelectedProjectName() {
		for (ProjectDto p : this.user.getProjects()) {
			if (p.getId() == this.selectedPId) {
				return p.getName();
			}
		}

		return null;
	}

	public ProjectDto getSelectedProject() {
		for (ProjectDto p : this.user.getProjects()) {
			if (this.selectedPId == p.getId()) {
				return p;
			}
		}

		return null;
	}

	public void selectProject(long pId) {
		this.selectedPId = pId;
		Window.alert("PID>>" + this.selectedPId);
		this.titleBar.setProject(pId + "-" + this.getSelectedProjectName());
	}

	public void setTitle(String title) {
		this.titleBar.setTitle(title);
	}

	public void showProgress(String msg) {
		this.progressBar.setText(msg);
		this.progressBar.startProgress();
	}

	public void stopProgress() {
		this.progressBar.stopProgress();
	}

	public Start getStart() {
		return this.startNode;
	}

	public List<String> getSourceType() {
		return sourceType;
	}

	public void setSourceType(List<String> sourceType) {
		this.sourceType = sourceType;
	}

	public List<String> getRecordType() {
		return recordType;
	}

	public void setRecordType(List<String> recordType) {
		this.recordType = recordType;
	}

	public List<String> getDataType() {
		return dataType;
	}

	public void setDataType(List<String> dataType) {
		this.dataType = dataType;
	}

	public long getPreviousId() {
		return this.prevId;
	}

	public void saveCurrentId(long currentId) {
		this.prevId = this.jobId;
		this.jobId = currentId;
	}

	public void showHideDrawingTool() {
		this.toolWin.show();
	}

	public void setWFType(int type) {
		this.wfType = type;
	}

	public int getWFType() {
		return this.wfType;
	}

	public void newWorkflow() {
		this.getDrawingController().removeAll();
		this.wfType = TYPE_WF;
	}

	public void newSubWorkflow() {
		this.getDrawingController().removeAll();
		this.wfType = TYPE_SUB_WF;
	}
}
