package com.gb.wf.client.component;

import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ConditionDto;
import com.gb.wf.client.handler.RowDeleteHandler;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class FilterConditionRow extends FlowPanel {
	ListBox lstColumn = new ListBox();
	ListBox lstCondition = new ListBox();
	TextBox txtValue = new TextBox();
	TextBox txtOther = new TextBox();
	Label lblType = new Label();

	RowDeleteHandler handler;

	public FilterConditionRow(List<ColumnDto> fields, RowDeleteHandler handler, String type) {
		this(fields, handler, type, null);
	}

	public FilterConditionRow(List<ColumnDto> fields, RowDeleteHandler handler, String type, ConditionDto dto) {
		this.handler = handler;

		this.lstColumn.addItem("Select Column");
		for (ColumnDto f : fields) {
			this.lstColumn.addItem(f.getName());
		}

		this.lstCondition.addItem("Equal To");
		this.lstCondition.addItem("Greater Than");
		this.lstCondition.addItem("Less Than");
		this.lstCondition.addItem("Greater or Equal");
		this.lstCondition.addItem("Less or Equal");
		this.lstCondition.addItem("Start With");
		this.lstCondition.addItem("End With");
		this.lstCondition.addItem("Contain");
		this.lstCondition.addItem("Not Equal");
		this.lstCondition.addItem("In");
		this.lstCondition.addItem("Not In");
		this.lstCondition.addItem("Other");

		this.lblType.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		this.lblType.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		this.lblType.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.lblType, 50, 20);
		if (type != null) {
			this.lblType.setText(type);
		}
		this.add(this.lblType);

		this.lstColumn.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.lstColumn, 100, 20);
		this.add(this.lstColumn);

		this.lstCondition.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.lstCondition, 100, 20);
		this.add(this.lstCondition);

		this.txtOther.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.txtOther, 100, 20);
		this.add(this.txtOther);

		this.txtValue.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.txtValue, 100, 20);
		this.add(this.txtValue);

		ImageButton btn = new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_JOIN, "Delete Join Condition", new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				deleteMe();
			}
		}, 20, 20);
		btn.getElement().getStyle().setFloat(Float.LEFT);
		this.add(btn);

		this.lstCondition.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent ce) {
				conditionChanged();
			}
		});

		if (dto != null) {
			init(dto);
		}

		this.txtOther.setEnabled(false);
		this.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
	}

	void conditionChanged() {
		int idx = this.lstCondition.getSelectedIndex();
		if ((idx + 1) == this.lstCondition.getItemCount()) {
			this.txtOther.setEnabled(true);
		} else {
			this.txtOther.setEnabled(false);
		}
	}

	void deleteMe() {
		this.handler.deleteRow(this);
	}

	void setControllSise(Widget wdg, double w, double h) {
		wdg.getElement().getStyle().setWidth(w, Unit.PX);
		wdg.getElement().getStyle().setHeight(h, Unit.PX);
	}

	void init(ConditionDto dto) {
		for (int i = 0; i < lstColumn.getItemCount(); i++) {
			if (dto.getColumn().equals(lstColumn.getItemText(i))) {
				lstColumn.setSelectedIndex(i);
				break;
			}
		}

		int i;
		for (i = 0; i < lstCondition.getItemCount(); i++) {
			if (dto.getCondition().equals(lstCondition.getItemText(i))) {
				lstCondition.setSelectedIndex(i);
				break;
			}
		}
		
		if (i == lstCondition.getItemCount())
		{
			txtOther.setText(dto.getCondition());
			lstCondition.setSelectedIndex(i-1);
			txtOther.setEnabled(true);
		}
		
		txtValue.setText(dto.getValue());
	}

	public ConditionDto getDto() {
		ConditionDto dto = new ConditionDto();

		if (this.lstColumn.getSelectedIndex() > 0) {
			dto.setColumn(this.lstColumn.getItemText(this.lstColumn.getSelectedIndex()));
		} else {
			Window.alert("Select Column");
			return null;
		}

		int idx = lstCondition.getSelectedIndex();
		if ("other".equalsIgnoreCase(lstCondition.getItemText(idx))) {
			dto.setCondition(this.txtOther.getText());
		} else {
			dto.setCondition(this.lstCondition.getItemText(this.lstCondition.getSelectedIndex()));
		}

		if (this.lblType.getText().trim().length() > 0) {
			dto.setType(this.lblType.getText());
		} else {
			dto.setType("none");
		}

		if (this.txtValue.getText().length() > 0) {
			dto.setValue(this.txtValue.getText());
		} else {
			Window.alert("Enter Value");
			return null;
		}

		return dto;
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		if (this.lstColumn.getSelectedIndex() > 0) {

			json.put("column", new JSONString(this.lstColumn.getItemText(this.lstColumn.getSelectedIndex())));
		} else {
			Window.alert("Select Column");
			return null;
		}

		int idx = lstCondition.getSelectedIndex();
		if ("other".equalsIgnoreCase(lstCondition.getItemText(idx))) {
			json.put("condition", new JSONString(this.txtOther.getText()));

		} else {
			json.put("condition", new JSONString(this.lstCondition.getItemText(this.lstCondition.getSelectedIndex())));

		}

		if (this.lblType.getText().trim().length() > 0) {
			json.put("type", new JSONString(this.lblType.getText()));
		} else {
			json.put("type", new JSONString("none"));
		}

		if (this.txtValue.getText().length() > 0) {
			json.put("type", new JSONString(this.txtValue.getText()));
		} else {
			Window.alert("Enter Value");
			return null;
		}

		return json;
	}
}
