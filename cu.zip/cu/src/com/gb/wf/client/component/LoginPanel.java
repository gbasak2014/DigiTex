package com.gb.wf.client.component;

import com.gb.wf.client.LoginService;
import com.gb.wf.client.LoginServiceAsync;
import com.gb.wf.client.dlg.UserRegistrationDlg;
import com.gb.wf.client.dto.UserDto;
import com.gb.wf.client.util.SdfUtils;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class LoginPanel extends DockLayoutPanel {
	TextBox txtUser = new TextBox();
	PasswordTextBox txtPassword = new PasswordTextBox();
	Panel pnlTop = new FlowPanel();
	Panel pnlBottom = new FlowPanel();
	Panel pnlLeft = new FlowPanel();
	Panel pnlRight = new FlowPanel();

	Label lblMsg = new Label();

	VerticalPanel vp = new VerticalPanel();
	Button btn = new Button("Login");

	private final LoginServiceAsync service = GWT.create(LoginService.class);

	public LoginPanel() {
		super(Unit.PX);

		vp.setSize("400px", "300px");
		vp.setStyleName("loginPanel");

		Label lbl;// = new Label("Welcome to SPARK Data Process workflow");
		// lbl.setStyleName("logoText");
		// vp.add(lbl);

		lblMsg.getElement().getStyle().setBackgroundColor("#ff0000");
		vp.add(lblMsg);
		FlowPanel fp = new FlowPanel();
		fp.getElement().getStyle().setMargin(5, Unit.PX);
		lbl = new Label("Username:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		txtUser.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(txtUser);
		vp.add(fp);

		fp = new FlowPanel();
		fp.getElement().getStyle().setMargin(5, Unit.PX);
		lbl = new Label("Password:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		txtPassword.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(txtPassword);
		vp.add(fp);

		fp = new FlowPanel();
		fp.getElement().getStyle().setMargin(5, Unit.PX);

		btn.getElement().getStyle().setFloat(Float.RIGHT);
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				login();
			}
		});
		fp.add(btn);
		vp.add(fp);

		fp = new FlowPanel();
		fp.getElement().getStyle().setMargin(10, Unit.PX);
		Anchor a1 = new Anchor(" Forgot Password");
		a1.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				forgotPassword();
			}
		});
		a1.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(a1);
		lbl = new Label(" | ");
		lbl.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(lbl);

		a1 = new Anchor("Registration ");
		a1.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				registration();
			}
		});

		a1.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(a1);

		vp.add(fp);

		// DockLayoutPanel dlp = new DockLayoutPanel(Unit.PX);
		Label lblLogo = new Label("Shristi - The Creator");
		lblLogo.setStyleName("logoText");
		pnlTop.add(lblLogo);
		Label lblDv = new Label("Design your data Ingestion and Data processing job");
		lblDv.getElement().getStyle().setFontSize(20, Unit.PX);
		lblDv.getElement().getStyle().setColor("blue");
		pnlRight.add(lblDv);

		this.setStyleName("pwdPanel");
		pnlTop.setStyleName("pwdPanel");
		pnlLeft.setStyleName("pwdPanel");
		pnlRight.setStyleName("pwdPanel");

		int h = Window.getClientHeight();
		this.setSize("100%", h + "px");
		addNorth(pnlTop, 150);
		// addSouth(pnlBottom, 100);
		addSouth(pnlRight, 100);
		addWest(pnlLeft, 300);
		add(vp);
	}

	void forgotPassword() {
		Window.alert("Forgot pwd");
	}

	void login() {
		btn.setEnabled(false);
		JSONObject st = new JSONObject();
		st.put("userId", new JSONString(txtUser.getText()));
		st.put("password", new JSONString(txtPassword.getText()));

		service.loginUser(st.toString(), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String result) {
				processLogin(result);
			}

			@Override
			public void onFailure(Throwable e) {
				Window.alert("Fail to Login!!!" + e.getMessage());
			}
		});
	}

	void registration() {
		UserRegistrationDlg dlg = new UserRegistrationDlg();
		RootPanel.get().clear();
		RootPanel.get().add(dlg);
	}

	void processLogin(String msg) {
		if ("UNAUTHENTICATE".equalsIgnoreCase(msg)) {
			this.lblMsg.setText("Invalid User or Password!!!");
		} else if ("ERROR".equalsIgnoreCase(msg)) {
			this.lblMsg.setText("Sorry. System ERROR!!!");
		} else {
			JSONObject json = (JSONObject) JSONParser.parseStrict(msg);

			UserDto user = SdfUtils.getUserDto(json);
			WFDesignerPage mainPage = new WFDesignerPage(user);
			RootPanel.get().clear();
			RootPanel.get().add(mainPage);
		}
	}
}
