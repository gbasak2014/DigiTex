package com.gb.wf.client.component;

import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;

public class ProgressBar extends PopupPanel {
	Label lbl = new Label("Lopading......");

	public ProgressBar() {
		final Image img = new Image("images/loader.gif");
		img.setWidth("40px");
		img.setHeight("40px");
		this.lbl.setWidth("340px");
		this.lbl.setHeight("100px");
		this.lbl.getElement().getStyle().setColor("#FFFFFF");
		Grid grid = new Grid(1, 2);
		grid.setWidget(0, 0, img);
		grid.setWidget(0, 1, lbl);
		this.add(grid);
		this.setWidth("400px");
		this.setHeight("200px");
		this.getElement().getStyle().setBackgroundColor("#1F3D47");
		this.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);
	}

	public void startProgress() {
		this.center();
		this.show();
	}

	public void stopProgress() {
		this.hide();
	}

	public void setText(String txt) {
		this.lbl.setText(txt);
	}
}
