package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.allen_sauer.gwt.dnd.client.PickupDragController;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Start;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Widget;
import com.orange.links.client.DiagramController;
import com.orange.links.client.event.TieLinkEvent;
import com.orange.links.client.event.TieLinkHandler;
import com.orange.links.client.event.UntieLinkEvent;
import com.orange.links.client.event.UntieLinkHandler;

public class DrawingController implements TieLinkHandler, UntieLinkHandler {
	DiagramController dc;
	PickupDragController dragController;

	List<SDPWidget> list = new ArrayList<SDPWidget>();

	public DrawingController(int canvasWidth, int canvasHeight) {
		this.dc = new DiagramController(canvasWidth, canvasHeight);
		this.dragController = new PickupDragController(this.dc.getView(), true);
		this.dc.registerDragController(this.dragController);
		this.dc.addTieLinkHandler(this);
		this.dc.addUntieLinkHandler(this);

	}

	public DiagramController getDiagramController() {
		return this.dc;
	}

	public PickupDragController getDragController() {
		return this.dragController;
	}

	public List<SDPWidget> getWidgets() {
		return this.list;
	}

	public void add(SDPWidget widget) {
		this.list.add(widget);
		this.dc.addWidget(widget, 0, 0);
		this.dragController.makeDraggable(widget);
	}

	public void add(SDPWidget widget, int x, int y) {
		this.list.add(widget);
		this.dc.addWidget(widget, x, y);
		this.dragController.makeDraggable(widget);
	}

	public void remove(Widget widget) {
		this.list.remove(widget);
		this.dc.deleteWidget(widget);
	}

	public void removeAll() {
		this.dc.clearDiagram();
		this.list.clear();
	}

	@Override
	public void onTieLink(TieLinkEvent event) {
		SDPWidget pred = (SDPWidget) event.getStartWidget();
		SDPWidget succ = (SDPWidget) event.getEndWidget();
		if (pred.getGroup() == ComponentTypes.SOURCE && succ.getGroup() == ComponentTypes.SOURCE && pred.getType() != ComponentTypes.SOURCE_LOCAL
				&& succ.getType() != ComponentTypes.SOURCE_HDFS) {
			Window.alert("Only Source Local to Source HDFS can be connected!!!");
			event.getConnection().delete();
		} else {
			pred.addChild(succ);
		}
	}

	@Override
	public void onUntieLink(UntieLinkEvent event) {
		SDPWidget pred = (SDPWidget) event.getStartWidget();
		SDPWidget succ = (SDPWidget) event.getEndWidget();
		pred.removeChild(succ);
	}

	public boolean isNameExist(String name) {
		for (SDPWidget w : this.list) {
			if (name.equalsIgnoreCase(w.getName())) {
				return true;
			}
		}

		return false;
	}

	public int getAbsoluteLeft() {
		return this.dc.getView().getAbsoluteLeft();
	}

	public int getAbsoluteTop() {
		return this.dc.getView().getAbsoluteTop();
	}

	public Start getStartNode() {
		for (SDPWidget w : this.list) {
			if (w.getType() == ComponentTypes.START) {
				return (Start) w;
			}
		}

		return null;
	}
}
