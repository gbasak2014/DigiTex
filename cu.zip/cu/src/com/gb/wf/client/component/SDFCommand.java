package com.gb.wf.client.component;

public interface SDFCommand {
	int getCommand();
}
