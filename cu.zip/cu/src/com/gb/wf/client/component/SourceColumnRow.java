package com.gb.wf.client.component;

import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.handler.RowDeleteHandler;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;

public class SourceColumnRow extends FlowPanel {
	TextBox txtColumn = new TextBox();
	ListBox lstDataType = new ListBox();
	CheckBox chkSensitive = new CheckBox("Sensitive?");

	RowDeleteHandler handler;

	public SourceColumnRow(List<String> dataTypes, RowDeleteHandler handler) {
		this.handler = handler;

		this.lstDataType.addItem("Select Data Type");
		for (String f : dataTypes) {
			this.lstDataType.addItem(f);
		}

		this.txtColumn.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.txtColumn, 200, 20);
		this.add(this.txtColumn);

		this.lstDataType.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.lstDataType, 200, 20);
		this.add(this.lstDataType);

		this.chkSensitive.getElement().getStyle().setFloat(Float.LEFT);
		setControllSise(this.chkSensitive, 100, 20);
		this.add(this.chkSensitive);

		ImageButton btn = new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_JOIN, "Delete Join Condition", new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				deleteMe();
			}
		}, 20, 20);
		btn.getElement().getStyle().setFloat(Float.LEFT);
		this.add(btn);

	}

	void deleteMe() {
		this.handler.deleteRow(this);
	}

	void setControllSise(Widget wdg, double w, double h) {
		wdg.getElement().getStyle().setWidth(w, Unit.PX);
		wdg.getElement().getStyle().setHeight(h, Unit.PX);
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		if (this.txtColumn.getText().trim().length() > 0) {
			json.put("name", new JSONString(this.txtColumn.getText()));
		} else {
			Window.alert("Enter Column Name");
			return null;
		}

		if (this.lstDataType.getSelectedIndex() > 0) {

			json.put("dataType", new JSONString(this.lstDataType.getItemText(this.lstDataType.getSelectedIndex())));
		} else {
			Window.alert("Select Data Type");
			return null;
		}

		json.put("sensitiveFlag", new JSONString(String.valueOf(this.chkSensitive.getValue())));

		return json;
	}

	public void setValues(String column, String dataType, boolean sensitive) {
		this.txtColumn.setText(column);
		this.chkSensitive.setValue(sensitive);

		for (int i = 0; i < this.lstDataType.getItemCount(); i++) {
			if (dataType.equalsIgnoreCase(this.lstDataType.getItemText(i))) {
				this.lstDataType.setSelectedIndex(i);
				break;
			}
		}
	}

	public ColumnDto getColumnData()
	{
		ColumnDto dto = new ColumnDto();
		dto.setName(this.txtColumn.getText());
		dto.setDataType(this.lstDataType.getItemText(this.lstDataType.getSelectedIndex()));
		dto.setSensitiveFlag(this.chkSensitive.getValue());
		
		return dto;
	}
}
