package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.Widget;

public class SDFDropDownMenu extends PopupPanel {
	FlexTable table = new FlexTable();
	Widget parent;
	int r = 0;

	public SDFDropDownMenu(Widget parent) {
		super(true);
		this.parent = parent;
		this.setStyleName("sdf-submenu");
		this.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);

		this.add(this.table);
	}

	public void addItem(Anchor mi) {
		this.table.setText(r, 0, "");
		this.table.setWidget(r, 1, mi);
		this.table.getCellFormatter().getElement(r, 0).getStyle().setWidth(20, Unit.PX);
		r++;
	}

	@Override
	public void setSize(String width, String height) {
		super.setSize(width, height);
	}

	public void refreshSize() {
		String h = (r * 20) + "px";
		this.setSize("200px", h);
	}

	public void showMe() {
		try {
			int l = this.parent.getAbsoluteLeft();
			int t = this.parent.getAbsoluteTop() + this.parent.getOffsetHeight();
			this.setPopupPosition(l, t);
		} catch (Exception e) {
			Window.alert(e.getMessage());
			// this.center();
		}

		this.show();
	}

}
