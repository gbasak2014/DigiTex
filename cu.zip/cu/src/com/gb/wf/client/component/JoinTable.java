package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.JoinDto;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class JoinTable extends DockLayoutPanel {
	VerticalPanel table = new VerticalPanel();
	List<JoinConditionRow> model = new ArrayList<JoinConditionRow>();

	List<SDPWidget> schemaList;
	public JoinTable(List<SDPWidget> schemaList) {
		super(Unit.PX);
		this.schemaList = schemaList;
		this.setSize("610px", "200px");
		ScrollPanel sp = new ScrollPanel();
		sp.getElement().getStyle().setBackgroundColor("#ffffff");
		sp.getElement().getStyle().setBorderColor("#0");
		sp.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		sp.setSize("600px", "200px");
		table.setWidth("600px");
		sp.add(table);

		this.addNorth(new JoinConditionHeader(this), 25);
		this.add(sp);
	}

	public void insertRow() {
		JoinConditionRow row = new JoinConditionRow(this.schemaList, this);
		this.model.add(row);
		this.table.add(row);
	}

	public void insertRow(JoinDto dto) {
		JoinConditionRow row = new JoinConditionRow(this.schemaList, this, dto);
		this.model.add(row);
		this.table.add(row);
	}
	
	public void removeRow(JoinConditionRow row) {
		this.model.remove(row);
		this.table.remove(row);
	}

	public List<JoinConditionRow> getModel() {
		return this.model;
	}

	public JSONArray getJSON() {
		JSONArray jsonArr = new JSONArray();

		for (int i = 0; i < this.model.size(); i++) {
			JoinConditionRow row = this.model.get(i);
			jsonArr.set(i, row.getJSON());
		}

		return jsonArr;
	}

	public String getJSONString() {
		return getJSON().toString();
	}

	public int getRowCount() {
		return this.model.size();
	}
}
