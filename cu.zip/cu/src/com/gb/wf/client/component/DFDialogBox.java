package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ComplexPanel;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;

public class DFDialogBox extends DialogBox {
	public DFDialogBox(String title, ComplexPanel propPanel) {
		this.ensureDebugId("cwDialogBox");
		this.setText(title);

		DockLayoutPanel dialogContents = new DockLayoutPanel(Unit.PX);
		this.setWidget(dialogContents);

		// Add some text to the top of the dialog
		dialogContents.addNorth(new Button("Hwlo......................."), 25);
		dialogContents.add(propPanel);
		// Add a close button at the bottom of the dialog
		Button closeButton = new Button("Close", new ClickHandler() {
			public void onClick(ClickEvent event) {
				hide();
			}
		});

		FlowPanel fp = new FlowPanel();
		fp.add(closeButton);
		dialogContents.addSouth(fp, 25);

	}
}
