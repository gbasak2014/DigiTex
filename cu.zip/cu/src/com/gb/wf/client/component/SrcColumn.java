package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.TextBox;

public class SrcColumn {
	TextBox txtName = new TextBox();
	TextBox txtDataType = new TextBox();
	TextBox txtPos = new TextBox();
	TextBox txtLength = new TextBox();
	CheckBox chkSensitive = new CheckBox();
	long id;

	public SrcColumn() {
		this.txtDataType.setWidth("100px");
		this.txtLength.setWidth("60px");
		this.txtName.setWidth("150px");
		this.txtPos.setWidth("50px");
	}

	public SrcColumn(JSONObject obj, long id, int pos, String name, String dataType, int length, boolean sensitive, FlexTable tbl, int row) {
		this();
		this.txtDataType.setText(dataType);
		this.txtLength.setText(String.valueOf(length));
		this.txtName.setText(name);
		this.txtPos.setText(String.valueOf(pos));
		this.chkSensitive.setValue(sensitive);

		tbl.setWidget(row, 0, this.txtPos);
		tbl.setWidget(row, 1, this.txtName);
		tbl.setWidget(row, 2, this.txtDataType);
		tbl.setWidget(row, 3, this.txtLength);
		tbl.setWidget(row, 4, this.chkSensitive);
	}

	public SrcColumn(JSONObject obj, FlexTable tbl, int row) {
		this();
		this.txtDataType.setText(obj.get("dataType") != null ? obj.get("dataType").isString().stringValue() : "");
		this.txtLength.setText(obj.get("length") != null ? obj.get("length").toString() : "");
		this.txtName.setText(obj.get("name") != null ? obj.get("name").isString().stringValue() : "");
		this.txtPos.setText(obj.get("pos") != null ? obj.get("pos").toString() : "");
		this.chkSensitive.setValue(obj.get("sensitiveFlag") != null ? obj.get("sensitiveFlag").isBoolean().booleanValue() : false);

		tbl.setWidget(row, 0, this.txtPos);
		tbl.setWidget(row, 1, this.txtName);
		tbl.setWidget(row, 2, this.txtDataType);
		tbl.setWidget(row, 3, this.txtLength);
		tbl.setWidget(row, 4, this.chkSensitive);
	}

	public JSONObject getJSON() {
		JSONObject obj = new JSONObject();

		obj.put("id", new JSONNumber(this.id));
		obj.put("name", new JSONString(this.txtName.getText()));
		obj.put("dataType", new JSONString(this.txtDataType.getText()));
		obj.put("pos", new JSONNumber(Integer.parseInt(this.txtPos.getText())));
		obj.put("length", new JSONNumber(Integer.parseInt(this.txtLength.getText())));
		obj.put("sensitiveFlag", new JSONString(this.chkSensitive.getValue().toString()));

		return obj;
	}

	public FlowPanel getRow() {
		FlowPanel fp = new FlowPanel();
		this.txtPos.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.getElement().getStyle().setFloat(Float.LEFT);
		this.txtDataType.getElement().getStyle().setFloat(Float.LEFT);
		this.txtLength.getElement().getStyle().setFloat(Float.LEFT);
		this.chkSensitive.getElement().getStyle().setFloat(Float.LEFT);

		fp.add(this.txtPos);
		fp.add(this.txtName);
		fp.add(this.txtDataType);
		fp.add(this.txtLength);
		fp.add(this.chkSensitive);

		return fp;
	}
}
