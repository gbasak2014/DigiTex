package com.gb.wf.client.component;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.ToggleButton;

public class SDFMenu extends ToggleButton {

	SDFDropDownMenu dropDownMenu;

	public SDFMenu(String title) {
		super(title);
		this.getElement().getStyle().setOpacity(0.8);
		//this.setStyleName("gwt-Menu-Button");
		//this.setStylePrimaryName("gwt-Menu-Button");
		// this.getElement().getStyle().setBackgroundColor("#eef");
		// this.getElement().getStyle().setOpacity(.9);
		this.dropDownMenu = new SDFDropDownMenu(this);
		this.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				showDropDown();
			}
		});
	}

	public void addMenuItem(String title, int command, ClickHandler handler) {
		SDFMenuItem mi = new SDFMenuItem(title, command, handler);
		this.dropDownMenu.addItem(mi);
	}

	void showDropDown() {
		dropDownMenu.refreshSize();
		dropDownMenu.showMe();
	}
}
