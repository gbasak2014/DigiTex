package com.gb.wf.client.component;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.Widget;

public class FileMenuItems extends PopupPanel {

	Widget parent;

	public FileMenuItems(Widget parent) {
		super(true);
		this.parent = parent;
		FlexTable tbl = new FlexTable();
		Anchor aNewWf = new Anchor("New Workflow");
		Anchor aNewSWf = new Anchor("New Sub Workflow");
		Anchor aOpenWf = new Anchor("Open Workflow");
		Anchor aOpenSWf = new Anchor("Open Sub Workflow");
		Anchor aSaveWf = new Anchor("Save Workflow");
		Anchor aSaveSWf = new Anchor("Save Sub Workflow");
		
		tbl.setWidget(0, 0, aNewWf);
		tbl.setWidget(1, 0, aNewSWf);
		tbl.setWidget(2, 0, aOpenWf);
		tbl.setWidget(3, 0, aOpenSWf);
		tbl.setWidget(4, 0, aSaveWf);
		tbl.setWidget(5, 0, aSaveSWf);
		this.add(tbl);
		this.setWidth("200px");
		this.setHeight("120px");
		this.setStyleName("sdf-submenu");
		this.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);
		aNewWf.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				Window.alert("New Workflow");
			}
		});
	}

	public void showMe() {
		try {
			int l = this.parent.getAbsoluteLeft();
			int t = this.parent.getAbsoluteTop() + this.parent.getOffsetHeight();
			this.setPopupPosition(l, t);
		} catch (Exception e) {
			Window.alert(e.getMessage());
			// this.center();
		}

		this.show();
	}

	public void stopProgress() {
		this.hide();
	}
}
