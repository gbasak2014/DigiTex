package com.gb.wf.client.component;

import com.gb.wf.client.handler.MdmReqHandler;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.TextBox;

public class MdmReqWin extends PopupPanel {
	ListBox lstDBType = new ListBox();
	TextBox txtDb = new TextBox();
	TextBox txtUser = new TextBox();
	TextBox txtHost = new TextBox();
	PasswordTextBox txtPwd = new PasswordTextBox();
	TextBox txtTable = new TextBox();
	MdmReqHandler handler;

	JSONObject json;
	
	public MdmReqWin(MdmReqHandler handler) {
		this.handler = handler;
		this.setWidth("600px");
		this.setHeight("400px");
		this.setStyleName("gwt-DialogBox");
		this.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		this.getElement().getStyle().setBorderColor("#0");
		
		
		this.lstDBType.addItem("ORACLE");
		this.lstDBType.addItem("DB2");
		this.lstDBType.addItem("MYSQL");
		this.lstDBType.addItem("SQLServer");
		this.lstDBType.addItem("Sybase");
		
		FlexTable tbl = new FlexTable();
		tbl.setText(0, 0, "Database Type");
		tbl.setWidget(0, 1, this.lstDBType);
		tbl.setText(1, 0, "Database Name");
		tbl.setWidget(1, 1, this.txtDb);

		tbl.setText(2, 0, "Database Host");
		tbl.setWidget(2, 1, this.txtHost);

		tbl.setText(3, 0, "Database User");
		tbl.setWidget(3, 1, this.txtUser);

		tbl.setText(4, 0, "Database Password");
		tbl.setWidget(4, 1, this.txtPwd);

		tbl.setText(5, 0, "Table Name");
		tbl.setWidget(5, 1, this.txtTable);
		
		HorizontalPanel hp = new HorizontalPanel();
		hp.add(new Button("Ok", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				processOK();
			}
		}));
		hp.add(new Button("Cancel", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				processCancel();
			}
		}));

		tbl.setWidget(6, 1, hp);
		
		this.add(tbl);
	}

	void processCancel() {
		this.hide();
	}

	void processOK() {
		this.json = new JSONObject();
		int idx = this.lstDBType.getSelectedIndex();
		json.put("dbType", new JSONString(this.lstDBType.getItemText(idx)));
		json.put("db", new JSONString(this.txtDb.getText()));
		json.put("user", new JSONString(this.txtUser.getText()));
		json.put("pwd", new JSONString(this.txtPwd.getText()));
		json.put("host", new JSONString(this.txtHost.getText()));
		json.put("table", new JSONString(this.txtTable.getText()));
		this.handler.getSourceData(json);

		this.hide();
	}

	public void showWin() {
		this.center();
		this.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);
		this.show();
	}
}
