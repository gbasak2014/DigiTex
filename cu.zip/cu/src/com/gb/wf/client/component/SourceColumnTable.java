package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.handler.RowDeleteHandler;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class SourceColumnTable extends DockLayoutPanel implements RowDeleteHandler {
	VerticalPanel table = new VerticalPanel();
	List<SourceColumnRow> model = new ArrayList<SourceColumnRow>();

	List<String> dataTypes;

	public SourceColumnTable(List<String> dataTypes) {
		super(Unit.PX);
		if (dataTypes != null) {
			this.dataTypes = dataTypes;
		} else {
			this.dataTypes = new ArrayList<String>();
		}

		this.setSize("800px", "210px");
		ScrollPanel sp = new ScrollPanel();
		sp.getElement().getStyle().setBackgroundColor("#ffffff");
		sp.setSize("780px", "200px");
		table.setWidth("800px");
		sp.add(table);

		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Column Name");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		fp.add(lbl);
		lbl = new Label("Data Type");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		fp.add(lbl);
		lbl = new Label("Is Sensitive");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		lbl.getElement().getStyle().setWidth(100, Unit.PX);
		fp.add(lbl);
		Button btn = new Button("+");
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);

		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				insertRow();
			}
		});

		this.addNorth(fp, 30);
		this.add(sp);

		this.getElement().getStyle().setBorderColor("#0");
		this.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
	}

	public void insertRow() {
		SourceColumnRow row = new SourceColumnRow(this.dataTypes, this);
		this.model.add(row);
		this.table.add(row);
	}

	public void insertRow(String column, String dataType, boolean sensitive) {
		SourceColumnRow row = new SourceColumnRow(this.dataTypes, this);
		row.setValues(column, dataType, sensitive);
		this.model.add(row);
		this.table.add(row);
	}

	public void removeRow(SourceColumnRow row) {
		this.model.remove(row);
		this.table.remove(row);
	}

	public List<SourceColumnRow> getModel() {
		return this.model;
	}

	public JSONArray getJSON() {
		JSONArray jsonArr = new JSONArray();

		for (int i = 0; i < this.model.size(); i++) {
			SourceColumnRow row = this.model.get(i);
			JSONObject obj = row.getJSON();
			obj.put("pos", new JSONNumber(i));

			jsonArr.set(i, obj);
		}

		return jsonArr;
	}

	public String getJSONString() {
		return getJSON().toString();
	}

	public int getRowCount() {
		return this.model.size();
	}

	@Override
	public void deleteRow(Widget widget) {
		this.model.remove(widget);
		this.table.remove(widget);
	}

	public void addDataType(String dataType) {
		this.dataTypes.add(dataType);
	}

	public List<ColumnDto> getColumnList() {
		List<ColumnDto> list = new ArrayList<ColumnDto>();
		for (int i = 0; i < this.model.size(); i++) {
			ColumnDto dto = this.model.get(i).getColumnData();
			list.add(dto);
		}
		return list;
	}
}
