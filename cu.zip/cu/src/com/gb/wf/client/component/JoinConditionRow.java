package com.gb.wf.client.component;

import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.JoinDto;
import com.gb.wf.client.widget.ImageButton;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.Widget;

public class JoinConditionRow extends FlowPanel {
	ListBox lstSchema1 = new ListBox();
	ListBox lstSchema2 = new ListBox();
	ListBox lstJoinType = new ListBox();
	ListBox lstField1 = new ListBox();
	ListBox lstField2 = new ListBox();

	List<SDPWidget> schemaList;

	JoinTable parent;

	public JoinConditionRow(List<SDPWidget> schemaList, JoinTable parent) {
		this(schemaList, parent, null);
	}

	public JoinConditionRow(List<SDPWidget> schemaList, JoinTable parent, JoinDto dto) {
		this.parent = parent;
		this.schemaList = schemaList;
		Label lbl;

		lstSchema1.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lstSchema1.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		// lstSchema1.setWidth("100px");
		setControllSise(this.lstSchema1, 100, 20);

		lstSchema1.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lstSchema1);

		lstJoinType.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lstJoinType.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		// lstJoinType.setWidth("100px");
		setControllSise(this.lstJoinType, 100, 20);
		lstJoinType.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lstJoinType);

		lstSchema2.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lstSchema2.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		// lstSchema2.setWidth("100px");
		setControllSise(this.lstSchema2, 100, 20);
		lstSchema2.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lstSchema2);

		lbl = new Label("ON");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		// lbl.setWidth("20px");
		setControllSise(lbl, 20, 20);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lstField1.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lstField1.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		// lstField1.setWidth("100px");
		setControllSise(this.lstField1, 100, 20);
		lstField1.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lstField1);

		lbl = new Label(" = ");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		// lbl.setWidth("20px");
		setControllSise(lbl, 20, 20);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lstField2.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lstField2.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		setControllSise(this.lstField2, 100, 20);
		lstField2.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lstField2);
		ImageButton btn = new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_JOIN, "Delete Join Condition", new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				deleteMe();
			}
		}, 20, 20);
		btn.getElement().getStyle().setFloat(Float.LEFT);
		this.add(btn);

		this.lstSchema1.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent ce) {
				schema1Changed();
			}
		});

		this.lstSchema2.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent ce) {
				schema2Changed();
			}
		});

		init(dto);
		this.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
	}

	void deleteMe() {
		this.parent.removeRow(this);
	}

	void setControllSise(Widget wdg, double w, double h) {
		wdg.getElement().getStyle().setWidth(w, Unit.PX);
		wdg.getElement().getStyle().setHeight(h, Unit.PX);
	}

	void init(JoinDto dto) {
		this.lstSchema1.addItem("Select Schema");
		this.lstSchema2.addItem("Select Schema");

		for (SDPWidget w : schemaList) {
			this.lstSchema1.addItem(w.getName());
			this.lstSchema2.addItem(w.getName());
		}

		this.lstJoinType.addItem("Inner", "INNER");
		this.lstJoinType.addItem("Left Outer", "LEFT");
		this.lstJoinType.addItem("Right Outer", "RIGHT");
		this.lstJoinType.addItem("Full Outer", "FULL");

		if (dto != null) {
			for (int i = 0; i < this.lstSchema1.getItemCount(); i++) {
				if (dto.getLeftSchema().equals(this.lstSchema1.getItemText(i))) {
					this.lstSchema1.setSelectedIndex(i);
					String name = this.lstSchema1.getItemText(i);
					for (SDPWidget w : schemaList) {
						if (name.equals(w.getName())) {
							this.lstField1.clear();
							this.lstField1.addItem("Select Field");
							for (ColumnDto f : w.getFields()) {
								this.lstField1.addItem(f.getName());
							}
							break;
						}
					}
					break;
				}
			}

			for (int i = 0; i < this.lstSchema2.getItemCount(); i++) {
				if (dto.getRightSchema().equals(this.lstSchema2.getItemText(i))) {
					this.lstSchema2.setSelectedIndex(i);
					String name = this.lstSchema2.getItemText(i);
					for (SDPWidget w : schemaList) {
						if (name.equals(w.getName())) {
							this.lstField2.clear();
							this.lstField2.addItem("Select Field");
							for (ColumnDto f : w.getFields()) {
								this.lstField2.addItem(f.getName());
							}
							break;
						}
					}
					break;

				}
			}

			for (int i = 0; i < this.lstJoinType.getItemCount(); i++) {
				if (dto.getJoinType().equalsIgnoreCase(this.lstJoinType.getValue(i))) {
					this.lstJoinType.setSelectedIndex(i);
					break;
				}
			}

			for (int i = 0; i < this.lstField1.getItemCount(); i++) {
				if (dto.getLeftColumn().equals(this.lstField1.getItemText(i))) {
					this.lstField1.setSelectedIndex(i);
					break;
				}
			}

			for (int i = 0; i < this.lstField2.getItemCount(); i++) {
				if (dto.getRightColumn().equals(this.lstField2.getItemText(i))) {
					this.lstField2.setSelectedIndex(i);
					break;
				}
			}

		}
	}

	void schema1Changed() {
		if (this.lstSchema1.getSelectedIndex() > 0) {
			String name = this.lstSchema1.getItemText(this.lstSchema1.getSelectedIndex());
			for (SDPWidget w : schemaList) {
				if (name.equals(w.getName())) {
					this.lstField1.clear();
					this.lstField1.addItem("Select Field");
					for (ColumnDto f : w.getFields()) {
						this.lstField1.addItem(f.getName());
					}
					break;
				}
			}
		}
	}

	void schema2Changed() {
		if (this.lstSchema2.getSelectedIndex() > 0) {
			String name = this.lstSchema2.getItemText(this.lstSchema2.getSelectedIndex());
			for (SDPWidget w : schemaList) {
				if (name.equals(w.getName())) {
					this.lstField2.clear();
					this.lstField2.addItem("Select Field");
					for (ColumnDto f : w.getFields()) {
						this.lstField2.addItem(f.getName());
					}
					break;
				}
			}
		}
	}

	public JoinDto getJoinDto() {
		JoinDto dto = new JoinDto();

		if (this.lstSchema1.getSelectedIndex() > 0) {
			dto.setLeftSchema(this.lstSchema1.getItemText(this.lstSchema1.getSelectedIndex()));
		} else {
			Window.alert("Select Schema1");
			return null;
		}
		if (this.lstSchema2.getSelectedIndex() > 0) {
			dto.setRightSchema(this.lstSchema2.getItemText(this.lstSchema2.getSelectedIndex()));
		} else {
			Window.alert("Select Schema2");
			return null;
		}

		if (this.lstField1.getSelectedIndex() > 0) {
			dto.setLeftColumn(this.lstField1.getItemText(this.lstField1.getSelectedIndex()));
		} else {
			Window.alert("Select Field1");
			return null;
		}
		if (this.lstField2.getSelectedIndex() > 0) {
			dto.setRightColumn(this.lstField2.getItemText(this.lstField2.getSelectedIndex()));
		} else {
			Window.alert("Select Field2");
			return null;
		}

		dto.setJoinType(this.lstJoinType.getValue(this.lstJoinType.getSelectedIndex()));

		return dto;
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		if (this.lstSchema1.getSelectedIndex() > 0) {

			json.put("schema1", new JSONString(this.lstSchema1.getItemText(this.lstSchema1.getSelectedIndex())));
		} else {
			Window.alert("Select Schema1");
			return null;
		}
		if (this.lstSchema2.getSelectedIndex() > 0) {

			json.put("schema2", new JSONString(this.lstSchema2.getItemText(this.lstSchema2.getSelectedIndex())));
		} else {
			Window.alert("Select Schema2");
			return null;
		}

		if (this.lstField1.getSelectedIndex() > 0) {

			json.put("field1", new JSONString(this.lstField1.getItemText(this.lstField1.getSelectedIndex())));
		} else {
			Window.alert("Select Filed1");
			return null;
		}
		if (this.lstField2.getSelectedIndex() > 0) {

			json.put("field2", new JSONString(this.lstField2.getItemText(this.lstField2.getSelectedIndex())));
		} else {
			Window.alert("Select Field2");
			return null;
		}

		json.put("join", new JSONString(this.lstJoinType.getValue(this.lstJoinType.getSelectedIndex())));

		return json;
	}
}
