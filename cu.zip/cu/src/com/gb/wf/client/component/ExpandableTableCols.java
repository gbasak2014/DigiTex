package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.CloseEvent;
import com.google.gwt.event.logical.shared.CloseHandler;
import com.google.gwt.event.logical.shared.OpenEvent;
import com.google.gwt.event.logical.shared.OpenHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;

public class ExpandableTableCols {
	JSONObject jsonTbl;
	DisclosurePanel row;

	List<SrcColumn> lstCols = new ArrayList<SrcColumn>();

	String host;
	String db;
	String user;
	String pwd;
	String tableName;
	String dbType;
	String status;
	long id;
	long version;

	TextBox txtDesc = new TextBox();
	long ssId;

	public ExpandableTableCols(JSONObject jsonTbl, long ssId) {
		this.jsonTbl = jsonTbl;
		this.row = new DisclosurePanel();
		this.ssId = ssId;

		Label btnColExp = new Label('\u25BA' + "");
		btnColExp.setTitle("expand/collapse");
		HorizontalPanel hdrPnl = new HorizontalPanel();
		hdrPnl.setWidth("100%");
		hdrPnl.getElement().getStyle().setBorderColor("#0");
		hdrPnl.getElement().getStyle().setBorderWidth(1, Unit.PX);
		try {
			this.id = this.jsonTbl.get("id") != null ? (long) this.jsonTbl.get("id").isNumber().doubleValue() : -1;
			this.version = this.jsonTbl.get("version") != null ? (long) this.jsonTbl.get("version").isNumber().doubleValue() : 0;
			this.host = this.jsonTbl.get("host") != null ? this.jsonTbl.get("host").isString().stringValue() : "";
			this.db = this.jsonTbl.get("db") != null ? this.jsonTbl.get("db").isString().stringValue() : "";
			this.user = this.jsonTbl.get("user") != null ? this.jsonTbl.get("user").isString().stringValue() : "";
			this.pwd = this.jsonTbl.get("pwd") != null ? this.jsonTbl.get("pwd").isString().stringValue() : "";
			this.dbType = this.jsonTbl.get("dbType") != null ? this.jsonTbl.get("dbType").isString().stringValue() : "";
			this.status = this.jsonTbl.get("status") != null ? this.jsonTbl.get("status").isString().stringValue() : "NEW";
			this.txtDesc.setText(this.jsonTbl.get("description") != null ? this.jsonTbl.get("description").isString().stringValue() : "");
			this.tableName = this.jsonTbl.get("tableName") != null ? this.jsonTbl.get("tableName").isString().stringValue() : "";

			hdrPnl.add(btnColExp);
			Label lbl = new Label(this.host + "  ");
			lbl.setWidth("75px");
			hdrPnl.add(lbl);
			lbl = new Label(db);
			lbl.setWidth("75px");
			hdrPnl.add(lbl);
			lbl = new Label(this.tableName + "  ");
			lbl.setWidth("75px");
			hdrPnl.add(lbl);
			lbl = new Label(this.dbType + "  ");
			lbl.setWidth("75px");
			hdrPnl.add(lbl);

			row.setHeader(hdrPnl);
			JSONArray arr = this.jsonTbl.get("columns").isArray();

			int len = arr.size();
			FlexTable tbl = new FlexTable();
			tbl.getElement().getStyle().setBorderColor("#0");
			tbl.getElement().getStyle().setBorderWidth(1, Unit.PX);
			this.txtDesc.setWidth("600px");
			tbl.setText(0, 0, "Description ");
			tbl.getFlexCellFormatter().setColSpan(0, 1, 2);
			tbl.setWidget(0, 1, this.txtDesc);
			tbl.setWidget(0, 3, new Button("Save", new ClickHandler() {
				@Override
				public void onClick(ClickEvent arg0) {
					saveTable();
				}
			}));
			tbl.setText(1, 0, "Position");
			tbl.setText(1, 1, "Name");
			tbl.setText(1, 2, "Data Type");
			tbl.setText(1, 3, "Length");
			tbl.setText(1, 4, "Seisitive");

			for (int r = 0; r < len; r++) {
				this.lstCols.add(new SrcColumn(arr.get(r).isObject(), tbl, r + 2));
			}

			tbl.setHeight((len * 25) + "px");
			tbl.setWidth("1000px");
			row.setContent(tbl);

		} catch (Exception e) {
			Window.alert(e.getMessage());
		}

		btnColExp.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				row.setOpen(!row.isOpen());
			}
		});

		row.addOpenHandler(new OpenHandler<DisclosurePanel>() {

			@Override
			public void onOpen(OpenEvent<DisclosurePanel> arg0) {
				btnColExp.setText('\u25BC' + "");
				btnColExp.setTitle("Collapse");
			}
		});

		row.addCloseHandler(new CloseHandler<DisclosurePanel>() {

			@Override
			public void onClose(CloseEvent<DisclosurePanel> arg0) {
				btnColExp.setText('\u25BA' + "");
				btnColExp.setTitle("Expand");
			}
		});
	}

	public DisclosurePanel getRow() {
		return row;
	}

	void saveTable() {
		JSONObject obj = new JSONObject();
		obj.put("table", this.getJSON());
		obj.put("sourceSystem", new JSONNumber(this.ssId));

		Window.alert(obj.toString());

	}

	public JSONObject getJSON() {
		JSONArray arr = new JSONArray();
		int i = 0;
		for (SrcColumn col : this.lstCols) {
			arr.set(i, col.getJSON());
			i++;
		}

		JSONObject obj = new JSONObject();

		obj.put("id", new JSONNumber(this.id));
		obj.put("version", new JSONNumber(this.version));
		obj.put("description", new JSONString(this.txtDesc.getText()));
		obj.put("host", new JSONString(this.host));
		obj.put("db", new JSONString(this.db));
		obj.put("tableName", new JSONString(this.tableName));
		obj.put("password", new JSONString(this.pwd));
		obj.put("type", new JSONString(this.dbType));
		obj.put("status", new JSONString(this.status));
		obj.put("user", new JSONString(this.user));
		obj.put("columns", arr);

		return obj;
	}
}
