package com.gb.wf.client.component;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Anchor;

public class SDFMenuItem extends Anchor implements SDFCommand {
	int command;

	public SDFMenuItem(String title, int command, ClickHandler clickHandler) {
		super(title);
		this.command = command;
		this.addClickHandler(clickHandler);
		this.setHeight("20px");
	}

	@Override
	public int getCommand() {
		return this.command;
	}
}
