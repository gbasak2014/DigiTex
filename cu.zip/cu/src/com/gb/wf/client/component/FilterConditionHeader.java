package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;

public class FilterConditionHeader extends FlowPanel {
	public FilterConditionHeader() {
		Label lbl = new Label(" ");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("50px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Column");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Condition");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Other");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Value");
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		this.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
	}
}
