package com.gb.wf.client.component;

import com.gb.wf.client.dlg.StartPropDlg;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;

public class ParamRow extends FlowPanel {
	TextBox txtParam = new TextBox();
	ListBox lstType = new ListBox();
	long id;
	
	StartPropDlg parent;
	public ParamRow(long id, String param, String type, StartPropDlg parent) {

		this.parent = parent;
		
		this.txtParam.getElement().getStyle().setWidth(100, Unit.PX);
		this.txtParam.getElement().getStyle().setHeight(20, Unit.PX);
		this.lstType.getElement().getStyle().setWidth(100, Unit.PX);
		this.lstType.getElement().getStyle().setHeight(20, Unit.PX);
		
		
		this.txtParam.getElement().getStyle().setFloat(Float.LEFT);
		this.lstType.getElement().getStyle().setFloat(Float.LEFT);

		this.id = id;
		this.txtParam.setText(param);
		this.lstType.addItem("String", "String");
		this.lstType.addItem("Long", "Long");
		this.lstType.addItem("Double", "Double");
		
		for (int i=0; i<this.lstType.getItemCount(); i++)
		{
			if(this.lstType.getValue(i).equalsIgnoreCase(type))
			{
				this.lstType.setSelectedIndex(i);
				break;
			}
		}
		
		this.add(this.txtParam);
		this.add(this.lstType);
		
		ImageButton btn = new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_JOIN, "Delete Join Condition", new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				deleteMe();
			}
		}, 20, 20);
		btn.getElement().getStyle().setFloat(Float.LEFT);
		this.add(btn);
		
	}

	void deleteMe()
	{
		this.parent.deleteParam(this);
	}
	
	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("id", new JSONNumber(this.id));
		json.put("param", new JSONString(this.txtParam.getText()));
		json.put("type", new JSONString(this.lstType.getValue(this.lstType.getSelectedIndex())));

		return json;
	}

	public String getJSONString() {
		return getJSON().toString();
	}
	
	public long getId()
	{
		return this.id;
	}
	
	public String getParam()
	{
		return this.txtParam.getText();
	}
	public String getParamType()
	{
		return this.lstType.getValue(this.lstType.getSelectedIndex());
	}
}
