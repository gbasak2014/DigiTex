package com.gb.wf.client.component;

import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;

public class JoinConditionHeader extends FlowPanel {
	JoinTable parent;
	public JoinConditionHeader(JoinTable parent) {
		this.parent = parent;
		
		Label lbl = new Label("Schema 1");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Join Type");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		
		lbl = new Label("Schema 2");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);
		
		
		lbl = new Label("ON");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("20px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);
		
		lbl = new Label("Field 1");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);
		
		lbl = new Label(" = ");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("20px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);
		
		lbl = new Label("Field 2");		
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
		lbl.setWidth("100px");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);
		
		
		ImageButton btn = new ImageButton("images/btn-add-row.jpg", SDPButtonActions.ADD_JOIN, "Add Join Condition", new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent arg0) {
				addRow();
			}
		}, 20, 20);
		
		btn.getElement().getStyle().setFloat(Float.LEFT);
		this.add(btn);
		this.getElement().getStyle().setBorderStyle(BorderStyle.NONE);
	}
	
	void addRow()
	{
		this.parent.insertRow();
	}
}
