package com.gb.wf.client.component;

import com.gb.wf.client.handler.PopUpHandler;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SubWf;
import com.google.gwt.core.client.Scheduler.ScheduledCommand;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.MenuItem;
import com.google.gwt.user.client.ui.PopupPanel;

public class SDPPopupMenu extends PopupPanel {
	PopUpHandler designerPage;

	MenuItem miEditor;

	public SDPPopupMenu(PopUpHandler designerPage) {
		super(true, true);
		this.designerPage = designerPage;
		MenuBar menu = new MenuBar(true);
		menu.addItem(new MenuItem("Properties", new ScheduledCommand() {

			@Override
			public void execute() {
				showProperties();
			}
		}));
		menu.addItem(new MenuItem("Delete", new ScheduledCommand() {

			@Override
			public void execute() {
				deleteWidget();
			}
		}));

		this.miEditor = new MenuItem("Edit", new ScheduledCommand() {

			@Override
			public void execute() {
				editStep();
			}
		});
		menu.addItem(this.miEditor);

		this.add(menu);
	}

	public void setSelectedWidget(SDPWidget widget) {
		this.designerPage.setSelectedWidget(widget);
	}

	void showProperties() {
		this.hide();
		this.designerPage.showPropertiesDialog();
	}

	void deleteWidget() {
		this.hide();
		this.designerPage.deleteSelected();
	}

	public void showEdit(boolean show) {
		this.miEditor.setVisible(show);
	}

	void editStep() {
		this.hide();
		SDPWidget w = this.designerPage.getSelectedWidget();
		if (w != null && w.getType() == ComponentTypes.SUB_WF) {
			SubWf sw = (SubWf) w;
			this.designerPage.openEditor(sw.getSubWfId());
		}
	}
}
