package com.gb.wf.client.component;

import com.gb.wf.client.handler.TitleChangeListener;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;

public class SDPTitleBar extends FlowPanel implements ClickHandler, TitleChangeListener {
	Label lblTitle;

	String project = "";
	String wf;

	public SDPTitleBar(String username) {

		this.setStyleName("titlebar");

		this.add(new Label("  "));
		Image img = new Image("images/logo.jpg");
		img.addClickHandler(this);
		img.getElement().getStyle().setFloat(Float.LEFT);
		this.add(img);

		img = new Image("images/spark.jpg");
		img.getElement().getStyle().setProperty("float", "left");
		this.add(img);

		lblTitle = new Label("Project: No Project Selected");
		lblTitle.setStyleName("titleText");
		lblTitle.getElement().getStyle().setFloat(Float.LEFT);
		lblTitle.setWidth("500px");
		this.add(lblTitle);

		Label lbl = new Label("Welcome - " + username + "  ");
		lbl.getElement().getStyle().setFloat(Float.RIGHT);
		this.add(lbl);

	}

	public void setTitle(String text) {
		this.wf = text;
		this.lblTitle.setText("Project: " + this.project + " , Workflow: " + this.wf);
	}

	public void setProject(String project) {
		this.project = project;
		String title = "Project: " + this.project + " , Workflow: " + (this.wf == null ? "New" : this.wf);
		Window.alert(title);
		this.lblTitle.setText(title);
	}

	@Override
	public void onClick(ClickEvent event) {
		DFAboutDialogBox dialogBox = new DFAboutDialogBox();
		dialogBox.setModal(false);
		dialogBox.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dialogBox.setGlassEnabled(true);
		dialogBox.setAnimationEnabled(true);
		dialogBox.center();
		dialogBox.show();
	}

	@Override
	public void titleChanged(String title) {
		this.setTitle(title);
	}
}
