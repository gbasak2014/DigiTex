package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;

public class FilterCondition extends FlowPanel {

	ListBox lstFunction = new ListBox();
	ListBox lstField = new ListBox();
	TextBox txtArgument = new TextBox();

	Label lblLogicalOp;

	public FilterCondition(String op) {
		lstFunction.getElement().getStyle().setFloat(Float.LEFT);
		lstFunction.setWidth("100px");

		lstField.getElement().getStyle().setFloat(Float.LEFT);
		lstField.setWidth("100px");

		txtArgument.getElement().getStyle().setFloat(Float.LEFT);
		txtArgument.setWidth("300px");

		if (op != null && op.length() > 0) {
			lblLogicalOp = new Label(op);
			lblLogicalOp.getElement().getStyle().setFloat(Float.LEFT);
			lblLogicalOp.setWidth("50px");
			this.add(lblLogicalOp);
			this.setSize("560px", "30px");
		} else {
			this.setSize("510px", "30px");
		}

		this.add(lstFunction);
		this.add(txtArgument);
		this.add(lstField);
	}

	void init()
	{
		this.lstFunction.addItem("Select Function");
		this.lstFunction.addItem("Equal(<Valu11>,<Value2>");
		this.lstFunction.addItem("NotEmpty(<Value>)");
		this.lstFunction.addItem("IsNumber(<Value>)");
		this.lstFunction.addItem("IsDate(<Value>, <Format>)");
		this.lstFunction.addItem("DateBetween(<Value>,<format>,<Start Date>,<End Date>)");
		this.lstFunction.addItem("NumberBetwen(<value>,<Start Number>,<End Number>)");
	}
	
	public String getFunction() {
		int idx = this.lstFunction.getSelectedIndex();
		if (idx > 0) {
			return this.lstFunction.getItemText(idx);
		}

		return null;
	}

	public String getArcguments() {
		return this.txtArgument.getText();
	}

	public String getLogicalOp() {
		if (this.lblLogicalOp != null) {
			return this.lblLogicalOp.getText();
		}

		return null;
	}
}
