package com.gb.wf.client.dto;

public class TransformationDto {
	int index;
	String function;
	String fieldName;

	public TransformationDto(int index, String function, String fieldName) {
		this.index = index;
		this.function = function;
		this.fieldName = fieldName;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

}
