package com.gb.wf.client.dto;

public class OrderDto {
	String field;
	String order;

	public OrderDto() {
	}

	public OrderDto(String field) {
		this(field, "ASC");
	}

	public OrderDto(String field, String order) {
		this.field = field;
		this.order = order;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}
