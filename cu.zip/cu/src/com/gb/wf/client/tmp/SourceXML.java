package com.gb.wf.client.tmp;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceXML extends SDPWidget {
	String rootElement;

	public SourceXML(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-xml.jpg", "SourceJSON", ComponentTypes.SOURCE_XML, ComponentTypes.SOURCE_XML, popupMenu, clickHandler);
	}

	public String getRootElement() {
		return rootElement;
	}

	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("root", new JSONString(this.getRootElement()));

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return null;
	}
}
