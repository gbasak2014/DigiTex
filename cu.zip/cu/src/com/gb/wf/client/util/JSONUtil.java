package com.gb.wf.client.util;

import com.google.gwt.json.client.JSONObject;

public class JSONUtil {
	public static String getEmptyIfNull(String key, JSONObject obj) {

		try {
			return obj.get(key).isString().stringValue();
		} catch (Exception e) {
		}

		return "";
	}
}
