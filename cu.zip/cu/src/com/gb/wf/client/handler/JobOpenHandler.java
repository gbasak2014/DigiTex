package com.gb.wf.client.handler;

public interface JobOpenHandler{
	public void openJob(long jobId);
}
