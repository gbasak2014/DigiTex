package com.gb.wf.client.handler;

import com.google.gwt.json.client.JSONObject;

public interface MdmReqHandler {
	void getSourceData(JSONObject json);
	void processFileMeta(String data);
}
