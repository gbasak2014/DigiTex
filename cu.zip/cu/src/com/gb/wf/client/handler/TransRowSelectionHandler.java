package com.gb.wf.client.handler;

import com.gb.wf.client.component.TransformationRow;

public interface TransRowSelectionHandler {
	void rowSelected(TransformationRow row);
}
