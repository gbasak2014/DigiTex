package com.gb.wf.client.handler;

import com.gb.wf.client.widget.SDPWidget;

public interface PopUpHandler {
	public void setSelectedWidget(SDPWidget widget);

	void showPropertiesDialog();

	void deleteSelected();

	void openEditor(long id);

	SDPWidget getSelectedWidget();
}
