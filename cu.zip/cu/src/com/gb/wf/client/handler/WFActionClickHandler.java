package com.gb.wf.client.handler;

import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;

public class WFActionClickHandler implements ClickHandler {
	PopUpHandler designerPage;
	SDPWidget previousBtn;
	String borderColor;
	String borderWidth;

	public WFActionClickHandler(PopUpHandler designerPage) {
		this.designerPage = designerPage;
	}

	@Override
	public void onClick(ClickEvent event) {
		SDPWidget btn = (SDPWidget) event.getSource();
		if (btn != null && !btn.equals(previousBtn)) {
			if (this.previousBtn != null) {
				this.previousBtn.getElement().getStyle().setBorderColor(this.borderColor);
				this.previousBtn.getElement().getStyle().setBorderWidth(1, Unit.PX);
				this.previousBtn.getElement().getStyle().setBackgroundColor("#ffffff");
			}

			this.previousBtn = btn;
			this.borderColor = btn.getElement().getStyle().getBorderColor();
			this.borderWidth = btn.getElement().getStyle().getBorderWidth();

			btn.getElement().getStyle().setBorderColor("#ff0000");
			btn.getElement().getStyle().setBorderWidth(2, Unit.PX);
			btn.getElement().getStyle().setBackgroundColor("#00ffff");
			this.designerPage.setSelectedWidget(btn);
		}
	}
}
