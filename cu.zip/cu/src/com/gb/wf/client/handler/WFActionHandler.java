package com.gb.wf.client.handler;

import java.util.List;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.DFAboutDialogBox;
import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.component.OptionWindow;
import com.gb.wf.client.component.SDFCommand;
import com.gb.wf.client.component.WFDesignerPage;
import com.gb.wf.client.dlg.AddProjectDlg;
import com.gb.wf.client.dlg.AddUserDlg;
import com.gb.wf.client.dlg.CreateSourceSystemDlg;
import com.gb.wf.client.dlg.ExecuteWfDlg;
import com.gb.wf.client.dlg.JobDetailDlg;
import com.gb.wf.client.dlg.OpenWfDlg;
import com.gb.wf.client.dlg.ResizeDlg;
import com.gb.wf.client.dlg.ServiceAddDlg;
import com.gb.wf.client.dlg.SourceMetaDlg;
import com.gb.wf.client.dlg.ViewProjectDlg;
import com.gb.wf.client.dlg.ViewSourceSystemDlg;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.CustomAction;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Start;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Handle Menu Item click event
 * 
 * @author Gouranga Basak
 *
 */
public class WFActionHandler implements ClickHandler {
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	WFDesignerPage designerPage;

	public WFActionHandler(WFDesignerPage designerPage) {
		this.designerPage = designerPage;
	}

	@Override
	public void onClick(ClickEvent event) {
		OptionWindow optionWindow;
		SDFCommand btn = (SDFCommand) event.getSource();
		switch (btn.getCommand()) {
		// File Menu Start
		case DFConstants.WF_NEW:
			this.designerPage.newWorkflow();
			break;
		case DFConstants.SWF_NEW:
			this.designerPage.newSubWorkflow();
			break;
		case DFConstants.WF_OPEN:
			this.openWorkflow(true);
			break;
		case DFConstants.SWF_OPEN:
			this.openWorkflow(false);
			break;
		case DFConstants.SELECT_PROJECT:
			openViewProjectWin();
			break;
		case DFConstants.WF_SAVE:
			if (WFDesignerPage.TYPE_WF != this.designerPage.getWFType()) {
				Window.alert("You can not save 'Sub Workflow' As 'Workflow', please save as 'Sub Workflow'!!");
				return;
			}
			this.saveWorkflow(false);
			break;
		case DFConstants.SWF_SAVE:
			if (WFDesignerPage.TYPE_SUB_WF != this.designerPage.getWFType()) {
				Window.alert("You can not save 'Workflow' As 'Sub Workflow', please save as 'Workflow'!!");
				return;
			}
			this.saveWorkflow(true);
			break;
		// File Menu End
		case DFConstants.WF_VIEW:
			optionWindow = new OptionWindow(OptionWindow.OPTION_OPEN);
			optionWindow.show(this);
			break;
		// Service Menu Start
		case DFConstants.ADD_COMMON_SERVICES:
			openCommonServiceDlg();
			break;
		case DFConstants.ADD_UDF:
			openUDFDlg();
			break;
		case DFConstants.OPEN_COMMON_SERVICES:
			Window.alert("Open Common Service");
			break;
		case DFConstants.OPEN_UDF:
			Window.alert("Open UDF");
			break;
		// Service Menu End
		// Workflow Menu Start
		case DFConstants.WF_COMPILE:
			this.compileWorkflow();
			break;
		case DFConstants.WF_RUN:
			openExecuteWorkflow();
			break;
		// Workflow Menu End
		// View Menu Start
		case DFConstants.WF_RESIZE:
			resizeDesign();
			break;
		case DFConstants.WF_GRID:
			showHideGrid();
			break;
		case DFConstants.SHOW_DESIN_TOOL:
			showHideDesignTool();
			break;
		// View Menu End
		// Administrator Menu Start
		case DFConstants.ADD_PROJECT:
			addProject();
			break;
		case DFConstants.ADD_USER:
			addUser();
			break;
		// Administrator Menu End
		// Meta Data Menu Start
		case DFConstants.ADD_META:
			addMeta();
			break;
		case DFConstants.VIEW_SOURCE:
			viewSourceSystem();
			break;
		// Meta Data Menu end
		// Navigate Start
		case DFConstants.PREVIOUS:
			long prvId = this.designerPage.getPreviousId();
			if (prvId > 0) {
				this.openWorkflow(prvId);
				this.designerPage.saveCurrentId(prvId);
			}
			break;
		case DFConstants.NEXT:
			Window.alert("Next ....");
			break;
		// Navigate End
		// Help Start
		case DFConstants.HELP:
			Window.alert("Helo comin soon!!");
			break;
		case DFConstants.ABOUT:
			showAbout();
			break;
		}
	}

	void showAbout() {
		DFAboutDialogBox dialogBox = new DFAboutDialogBox();
		dialogBox.setModal(false);
		dialogBox.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dialogBox.setGlassEnabled(true);
		dialogBox.setAnimationEnabled(true);
		dialogBox.center();
		dialogBox.show();
	}

	void showHideDesignTool() {
		this.designerPage.showHideDrawingTool();
	}

	void openViewProjectWin() {
		ViewProjectDlg dlg = new ViewProjectDlg(this.designerPage);
		dlg.setTitle("Project Select");
		dlg.setModal(true);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void viewSourceSystem() {
		try {
			long pId = this.designerPage.getSelectedProjectId();
			this.service.getSourceSystems(pId, new AsyncCallback<String>() {

				@Override
				public void onSuccess(String data) {
					openSSDlg(data);
				}

				@Override
				public void onFailure(Throwable e) {
					Window.alert(e.getMessage());
				}
			});

		} catch (Exception e) {
			Window.alert(e.getMessage());
		}
	}

	void openSSDlg(String data) {
		JSONObject resp = JSONParser.parseStrict(data).isObject();
		if ("SUCCESS".equalsIgnoreCase(resp.get("status").isString().stringValue())) {
			ViewSourceSystemDlg dlg = new ViewSourceSystemDlg(resp.get("data").isArray(), this);
			dlg.setModal(false);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.setGlassEnabled(true);
			dlg.setAnimationEnabled(true);
			dlg.center();
			dlg.show();
		} else {
			Window.alert(resp.get("data").isString().stringValue());
		}

	}

	void openCommonServiceDlg() {
		try {
			long projectId = this.designerPage.getSelectedProjectId();
			ServiceAddDlg dlg = new ServiceAddDlg(new CustomAction(null, null), this.designerPage, ServiceAddDlg.SERVICE, projectId);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.center();
			dlg.show();
		} catch (Exception e) {
			Window.alert("Please select project!!");
		}
	}

	void openUDFDlg() {
		try {
			long projectId = this.designerPage.getSelectedProjectId();
			ServiceAddDlg dlg = new ServiceAddDlg(new CustomAction(null, null), this.designerPage, ServiceAddDlg.UDF, projectId);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.center();
			dlg.show();
		} catch (Exception e) {
			Window.alert("Please select project!!");
		}
	}

	void showHideGrid() {
		designerPage.getDrawingController().getDiagramController().showGrid(!designerPage.getDrawingController().getDiagramController().isShowGrid());
	}

	void resizeDesign() {
		int w = designerPage.getDrawingController().getDiagramController().getCanvasWidth();
		int h = designerPage.getDrawingController().getDiagramController().getCanvasHeight();

		ResizeDlg dlg = new ResizeDlg("Resize Design", w, h);
		dlg.setTitle("Transformation");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();

		w = dlg.getNewWidth();
		h = dlg.getNewHeight();
		if (w > 0) {
			designerPage.getDrawingController().getDiagramController().getDiagramCanvas().setWidth(w);
			designerPage.getDrawingController().getDiagramController().getDiagramCanvas().setHeight(h);
		}
	}

	void saveWorkflow() {
		boolean input = Window.confirm("Save as Sub Workflow?");
		this.designerPage.showProgress("Saving Workflow....");
		this.service.saveWorkflow(this.getJobJson(input), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();
				if (!"SUCCESS".equalsIgnoreCase(jo.get("status").isString().stringValue())) {
					Window.alert("Error saving job!!!");
				} else {
					designerPage.processOpenWorkFlow(jo.toString());
				}

				designerPage.stopProgress();
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("Error....");
			}
		});
	}

	public void saveWorkflow(boolean isSubWorkflow) {
		this.designerPage.showProgress("Saving Workflow....");
		this.service.saveWorkflow(this.getJobJson(isSubWorkflow), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();
				if (!"SUCCESS".equalsIgnoreCase(jo.get("status").isString().stringValue())) {
					Window.alert("Error saving job!!!");
				} else {
					designerPage.processOpenWorkFlow(jo.toString());
				}

				designerPage.stopProgress();
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("Error....");
			}
		});
	}

	void saveAsWorkflow() {
		boolean input = Window.confirm("Save as Sub Workflow?");
		this.service.saveWorkflow(this.getJobJson(input), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();

				Window.alert(jo.get("data").isString().stringValue());
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Error....");
			}
		});
	}

	void viewWorkflow(boolean isJob) {
		long prgId = 0;
		try {
			prgId = this.designerPage.getSelectedProjectId();

		} catch (Exception e) {
			Window.alert("Select Project!!");
			return;
		}

		this.service.getJobs(isJob, prgId, new AsyncCallback<String>() {

			@Override
			public void onSuccess(String jobs) {

				if ("ERROR".equals(jobs)) {
					Window.alert(jobs);
				} else {
					openJobDtlDlg(jobs);
				}
			}

			@Override
			public void onFailure(Throwable t) {
				Window.alert("ERROR getting job details: " + t.getMessage());
			}
		});
	}

	public void openWorkflow(boolean isJob) {
		try {
			long pId = this.designerPage.getSelectedProjectId();
			String pName = this.designerPage.getSelectedProjectName();

			OpenWfDlg dlg = new OpenWfDlg(this, pId, "Please enter Job Name for Project: " + pId + " - " + pName, isJob);
			dlg.setTitle("Message Box");
			dlg.setModal(true);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.center();
			dlg.show();
		} catch (Exception e) {
			Window.alert("ERROR: " + e.getMessage());
		}
	}

	void openJobDtlDlg(String jobs) {
		JobDetailDlg dlg = new JobDetailDlg(this, jobs);
		dlg.setTitle("Job Detils");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void compileWorkflow() {
		this.designerPage.showProgress("Compiling workflow......");
		this.service.compileJob(this.getJobJson(false), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String msg) {
				designerPage.stopProgress();
				Window.alert("Success>>" + msg);
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("...Error...");
			}
		});
	}

	public void openWorkflow(long wfId) {
		this.designerPage.showProgress("Opening workflow....");

		this.service.openWorkflow(String.valueOf(wfId), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String json) {
				designerPage.processOpenWorkFlow(json);
				designerPage.stopProgress();
			}

			@Override
			public void onFailure(Throwable err) {
				designerPage.stopProgress();
				Window.alert(err.getMessage());
			}
		});
	}

	public void openWorkflow(long projectId, String wfId) {
		this.service.openWorkflow(wfId, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String json) {
				designerPage.processOpenWorkFlow(json);
			}

			@Override
			public void onFailure(Throwable err) {
				Window.alert(err.getMessage());
			}
		});
	}

	private String getJobJson(boolean subWorkflow) {
		JSONObject jsonRoot = new JSONObject();
		int paneLeft = this.designerPage.getDrawingController().getAbsoluteLeft();
		int paneTop = this.designerPage.getDrawingController().getAbsoluteTop();

		List<SDPWidget> list = this.designerPage.getDrawingController().getWidgets();
		for (SDPWidget w : list) {
			int l = w.getAbsoluteLeft() - paneLeft;
			int t = w.getAbsoluteTop() - paneTop;
			w.setPosition(l, t);

			try {
				if (w.getType() == ComponentTypes.START) {
					jsonRoot.put("start", w.getJSON());
				} else if (w.getType() == ComponentTypes.END) {
					jsonRoot.put("end", w.getJSON());
				} else {
					jsonRoot.put(w.getName(), w.getJSON());
				}
			} catch (Exception e) {
				Window.alert("ERROR for '" + w.getName() + "' - " + e.getMessage());
			}
		}

		if (subWorkflow) {
			jsonRoot.put("type", new JSONString("SUB_WORKFLOW"));
		} else {
			jsonRoot.put("type", new JSONString("JOB"));
		}

		return jsonRoot.toString();
	}

	public String getJobJson(JSONObject cluster, JSONObject param) {
		JSONObject jsonRoot = new JSONObject();
		int paneLeft = this.designerPage.getDrawingController().getAbsoluteLeft();
		int paneTop = this.designerPage.getDrawingController().getAbsoluteTop();

		List<SDPWidget> list = this.designerPage.getDrawingController().getWidgets();
		for (SDPWidget w : list) {
			int l = w.getAbsoluteLeft() - paneLeft;
			int t = w.getAbsoluteTop() - paneTop;
			w.setPosition(l, t);

			try {
				if (w.getType() == ComponentTypes.START) {
					jsonRoot.put("start", w.getJSON());
				} else if (w.getType() == ComponentTypes.END) {
					jsonRoot.put("end", w.getJSON());
				} else {
					jsonRoot.put(w.getName(), w.getJSON());
				}
			} catch (Exception e) {
				Window.alert("ERROR for '" + w.getName() + "' - " + e.getMessage());
			}
		}

		jsonRoot.put("cluster", cluster);

		if (param != null) {
			jsonRoot.put("parameters", param);
		}
		return jsonRoot.toString();
	}

	private void addUser() {
		AddUserDlg dlg = new AddUserDlg(this.designerPage.getUser());
		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	private void addProject() {
		AddProjectDlg dlg = new AddProjectDlg(designerPage);
		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	private void addMeta() {
		if (this.designerPage.getSelectedProjectId() <= 0) {
			Window.alert("Please select Project!!");
			return;
		}

		long projectId = this.designerPage.getSelectedProjectId();
		String prgNm = this.designerPage.getSelectedProjectName();

		CreateSourceSystemDlg dlg = new CreateSourceSystemDlg(projectId, prgNm, null);

		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	public void editSs(long ssId) {
		this.service.getSourceSystemDetail(ssId, new AsyncCallback<String>() {

			@Override
			public void onSuccess(String data) {
				openEditSs(data);
			}

			@Override
			public void onFailure(Throwable e) {
				Window.alert(e.getMessage());
			}
		});
	}

	void openEditSs(String data) {
		JSONObject obj = JSONParser.parseStrict(data).isObject();

		if ("SUCCESS".equalsIgnoreCase(obj.get("status").isString().stringValue())) {
			JSONObject ss = obj.get("data").isObject();

			long projectId = this.designerPage.getSelectedProjectId();
			String prgNm = this.designerPage.getSelectedProjectName();

			CreateSourceSystemDlg dlg = new CreateSourceSystemDlg(projectId, prgNm, ss);

			dlg.setModal(false);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.setGlassEnabled(true);
			dlg.setAnimationEnabled(true);
			dlg.center();
			dlg.show();
		} else {
			Window.alert(obj.get("data").isString().stringValue());
		}
	}

	private void addMetaBAK() {
		try {
			final long projectId = this.designerPage.getSelectedProjectId();

			if (this.designerPage.getSourceType().size() <= 0 || this.designerPage.getRecordType().size() <= 0 || this.designerPage.getDataType().size() <= 0) {
				this.service.getSourceConfig(new AsyncCallback<String>() {
					@Override
					public void onSuccess(String data) {
						refreshMetaList(data);
						openSourceMetaDlg(projectId);
					}

					@Override
					public void onFailure(Throwable arg0) {
						Window.alert("Server ERROR!!!");
					}
				});
			} else {
				openSourceMetaDlg(projectId);
			}

		} catch (Exception e) {
			Window.alert("ERROR:" + e.getMessage());
			return;
		}
	}

	void refreshMetaList(String data) {
		JSONObject json = JSONParser.parseStrict(data).isObject();

		List<String> srcType = this.designerPage.getSourceType();
		List<String> recType = this.designerPage.getRecordType();
		List<String> dtType = this.designerPage.getDataType();

		srcType.clear();
		recType.clear();
		dtType.clear();

		JSONArray arr = json.get("sourceTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			srcType.add(arr.get(i).isString().stringValue());
		}

		arr = json.get("recordTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			recType.add(arr.get(i).isString().stringValue());
		}

		arr = json.get("dataTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			dtType.add(arr.get(i).isString().stringValue());
		}
	}

	void openSourceMetaDlg(long projectId) {

		SourceMetaDlg dlg = new SourceMetaDlg(projectId, this.designerPage.getSourceType(), this.designerPage.getRecordType(), this.designerPage.getDataType());
		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	void openExecuteWorkflow() {
		try {
			ProjectDto p = this.designerPage.getSelectedProject();
			Start start = this.designerPage.getDrawingController().getStartNode();
			if (start != null) {
				ExecuteWfDlg dlg = new ExecuteWfDlg(this, p, start, start, ExecuteWfDlg.EXECUTE_WF);
				dlg.setModal(false);
				dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
				dlg.setGlassEnabled(true);
				dlg.setAnimationEnabled(true);
				dlg.center();
				dlg.show();
			} else {
				Window.alert("Please add start node!!");
			}
		} catch (Exception e) {
			Window.alert("Error!!!" + e.getMessage());
		}
	}

	public void requestExecuteWorkflow(String json) {
		this.service.executeJob(json, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();

				Window.alert(jo.get("data").isString().stringValue());
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server Communication Error....");
			}
		});

	}

	public WFDesignerPage getDesignerPage() {
		return this.designerPage;
	}
}
