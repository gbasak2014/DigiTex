package com.gb.wf.client.handler;

import com.google.gwt.user.client.ui.Widget;

public interface RowDeleteHandler {
	void deleteRow(Widget widget);
}
