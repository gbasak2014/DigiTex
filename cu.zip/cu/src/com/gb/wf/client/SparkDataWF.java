package com.gb.wf.client;

import com.gb.wf.client.component.LoginPanel;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.RootPanel;

//com.gb.wf.client.SparkDataWF
public class SparkDataWF implements EntryPoint {
	private static final String SERVER_ERROR = "An error occurred while " + "attempting to contact the server. Please check your network "
			+ "connection and try again.";

	//private final GreetingServiceAsync greetingService = GWT.create(GreetingService.class);

	public void onModuleLoad() {
		RootPanel.get().add(new LoginPanel());
		// RootPanel.get().add(new WFDesignerPage("Design Spark Workflow"));
	}
}
