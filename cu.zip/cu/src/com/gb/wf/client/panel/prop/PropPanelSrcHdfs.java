package com.gb.wf.client.panel.prop;

public class PropPanelSrcHdfs {

}
