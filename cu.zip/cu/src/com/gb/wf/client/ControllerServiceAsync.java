package com.gb.wf.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface ControllerServiceAsync {
	void processRequest(String service, String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void openWorkflow(String workflowId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void openWorkflow(long projectId, String workflowName, AsyncCallback<String> callback) throws IllegalArgumentException;

	void registerUser(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void loginUser(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void addUser(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void addProject(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void saveSourceMetaDate(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSourceConfig(AsyncCallback<String> callback) throws IllegalArgumentException;

	void getProjectSources(long id, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSourceList(long id, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getDBSourceList(long id, AsyncCallback<String> callback) throws IllegalArgumentException;

	void saveWorkflow(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getJobs(boolean isJob, long projectId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSubWfs(long projectId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void compileJob(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void executeJob(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void saveService(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getServiceList(long projectId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getUDFList(long projectId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getServiceDetail(long serviceId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSubWf(long sWfId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSubWfHeader(long sWfId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSourceSystems(long projectId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getSourceSystemDetail(long ssId, AsyncCallback<String> callback) throws IllegalArgumentException;

	void saveSourceSystem(String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void saveSourceTables(String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void saveSourceFiles(String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void listTables(String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getTableStruct(String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void getAllTablesStruct(String data, AsyncCallback<String> callback) throws IllegalArgumentException;

	void test(String data, AsyncCallback<String> callback) throws IllegalArgumentException;
}
