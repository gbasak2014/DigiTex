package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.widget.Filter;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class FilterPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	Filter widget;
	
	ListBox lstColumn1 = new ListBox();
	ListBox lstColumn2 = new ListBox();
	ListBox lstCondition = new ListBox();
	TextBox txtOtherColumn1 = new TextBox();
	TextBox txtOtherColumn2 = new TextBox();
	
	TextArea taFilter = new TextArea();
	List<ParamDto> params;
	
	public FilterPropDlg(SDPWidget widget, List<ParamDto> params) {
		super(false, false);
		this.widget = (Filter) widget;
		this.params = params;
		
		this.setSize("750px", "400px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Filter Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "400px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		txtName.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(txtName);
		vpn.add(fp);
		
		fp = new FlowPanel();
		Button btn = new Button("AND");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addAnd();
			}
		});
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		btn = new Button("OR");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addOr();
			}
		});		
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		btn = new Button(" ( ");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addLeftBrach();
			}
		});		
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		btn = new Button(" ) ");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addRightBrach();
			}
		});		
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		
		this.lstColumn1.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(this.lstColumn1);
		this.txtOtherColumn1.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(this.txtOtherColumn1);
		this.lstCondition.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(this.lstCondition);
		this.lstColumn2.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(this.lstColumn2);
		this.txtOtherColumn2.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(this.txtOtherColumn2);
		this.txtOtherColumn1.getElement().getStyle().setWidth(60, Unit.PX);
		this.txtOtherColumn2.getElement().getStyle().setWidth(60, Unit.PX);
		btn = new Button("Add Condition");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addCondition();
			}
		});		
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		
		vpn.add(fp);
		dp.addNorth(vpn, 60);
		dp.add(this.taFilter);
		this.taFilter.setVisibleLines(5);
		this.taFilter.getElement().getStyle().setWidth(700, Unit.PX);
		
		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void addAnd() {
		
		
		this.taFilter.setText(this.taFilter.getText() + " AND ");
	}

	void addOr() {
		this.taFilter.setText(this.taFilter.getText() + " OR ");
	}

	void addLeftBrach()
	{
		this.taFilter.setText(this.taFilter.getText() + " ( ");
	}
	
	void addRightBrach()
	{
		this.taFilter.setText(this.taFilter.getText() + " ) ");
	}
	
	void addConditionText(int pos, String txt)
	{
		String cnd = this.taFilter.getText();
		int len = cnd.length();
		if (pos >= len)
		{
			this.taFilter.setText(cnd + txt);
		}
		else
		{
			String txt1 = cnd.substring(0,pos);
			String txt2 = cnd.substring(pos);
			this.taFilter.setText(txt1 + txt + txt2); 
		}
	}
	
	void addCondition()
	{
		int idx1 = this.lstColumn1.getSelectedIndex();
		int idx2 = this.lstColumn2.getSelectedIndex();
		String col1=null;
		String col2=null;
		
		if (idx1 > 0 && idx1 < (this.lstColumn1.getItemCount() - 1))
		{
			col1 = "$" + this.lstColumn1.getItemText(idx1);
		}
		else if (idx1 > 0 && this.txtOtherColumn1.getText().trim().length() > 0)
		{
			col1 = this.txtOtherColumn1.getText().trim();
		}
		
		if (idx2 > 0 && idx2 < (this.lstColumn2.getItemCount() - 1))
		{
			col2 = "$" + this.lstColumn2.getItemText(idx2);
		}
		else if (idx2 > 0 && this.txtOtherColumn2.getText().trim().length() > 0)
		{
			col2 = this.txtOtherColumn2.getText().trim();
		}
		
		if (col1 == null || col2 == null)
		{
			Window.alert("Please select column...");
			return;
		}		
		
		String lgOp = this.lstCondition.getItemText(this.lstCondition.getSelectedIndex());
		String cnd = col1 + " " + lgOp + " " + col2;
		if (this.taFilter.getText().trim().length() > 0)
		{
			cnd = this.taFilter.getText().trim() + " " + cnd;
		}
		
		this.taFilter.setText(cnd);
	}
	
	void initComponens() {
		this.lstColumn1.addItem("Select Column");
		this.lstColumn2.addItem("Select Column");
		for (ColumnDto cd : this.widget.getPredecessors().get(0).getFields())
		{
			this.lstColumn1.addItem(cd.getName());
			this.lstColumn2.addItem(cd.getName());
		}
		
		for (ParamDto p : this.params)
		{
			this.lstColumn2.addItem("param." + p.getParam());
		}
		
		this.lstColumn1.addItem("Other");
		this.lstColumn2.addItem("Other");
		
		this.lstCondition.addItem("=");
		this.lstCondition.addItem("<");
		this.lstCondition.addItem(">");
		this.lstCondition.addItem("<=");
		this.lstCondition.addItem(">=");
		this.lstCondition.addItem("IN");
		this.lstCondition.addItem("Contains");
		this.lstCondition.addItem("StartWith");
		this.lstCondition.addItem("EndWith");
		this.lstCondition.addItem("IsNull");
		this.lstCondition.addItem("IsNotNull");
		
		this.txtName.setText(this.widget.getName());
		this.taFilter.setText(this.widget.getConditions());
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		this.widget.setConditions(this.taFilter.getText());
		this.widget.setFields(this.widget.getPredecessors().get(0).getFields());
		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
