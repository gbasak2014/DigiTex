package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SourceKafka;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class SourceKafkaPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtBrokers = new TextBox();
	TextBox txtTopics = new TextBox();
	TextBox txtInterval = new TextBox();

	TextArea taFields = new TextArea();
	ListBox lstFields = new ListBox();

	TextBox txtDelimiter = new TextBox();
	Label lblDElimiter = new Label("Record Element");

	ListBox lstRecType = new ListBox();

	SDPWidget widget;

	public SourceKafkaPropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("700px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Kafka Source Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("700px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtName);

		lbl = new Label("Batch Interval:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtInterval.setStyleName("textBox");
		this.txtInterval.setWidth("50px");
		this.txtInterval.setTitle("Batch Interval in Second");
		hp.add(lbl);
		hp.add(this.txtInterval);

		hp.add(lstRecType);
		lblDElimiter.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtDelimiter.setStyleName("textBox");
		this.txtDelimiter.setWidth("100px");
		this.txtDelimiter.setTitle("Field delimiter/XML Record Element");
		hp.add(lblDElimiter);
		hp.add(this.txtDelimiter);

		dp.addNorth(hp, 35);

		dp.addNorth(new Label("Brokers (comma separated)"), 25);
		txtBrokers.setWidth("580px");
		dp.addNorth(txtBrokers, 30);
		dp.addNorth(new Label("Topics (comma separated)"), 25);
		txtTopics.setWidth("580px");
		dp.addNorth(txtTopics, 30);

		lbl = new Label("Comma (,) separated fields name");
		this.taFields.setSize("580px", "50px");
		dp.addNorth(lbl, 25);
		dp.addNorth(this.taFields, 75);

		Button btn = new Button("Add Fields to List");
		btn.setSize("200px", "25px");
		btn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processFields();
			}
		});

		dp.addNorth(btn, 25);

		dp.addNorth(new Label("Fields in Source"), 20);
		this.lstFields.setSize("100px", "200px");
		this.lstFields.setVisibleItemCount(20);
		dp.addNorth(this.lstFields, 200);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);

		lstRecType.addItem("Select Record Type");
		lstRecType.addItem("Delimited");
		lstRecType.addItem("XML");
		lstRecType.addItem("JSON");

		this.initComponens();

		lstRecType.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				recordTypeChanged();
			}
		});
	}

	void recordTypeChanged() {
		int idx = lstRecType.getSelectedIndex();
		if (idx == 1) {
			this.lblDElimiter.setText("Delimiter:");
			this.txtDelimiter.setEnabled(true);
		} else if (idx == 2) {
			this.lblDElimiter.setText("Record Element:");
			this.txtDelimiter.setEnabled(true);
		} else {
			this.lblDElimiter.setText("");
			this.txtDelimiter.setEnabled(false);
		}
	}

	void initComponens() {
		SourceKafka sk = (SourceKafka) this.widget;
		this.txtName.setText(sk.getName());
		this.txtDelimiter.setText(sk.getDelimiter());
		this.txtBrokers.setText(sk.getBrokers());
		this.txtTopics.setText(sk.getTopics());
		this.txtInterval.setText(String.valueOf(sk.getInterval()));

		StringBuffer buff = new StringBuffer();
		if (sk.getFields() != null && sk.getFields().size() > 0) {
			for (int i = 0; i < sk.getFields().size(); i++) {
				this.lstFields.addItem(sk.getFields().get(i).getName());
				if (i > 0) {
					buff.append(",");
				}
				buff.append(sk.getFields().get(i));
			}
		}

		int cnt = this.lstRecType.getItemCount();
		for (int i = 0; i < cnt; i++) {
			if (sk.getRecordType().equals(this.lstRecType.getItemText(i))) {
				this.lstRecType.setSelectedIndex(i);
				break;
			}
		}

		this.taFields.setText(buff.toString());
	}

	void processOk() {
		SourceKafka sk = (SourceKafka) this.widget;
		sk.setName(this.txtName.getText());
		sk.setDelimiter(txtDelimiter.getText());
		sk.setInterval(Integer.parseInt(txtInterval.getText()));
		sk.setBrokers(txtBrokers.getText());
		sk.setTopics(txtTopics.getText());

		List<ColumnDto> lst = new ArrayList<ColumnDto>();
		for (int i = 0; i < this.lstFields.getItemCount(); i++) {
			ColumnDto dto = new ColumnDto();
			dto.setName(this.lstFields.getItemText(i));
			lst.add(dto);
		}

		int idx = this.lstRecType.getSelectedIndex();
		sk.setRecordType(this.lstRecType.getItemText(idx));

		sk.setFields(lst);

		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void processFields() {
		String[] fields = this.taFields.getText().split(",");
		this.lstFields.clear();

		for (String field : fields) {
			this.lstFields.addItem(field);
		}
	}
}
