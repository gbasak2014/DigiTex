package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SourceHive;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class SourceHivePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtSchema = new TextBox();
	TextBox txtTable = new TextBox();

	TextArea taFields = new TextArea();
	ListBox lstFields = new ListBox();
	
	TextArea taCondition = new TextArea();
	
	SDPWidget widget;

	public SourceHivePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("500px", "650px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Hive Source Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("500px", "650px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");

		hp.add(lbl);
		hp.add(this.txtName);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Schema:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtSchema.setWidth("100px");
		this.txtSchema.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtSchema);
		lbl = new Label("Table:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtTable.setWidth("100px");
		this.txtTable.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtTable);
		dp.addNorth(hp, 30);

		lbl = new Label("Comma (,) separated fields name");
		this.taFields.setSize("490px", "50px");
		dp.addNorth(lbl, 25);
		dp.addNorth(this.taFields, 75);

		Button btn = new Button("Add Fields to List");
		btn.setSize("200px", "25px");
		btn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processFields();
			}
		});

		dp.addNorth(btn, 25);

		VerticalPanel vp = new VerticalPanel();
		vp.add(new Label("Fields in Source"));
		this.lstFields.setSize("100px", "200px");
		this.lstFields.setVisibleItemCount(20);
		vp.add(this.lstFields);
		btn = new Button("Remove Field", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				removeField();
			}
		});
		vp.add(btn);
		dp.addWest(vp,150);
		
		
		
		vp = new VerticalPanel();
		lbl = new Label("Specify conditon to pull data");
		this.taCondition.setSize("450px", "200px");
		vp.add(lbl);
		vp.add(this.taCondition);
		dp.add(vp);
		
		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		SourceHive sh = (SourceHive) this.widget;
		this.txtName.setText(sh.getName());
		this.txtSchema.setText(sh.getSchema());
		this.txtTable.setText(sh.getTableName());
		this.taCondition.setText(sh.getCondition());

		StringBuffer buff = new StringBuffer();
		if (sh.getFields() != null && sh.getFields().size() > 0) {
			for (int i = 0; i < sh.getFields().size(); i++) {
				this.lstFields.addItem(sh.getFields().get(i).getName());
				if (i > 0) {
					buff.append(",");
				}
				buff.append(sh.getFields().get(i).getName());
			}
		}

		this.taFields.setText(buff.toString());
	}

	void removeField()
	{
		int idx = this.lstFields.getSelectedIndex();
		if (idx >=0)
		{
			this.lstFields.removeItem(idx);
		}
		else
		{
			Window.alert("Select field to remove!!");
		}
	}
	
	void processOk() {
		SourceHive sh = (SourceHive) this.widget;
		sh.setName(this.txtName.getText());
		sh.setSchema(txtSchema.getText());
		sh.setTable(txtTable.getText());
		sh.setCondition(taCondition.getText());

		List<ColumnDto> lst = new ArrayList<ColumnDto>();
		for (int i = 0; i < this.lstFields.getItemCount(); i++) {
			ColumnDto dto = new ColumnDto();
			dto.setName(this.lstFields.getItemText(i));
			dto.setDataType("String");
			dto.setId(i);
			dto.setPos(i);
			dto.setSensitiveFlag(false);
			lst.add(dto);
		}

		sh.setFields(lst);

		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void processFields() {
		String[] fields = this.taFields.getText().split(",");
		this.lstFields.clear();

		for (String field : fields) {
			this.lstFields.addItem(field);
		}
	}
}
