package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.component.SourceColumnTable;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.CustomAction;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;

public class SchemaDlg extends SdpDialogBox {

	CustomAction widget;

	SourceColumnTable retType;

	ListBox lstRetCat = new ListBox();

	boolean showCat;

	public SchemaDlg(CustomAction widget, List<String> dataTypes, boolean showCat) {
		super(false, false);
		this.widget = widget;
		this.retType = new SourceColumnTable(dataTypes);
		this.showCat = showCat;

		this.setSize("600px", "400px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Import List: " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("600px", "400px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		FlowPanel fp;
		if (this.showCat) {
			fp = new FlowPanel();
			Label lbl = new Label("Return Type Category");
			lbl.getElement().getStyle().setFloat(Float.LEFT);
			this.lstRetCat.getElement().getStyle().setFloat(Float.LEFT);
			fp.add(lbl);
			fp.add(this.lstRetCat);
			dp.addNorth(fp, 30);
		}

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		dp.add(this.retType);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.lstRetCat.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				returnCatChanged();
			}
		});
		
		this.add(dp);
		this.initComponens();
	}

	void returnCatChanged()
	{
		String cat = this.lstRetCat.getItemText(this.lstRetCat.getSelectedIndex());
		if ("DataFrame".equalsIgnoreCase(cat) || "Row".equalsIgnoreCase(cat))
		{
			this.retType.setVisible(false);
		}
		else
		{
			this.retType.setVisible(true);
		}
	}
	
	void initComponens() {
		List<ColumnDto> fields = this.widget.getFields();
		for (ColumnDto cd : fields) {
			this.retType.insertRow(cd.getName(), cd.getDataType(), false);
		}

		this.lstRetCat.addItem("DataFrame");
		this.lstRetCat.addItem("Row");
		this.lstRetCat.addItem("String");
		this.lstRetCat.addItem("Integer");
		this.lstRetCat.addItem("Long");
		this.lstRetCat.addItem("Double");
	}

	void processOk() {
		if (this.lstRetCat.getSelectedIndex() < 2 && this.retType.getRowCount() < 1 && this.showCat) {
			Window.alert("Please define return type structure!!");
			return;
		}

		JSONArray arr = this.retType.getJSON();
		int len = arr.size();
		List<ColumnDto> fields = this.widget.getFields();
		fields.clear();
		for (int i = 0; i < len; i++) {
			JSONObject ff = (JSONObject) arr.get(i);
			ColumnDto d = new ColumnDto();
			d.setName(ff.get("name").isString().stringValue());
			d.setDataType(ff.get("dataType").isString().stringValue());
			d.setSensitiveFlag(false);
			d.setPos(i);
			fields.add(d);
		}
		if (this.showCat) {
			this.widget.setRetCategory(this.lstRetCat.getItemText(this.lstRetCat.getSelectedIndex()));
		} else {
			this.widget.setRetCategory("Prime Type");
		}
		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
