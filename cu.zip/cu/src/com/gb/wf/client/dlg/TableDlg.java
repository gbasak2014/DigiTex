package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.widget.TransformationHeader;
import com.gb.wf.client.widget.TransformationRow;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class TableDlg extends SdpDialogBox {
	VerticalPanel vp;
	List<String> fields = new ArrayList<String>();

	public TableDlg() {
		super(false, false);

		this.fields.add("Column 1");
		this.fields.add("Column 2");
		this.fields.add("Column 3");
		this.fields.add("Column 4");
		this.fields.add("Column 5");

		this.setText("Transformation");
		this.setStyleName("gwt-DialogBox");
		this.setSize("800px", "500px");
		DockLayoutPanel dock = new DockLayoutPanel(Unit.PX);
		dock.setSize("800px", "500px");

		vp = new VerticalPanel();
		vp.setStyleName("gwt-DialogBox");

		FlowPanel fpSouth = new FlowPanel();
		fpSouth.setStyleName("gwt-DialogBox");

		Button btn = new Button("Add");
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fpSouth.add(btn);
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				addRow();
			}
		});

		btn = new Button("Close");
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fpSouth.add(btn);
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				closeMe();
			}
		});

		vp.add(new TransformationHeader());

		ScrollPanel sp = new ScrollPanel();
		sp.add(vp);

		dock.add(sp);
		dock.addSouth(fpSouth, 30);
		this.add(dock);
	}

	void addRow() {

		this.vp.add(new TransformationRow(vp, fields));
	}

	void closeMe() {
		this.hide();
	}
}
