package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.component.JoinConditionRow;
import com.gb.wf.client.component.JoinTable;
import com.gb.wf.client.component.SDPButtonActions;
import com.gb.wf.client.component.TransformationHeader;
import com.gb.wf.client.component.TransformationRow;
import com.gb.wf.client.component.TransformationTable;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.JoinDto;
import com.gb.wf.client.dto.TransformationDto;
import com.gb.wf.client.handler.TransRowSelectionHandler;
import com.gb.wf.client.widget.ImageButton;
import com.gb.wf.client.widget.Join;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class JoinPropDlg extends SdpDialogBox implements ClickHandler, TransRowSelectionHandler {
	TextBox txtName = new TextBox();
	ListBox lstFields = new ListBox(true);
	ListBox lstSchema = new ListBox();

	JoinTable joinTable;

	TransformationTable transformationTable;
	TransformationRow selectedTrns;

	Join widget;

	// List<TransformationRow> list = new ArrayList<TransformationRow>();

	public JoinPropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (Join) widget;
		this.transformationTable = new TransformationTable(this, new TransformationHeader("SL No", "Selected Column", "Column Name"), 510, 300);
		this.joinTable = new JoinTable(this.widget.getPredecessors());

		this.setSize("750px", "600px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Join Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "600px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		this.lstFields.setVisibleItemCount(16);
		this.lstFields.setWidth("150px");

		this.lstSchema.setWidth("150px");

		this.lstSchema.getElement().getStyle().setFloat(Float.LEFT);

		// VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Label lblName = new Label("Name:");
		lblName.getElement().getStyle().setFloat(Float.LEFT);
		txtName.getElement().getStyle().setFloat(Float.LEFT);
		this.lstSchema.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lblName);
		fp.add(txtName);
		fp.add(this.lstSchema);
		// vpn.add(fp);

		// fp = new FlowPanel();
		// fp.add(this.lstSchema);
		// vpn.add(fp);

		dp.addNorth(fp, 30);

		HorizontalPanel vp = new HorizontalPanel();

		VerticalPanel vp1 = new VerticalPanel();
		vp1.add(new ImageButton("images/btn-add.jpg", SDPButtonActions.ADD_COLUMN, "Add selected column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-add-all.jpg", SDPButtonActions.ADD_ALL_COLUMNS, "Add all column", this, 20, 20));

		vp.add(lstFields);
		vp.add(vp1);
		vp.add(this.transformationTable);

		vp1 = new VerticalPanel();
		vp1.add(new ImageButton("images/btn-add-row.jpg", SDPButtonActions.INSERT_COLUMN, "Insert column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_ROW, "Delete selected column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-move-up.jpg", SDPButtonActions.MOVE_UP, "Move selected row up", this, 20, 20));
		vp1.add(new ImageButton("images/btn-move-down.jpg", SDPButtonActions.MOVE_DOWN, "Move selected row down", this, 20, 20));

		vp.add(vp1);
		// ////dp.add(vp);

		HorizontalPanel hpj = new HorizontalPanel();
		hpj.add(this.joinTable);

		VerticalPanel vpMain = new VerticalPanel();
		vpMain.add(vp);
		vpMain.add(hpj);
		/*
		 * ScrollPanel sp = new ScrollPanel();
		 * sp.getElement().getStyle().setBackgroundColor("#ffffff");
		 * sp.getElement().getStyle().setBorderColor("#0");
		 * sp.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		 * sp.setSize("750px", "4600px"); sp.add(vpMain); dp.add(sp);
		 */
		dp.add(vpMain);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();

		this.lstSchema.addChangeHandler(new ChangeHandler() {

			@Override
			public void onChange(ChangeEvent ce) {
				addFields();
			}
		});

		this.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
	}

	void addFields() {
		this.lstFields.clear();
		if (this.lstSchema.getSelectedIndex() > 0) {
			String nm = this.lstSchema.getItemText(this.lstSchema.getSelectedIndex());
			for (SDPWidget w : this.widget.getPredecessors()) {
				if (nm.equals(w.getName())) {
					for (ColumnDto f : w.getFields()) {
						this.lstFields.addItem(f.getName());
					}
					break;
				}
			}
		}
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());

		initSchemaList();
		int idx = 0;
		for (TransformationDto t : this.widget.getTransformations()) {
			this.transformationTable.insertRow(t.getFunction(), t.getFieldName(), idx);
			idx++;
		}

		for (JoinDto j : this.widget.getLinks()) {
			this.joinTable.insertRow(j);
		}
	}

	void initSchemaList() {
		this.lstSchema.addItem("Select Schema");
		for (SDPWidget w : this.widget.getPredecessors()) {
			this.lstSchema.addItem(w.getName());
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		List<TransformationDto> tList = this.widget.getTransformations();
		List<ColumnDto> fields = this.widget.getFields();
		List<JoinDto> links = this.widget.getLinks();
		tList.clear();
		fields.clear();
		links.clear();

		int idx = 0;
		for (TransformationRow tr : this.transformationTable.getModel()) {
			tList.add(new TransformationDto(idx, tr.getTransformation(), tr.getFieldName()));
			ColumnDto dto = new ColumnDto();
			dto.setName(tr.getFieldName());
			dto.setDataType("NONE");
			dto.setId(idx);
			dto.setPos(idx);
			dto.setSensitiveFlag(false);
			fields.add(dto);

			idx++;
		}

		for (JoinConditionRow jr : this.joinTable.getModel()) {
			links.add(jr.getJoinDto());
		}

		this.hide();

	}

	void processCancel() {
		this.hide();
	}

	@Override
	public void onClick(ClickEvent event) {
		int cmd = ((ImageButton) event.getSource()).getCommand();
		int idx;
		switch (cmd) {
		case SDPButtonActions.ADD_COLUMN:
			idx = this.lstFields.getSelectedIndex();
			if (idx > 0) {
				String field = this.lstFields.getItemText(idx);
				String scm = this.lstSchema.getItemText(this.lstSchema.getSelectedIndex());
				this.transformationTable.insertRow(scm + "." + field, scm + "_" + field);
			}
			break;
		case SDPButtonActions.ADD_ALL_COLUMNS:
			for (idx = 0; idx < this.lstFields.getItemCount(); idx++) {
				String scm = this.lstSchema.getItemText(this.lstSchema.getSelectedIndex());
				String field = this.lstFields.getItemText(idx);
				this.transformationTable.insertRow(scm + "." + field, scm + "_" + field);
			}
			break;
		case SDPButtonActions.INSERT_COLUMN:
			this.transformationTable.insertRow("", "");
			break;
		case SDPButtonActions.DELETE_ROW:
			if (this.selectedTrns != null) {
				this.transformationTable.removeRow(this.selectedTrns);
				this.selectedTrns = null;
			}
			break;
		case SDPButtonActions.ADD_JOIN:
			this.joinTable.insertRow();
			break;
		}
	}

	@Override
	public void rowSelected(TransformationRow row) {
		if (this.selectedTrns != null) {
			this.selectedTrns.deselectRow();
		}
		this.selectedTrns = row;
		this.selectedTrns.selectRow();
	}
}
