package com.gb.wf.client.dlg;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.PrimeType;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;

public class PrimeTypePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	PrimeType widget;

	ListBox lstTypes = new ListBox();
	ListBox lstFields = new ListBox();

	public PrimeTypePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (PrimeType) widget;

		this.setSize("750px", "300px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Filter Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "300px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.getElement().getStyle().setFloat(Float.LEFT);
		this.lstTypes.getElement().getStyle().setFloat(Float.LEFT);
		this.lstFields.getElement().getStyle().setFloat(Float.LEFT);

		fp.add(lbl);
		fp.add(this.txtName);
		if (this.widget.getFields().size() > 0) {
			fp.add(this.lstFields);
			this.lstFields.addItem("Please select column");
			for (ColumnDto cd : this.widget.getFields()) {
				this.lstFields.addItem(cd.getName());
			}
			this.lstTypes.setEnabled(false);
		} else {
			fp.add(this.lstTypes);
			this.lstTypes.addItem("Select Data Type");
			for (String dt : this.widget.getDataTypeList()) {
				this.lstTypes.addItem(dt);
			}
		}

		dp.addNorth(fp, 30);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());
		String dt = this.widget.getDataType();

		if (dt != null && dt.length() > 0) {
			int s = this.lstTypes.getItemCount();
			for (int i = 0; i < s; i++) {
				if (dt.equals(this.lstTypes.getItemText(i))) {
					this.lstTypes.setSelectedIndex(i);
					break;
				}
			}
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		int idx;
		if (this.lstFields.getItemCount() > 0) {
			idx = this.lstFields.getSelectedIndex();
			if (idx <= 0) {
				Window.alert("Please select column to assign value to variable!!");
				return;
			}
			this.widget.setParentColumn(this.lstFields.getItemText(idx));
		} else {
			idx = this.lstTypes.getSelectedIndex();
			if (idx <= 0) {
				Window.alert("Please select Data Type!!");
				return;
			}
			this.widget.setDataType(this.lstTypes.getItemText(idx));
		}

		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
