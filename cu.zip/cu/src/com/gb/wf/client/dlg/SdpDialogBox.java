package com.gb.wf.client.dlg;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.HasDirection;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Label;

public class SdpDialogBox extends DialogBox {
	// private Node closeEventTarget = null;
	private Anchor closeAnchor;
	Label lblTitle = new Label();

	public SdpDialogBox() {
		this(false, false);
	}

	public SdpDialogBox(boolean autoHive) {
		this(autoHive, false);
	}

	public SdpDialogBox(boolean autoHide, boolean modal) {
		super(autoHide, modal);
		try {
			/*
			 * Element td = getCellElement(0, 2); td.
			 * setInnerHTML("<img src=\"images/close.jpg\" height=\"20px\" width=\"20px\"/>"
			 * ); closeEventTarget = td.getChild(0);
			 */

			closeAnchor = new Anchor("X");
			FlexTable captionLayoutTable = new FlexTable();
			captionLayoutTable.setWidth("100%");
			captionLayoutTable.setWidget(0, 0, this.lblTitle);
			captionLayoutTable.setWidget(0, 1, closeAnchor);
			captionLayoutTable.getCellFormatter().setHorizontalAlignment(0, 1, HasHorizontalAlignment.HorizontalAlignmentConstant.endOf(HasDirection.Direction.LTR));

			HTML caption = (HTML) getCaption();
			caption.getElement().appendChild(captionLayoutTable.getElement());

			caption.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent event) {
					EventTarget target = event.getNativeEvent().getEventTarget();
					Element targetElement = (Element) target.cast();

					if (targetElement == closeAnchor.getElement()) {
						closeAnchor.fireEvent(event);
					}
				}
			});

			closeAnchor.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent event) {
					hide();
				}
			});

		} catch (Exception e) {
			Window.alert(e.getMessage());
		}
	}

	public void addCloseHandler(ClickHandler handler) {
		closeAnchor.addClickHandler(handler);
	}

	@Override
	public void setText(String title) {
		this.lblTitle.setText(title);
	}

	public void postProcess() {
	}
}
