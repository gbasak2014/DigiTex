package com.gb.wf.client.dlg;

import com.gb.wf.client.handler.WFActionHandler;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.ScrollPanel;

public class ViewSourceSystemDlg extends SdpDialogBox {

	WFActionHandler handler;

	public ViewSourceSystemDlg(JSONArray arrSs, WFActionHandler handler) {
		super(false, false);

		this.handler = handler;

		String cw = (Window.getClientWidth() - 50) + "px";
		String ch = (Window.getClientHeight() - 50) + "px";
		this.setSize(cw, ch);
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize(cw, ch);
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		FlexTable ft = new FlexTable();
		ScrollPanel sp = new ScrollPanel(ft);
		dp.add(sp);

		Button btn = new Button("Close", new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				closeMe();
			}
		});

		FlowPanel fp = new FlowPanel();
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		;
		dp.addSouth(fp, 30);

		this.add(dp);

		initComponens(ft, arrSs);
	}

	void closeMe() {
		this.hide();
	}

	void initComponens(FlexTable ft, JSONArray ssArr) {
		ft.setText(0, 0, "Technical Name");
		ft.setText(0, 1, "Business Name");
		ft.setText(0, 2, "Description");
		ft.setText(0, 3, "Purpose");
		ft.setText(0, 4, "Owner");
		ft.setText(0, 5, "Approver");
		ft.setText(0, 6, "Status");

		int size = ssArr.size();

		for (int r = 1; r <= size; r++) {
			JSONObject obj = ssArr.get(r - 1).isObject();
			long id = (long) obj.get("id").isNumber().doubleValue();

			String technicalName = obj.get("technicalName").isString().stringValue();
			String businessName = obj.get("businessName").isString().stringValue();
			String description = obj.get("description").isString().stringValue();
			String purpose = obj.get("purpose").isString().stringValue();
			String owner = obj.get("owner").isString().stringValue();
			String approver = obj.get("approver").isString().stringValue();
			String status = obj.get("status").isString().stringValue();

			ft.setText(r, 0, technicalName);
			ft.setText(r, 1, businessName);
			ft.setText(r, 2, description);
			ft.setText(r, 3, purpose);
			ft.setText(r, 4, owner);
			ft.setText(r, 5, approver);
			ft.setText(r, 6, status);

			ImageButton btnView = new ImageButton("images/view.jpg", 0, "View " + technicalName, new ClickHandler() {

				@Override
				public void onClick(ClickEvent ce) {
					String msg = ((ImageButton) ce.getSource()).getMsg();
					viewSourceSystem(msg);
				}
			}, 20, 20);

			ImageButton btnEdit = new ImageButton("images/edit.jpg", 0, "Edit " + technicalName, new ClickHandler() {

				@Override
				public void onClick(ClickEvent ce) {
					String msg = ((ImageButton) ce.getSource()).getMsg();
					viewSourceSystem(msg);
				}
			}, 20, 20);

			btnView.setMsg(String.valueOf(id));
			btnEdit.setMsg(String.valueOf(id));

			ft.setWidget(r, 7, btnView);
			ft.setWidget(r, 8, btnEdit);
		}
	}

	void viewSourceSystem(String ssId) {
		this.handler.editSs(Long.parseLong(ssId));
		this.hide();
	}

	void editSourceSystem(String ssId) {
		this.handler.editSs(Long.parseLong(ssId));
		this.hide();
	}
}
