package com.gb.wf.client.dlg;

import java.util.HashMap;
import java.util.Map;

import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.handler.WFActionHandler;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Start;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class ExecuteWfDlg extends SdpDialogBox {
	public static int EXECUTE_WF = 1;
	public static int CREATE_SQOOP_JOB = 2;

	WFActionHandler handler;

	TextBox txtServer = new TextBox();
	TextBox txtPort = new TextBox();
	TextBox txtUser = new TextBox();
	TextBox txtHome = new TextBox();
	PasswordTextBox txtPwd = new PasswordTextBox();
	Map<String, TextBox> map = new HashMap<String, TextBox>();

	int operation;
	SDPWidget node;

	public ExecuteWfDlg(WFActionHandler handler, ProjectDto prj, Start start, SDPWidget node, int action) {
		super(false, true);
		this.handler = handler;
		this.operation = action;
		this.node = node;

		this.setSize("600px", "500px");
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("650px", "550px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		switch (this.operation) {
		case 1:
			this.setText("Execute Workflow");
			break;
		case 2:
			this.setText("Create Sqoop Job");
			break;
		default:
			this.setText("Execute Workflow");
			break;
		}
		VerticalPanel vp = new VerticalPanel();

		HorizontalPanel hp = new HorizontalPanel();
		hp.add(new Label("Please specify details of Edge Node in your Hadoop Cluster"));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Hoste Ip/Name:"));
		txtServer.setWidth("300px");
		hp.add(this.txtServer);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("SFTP Port:"));
		txtServer.setWidth("100px");
		this.txtPort.setText("22");
		hp.add(this.txtPort);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("User Name:"));
		txtServer.setWidth("300px");
		hp.add(this.txtUser);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Password:"));
		txtServer.setWidth("300px");
		hp.add(this.txtPwd);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Working Directory:"));
		txtServer.setWidth("300px");
		hp.add(this.txtHome);
		vp.add(hp);

		for (ParamDto dto : start.getParams()) {
			hp = new HorizontalPanel();
			hp.add(new Label(dto.getParam()));
			TextBox txt = new TextBox();
			txt.setWidth("300px");
			hp.add(txt);
			vp.add(hp);
			map.put(dto.getParam(), txt);
		}

		this.txtHome.setText(prj.getClusterHome());
		this.txtPort.setText(prj.getClusterPort());
		this.txtServer.setText(prj.getClusterHost());
		this.txtUser.setText(prj.getClusterUser());
		this.txtPwd.setText(prj.getClusterPwd());

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("Execute", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Cancel", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		vp.add(fp);
		this.add(vp);
	}

	void processOk() {
		this.hide();
		JSONObject cluster = new JSONObject();

		cluster.put("host", new JSONString(txtServer.getText()));
		cluster.put("user", new JSONString(txtUser.getText()));
		cluster.put("password", new JSONString(txtPwd.getText()));
		cluster.put("home", new JSONString(txtHome.getText()));
		cluster.put("port", new JSONNumber(Double.valueOf(txtPort.getText())));
		cluster.put("action", new JSONNumber(this.operation));

		String json = null;
		if (this.operation == EXECUTE_WF) {
			JSONObject param = null;
			if (map.size() > 0) {
				param = new JSONObject();
				for (String prm : map.keySet()) {
					param.put(prm, new JSONString(map.get(prm).getText()));
				}
			}
			json = this.handler.getJobJson(cluster, param);
		} else if (this.operation == CREATE_SQOOP_JOB) {
			JSONObject sqoop = this.node.getJSON();
			JSONObject req = new JSONObject();

			req.put("cluster", cluster);
			req.put("sqoop", sqoop);

			json = req.toString();
			Window.alert(json);
		}
		this.handler.requestExecuteWorkflow(json);
	}

	void processCancel() {
		this.hide();
	}
}
