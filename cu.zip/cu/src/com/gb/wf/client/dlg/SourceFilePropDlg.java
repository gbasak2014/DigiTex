package com.gb.wf.client.dlg;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.SourceMetaDto;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.util.SdfUtils;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SourceFileStream;
import com.gb.wf.client.widget.SourceHDFS;
import com.gb.wf.client.widget.SourceLocal;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class SourceFilePropDlg extends SdpDialogBox {
	ListBox lstName = new ListBox();
	TextBox txtSource = new TextBox();
	TextBox txtTarget = new TextBox();
	ListBox lstPathPattern = new ListBox();
	ListBox lstPathTrgPattern = new ListBox();

	TextBox txtDelimiter = new TextBox();
	Label lblDelimiter = new Label("Record Element:");
	TextBox txtSuffix = new TextBox();

	TextArea taFields = new TextArea();

	TextBox txtFileType = new TextBox();

	CheckBox chkDeleteSrc = new CheckBox("Delete Source");
	CheckBox chkRenameSrc = new CheckBox("Rename Suffix");

	SDPWidget widget;
	boolean isStream;

	// CellTable<ColumnDto> tables = new CellTable<ColumnDto>();
	long projectId;
	SourceMetaDto sourceMeta;

	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public SourceFilePropDlg(SDPWidget widget, long projectId) throws Exception {
		super(false, false);
		this.projectId = projectId;
		this.widget = widget;
		if (this.widget.getType() == ComponentTypes.SOURCE_FILE_STREAM) {
			this.isStream = true;
		} else {
			this.isStream = false;
		}

		this.setSize("600px", "500px");
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("650px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.lstName.setWidth("200px");

		this.txtDelimiter.setStyleName("textBox");
		this.txtDelimiter.setWidth("50px");

		hp.add(lbl);
		hp.add(this.lstName);
		hp.add(new Label("File Type:"));
		hp.add(this.txtFileType);
		hp.add(this.lblDelimiter);
		hp.add(this.txtDelimiter);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Source Path:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtSource.setWidth("450px");
		this.txtSource.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtSource);
		this.txtSource.setEnabled(enableSource());

		if (!this.isStream) {
			hp.add(this.lstPathPattern);

			this.lstPathPattern.addItem("Select pattern");
			this.lstPathPattern.addItem("Match All");
			this.lstPathPattern.addItem("Year (YYYY)");
			this.lstPathPattern.addItem("Month (MM)");
			this.lstPathPattern.addItem("Day (DD)");
			this.lstPathPattern.addItem("Hour (HH)");
			this.lstPathPattern.addItem("Job Name");

			this.lstPathPattern.addChangeHandler(new ChangeHandler() {
				@Override
				public void onChange(ChangeEvent event) {
					addPathPattern();
				}
			});
		}
		dp.addNorth(hp, 30);

		if (this.widget.getType() == ComponentTypes.SOURCE_LOCAL) {
			hp = new HorizontalPanel();
			hp.getElement().getStyle().setMargin(2, Unit.PX);
			lbl = new Label("Target Path:");
			lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
			this.txtTarget.setWidth("450px");
			this.txtTarget.setStyleName("textBox");
			hp.add(lbl);
			hp.add(this.txtTarget);

			hp.add(this.lstPathTrgPattern);

			this.lstPathTrgPattern.addItem("Select pattern");
			this.lstPathTrgPattern.addItem("Match All");
			this.lstPathTrgPattern.addItem("Year (YYYY)");
			this.lstPathTrgPattern.addItem("Month (MM)");
			this.lstPathTrgPattern.addItem("Day (DD)");
			this.lstPathTrgPattern.addItem("Hour (HH)");
			this.lstPathTrgPattern.addItem("Job Name");

			this.lstPathTrgPattern.addChangeHandler(new ChangeHandler() {
				@Override
				public void onChange(ChangeEvent event) {
					addPathTrgPattern();
				}
			});

			dp.addNorth(hp, 30);
		}

		FlowPanel fp;
		if (!this.isStream) {
			fp = new FlowPanel();
			fp.getElement().getStyle().setMargin(5, Unit.PX);
			this.chkDeleteSrc.getElement().getStyle().setFloat(Float.LEFT);
			this.chkRenameSrc.getElement().getStyle().setFloat(Float.LEFT);
			this.txtSuffix.setStyleName("textBox");
			this.txtSuffix.getElement().getStyle().setFloat(Float.LEFT);
			fp.add(this.chkDeleteSrc);
			fp.add(this.chkRenameSrc);
			fp.add(this.txtSuffix);
			dp.addNorth(fp, 30);
		}

		lbl = new Label("Fields and Data Type");
		this.taFields.setSize("580px", "200px");
		dp.addNorth(lbl, 25);
		dp.addNorth(this.taFields, 200);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.chkDeleteSrc.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> event) {
				if (chkDeleteSrc.getValue()) {
					chkRenameSrc.setValue(false);
					txtSuffix.setEnabled(true);
				} else {
					txtSuffix.setEnabled(false);
				}
			}
		});

		this.chkRenameSrc.addValueChangeHandler(new ValueChangeHandler<Boolean>() {

			@Override
			public void onValueChange(ValueChangeEvent<Boolean> event) {
				if (chkRenameSrc.getValue()) {
					chkDeleteSrc.setValue(false);
				}
			}
		});

		this.add(dp);
		getSourceList();
		// this.initComponens();

		this.taFields.setEnabled(false);
		this.lstName.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				sourceChanged();
			}
		});
	}

	void initComponens() {
		long id = -1;
		if (this.widget.getType() == ComponentTypes.SOURCE_LOCAL) {
			SourceLocal sl = (SourceLocal) this.widget;
			id = sl.getMetaId();
		} else if (this.widget.getType() == ComponentTypes.SOURCE_HDFS) {
			SourceHDFS sh = (SourceHDFS) this.widget;
			id = sh.getMetaId();
		} else {
			SourceFileStream sfs = (SourceFileStream) this.widget;
			id = sfs.getMetaId();
		}

		for (int i = 1; i < this.lstName.getItemCount(); i++) {
			String idNm = this.lstName.getItemText(i);
			long idx = Long.parseLong(idNm.split("-")[0].trim());
			if (id == idx) {
				this.lstName.setSelectedIndex(i);
			}
		}

		if (this.widget.getName() != null) {
			StringBuffer bff = new StringBuffer();
			Map<Integer, ColumnDto> m = new TreeMap<Integer, ColumnDto>();
			for (ColumnDto c : this.widget.getFields()) {
				m.put(c.getPos(), c);
			}

			for (Entry<Integer, ColumnDto> cd : m.entrySet()) {
				if (bff.length() > 0) {
					bff.append("\n");
				}
				ColumnDto dto = cd.getValue();
				bff.append(dto.getName()).append("\t").append(dto.getDataType()).append(dto.getSensitiveFlag() ? "\tSensitive" : "");
			}

			this.taFields.setText(bff.toString());
		}

		
		if (this.widget.getType() == ComponentTypes.SOURCE_LOCAL) {
			SourceLocal sl = (SourceLocal) this.widget;
			initLocal(sl);
		} else if (this.widget.getType() == ComponentTypes.SOURCE_HDFS) {
			SourceHDFS sh = (SourceHDFS) this.widget;
			initHDFS(sh);
		} else {
			SourceFileStream sfs = (SourceFileStream) this.widget;
			initStream(sfs);
		}
		
		sourceChanged();
	}

	void initLocal(SourceLocal w) {
		this.setText("Local File Source Properties for " + widget.getName());
		this.txtTarget.setText(w.getTargetPath());
		this.txtDelimiter.setText(w.getDelimiter());
		this.txtSource.setText(w.getPath());
		this.chkDeleteSrc.setValue(w.isDeleteOnSuccess());
		this.chkRenameSrc.setValue(w.isRenameOnSuccess());
		this.txtSuffix.setText(w.getSuffix());
		this.txtFileType.setText(w.getFileFormat());
	}

	void initHDFS(SourceHDFS w) {
		this.setText("HDFS File Source Properties for " + widget.getName());
		this.txtDelimiter.setText(w.getDelimiter());
		this.txtSource.setText(w.getSourcePath());
		this.chkDeleteSrc.setValue(w.isDeleteOnSuccess());
		this.chkRenameSrc.setValue(w.isRenameOnSuccess());
		this.txtSuffix.setText(w.getSuffix());
		this.txtFileType.setText(w.getFileType());
	}

	void initStream(SourceFileStream w) {
		this.setText("Streaming File Source Properties for " + widget.getName());
		this.txtDelimiter.setText(w.getDelimiter());
		this.txtSource.setText(w.getPath());
		this.txtFileType.setText(w.getRecordType());
	}

	void processOk() {
		try {
			int idx = this.lstName.getSelectedIndex();
			if (idx > 0) {
				String[] arr = this.lstName.getItemText(idx).split("-");
				this.widget.setName(arr[1]);
				long id = Long.parseLong(arr[0].trim());
				if (this.widget.getType() == ComponentTypes.SOURCE_LOCAL) {
					setLocal(id);
				} else if (this.widget.getType() == ComponentTypes.SOURCE_HDFS) {
					setHDFS(id);
				} else {
					setStream(id);
				}

				this.widget.setFields(this.sourceMeta.getColumns());
				this.hide();
			} else {
				Window.alert("Please select Source Name...");
			}
		} catch (Exception e) {
			Window.alert("ERROR:" + e.getMessage());
		}
	}

	void setLocal(long id) {
		SourceLocal sl = (SourceLocal) this.widget;
		sl.setMetaId(id);
		sl.setTargetPath(this.txtTarget.getText());
		sl.setFileFormat(this.txtFileType.getText());
		sl.setDelimiter(this.txtDelimiter.getText());
		sl.setPath(this.txtSource.getText());
		sl.setDeleteOnSuccess(this.chkDeleteSrc.getValue());
		sl.setRenameOnSuccess(this.chkRenameSrc.getValue());
		sl.setSuffix(this.txtSuffix.getText());
	}

	void setHDFS(long id) {
		SourceHDFS sl = (SourceHDFS) this.widget;
		sl.setMetaId(id);
		sl.setFileType(this.txtFileType.getText());
		sl.setDelimiter(this.txtDelimiter.getText());
		sl.setSourcePath(this.txtSource.getText());
		sl.setDeleteOnSuccess(this.chkDeleteSrc.getValue());
		sl.setRenameOnSuccess(this.chkRenameSrc.getValue());
		sl.setSuffix(this.txtSuffix.getText());
	}

	void setStream(long id) {
		SourceFileStream sl = (SourceFileStream) this.widget;
		sl.setMetaId(id);
		sl.setRecordType(this.txtFileType.getText());
		sl.setDelimiter(this.txtDelimiter.getText());
		sl.setPath(this.txtSource.getText());
	}

	void processCancel() {
		this.hide();
	}

	void addPathTrgPattern() {
		String pattern = null;
		switch (this.lstPathTrgPattern.getSelectedIndex()) {
		case 1:
			pattern = "*";
			break;
		case 2:
			pattern = "$YYYY";
			break;
		case 3:
			pattern = "$MM";
			break;
		case 4:
			pattern = "$DD";
			break;
		case 5:
			pattern = "$HH";
			break;
		case 6:
			pattern = "$job.name";
			break;
		}

		if (pattern != null) {
			this.txtTarget.setText(this.txtTarget.getText() + pattern);
		}
	}

	void addPathPattern() {
		String pattern = null;
		switch (this.lstPathPattern.getSelectedIndex()) {
		case 1:
			pattern = "*";
			break;
		case 2:
			pattern = "$YYYY";
			break;
		case 3:
			pattern = "$MM";
			break;
		case 4:
			pattern = "$DD";
			break;
		case 5:
			pattern = "$HH";
			break;
		case 6:
			pattern = "$job.name";
			break;
		}

		if (pattern != null) {
			this.txtSource.setText(this.txtSource.getText() + pattern);
		}
	}

	private void getSourceList() {
		this.service.getSourceList(this.projectId, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String res) {
				fillSourceList(res);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server ERROR!!");
			}
		});
	}

	void fillSourceList(String src) {
		this.lstName.addItem("Select source");
		for (String s : src.split(",")) {
			this.lstName.addItem(s);
		}

		initComponens();
	}

	void sourceChanged() {
		int idx = this.lstName.getSelectedIndex();
		if (idx > 0) {
			String[] src = this.lstName.getItemText(idx).split("-");
			long id = Long.parseLong(src[0]);

			if (this.sourceMeta == null || this.sourceMeta.getId() != id) {
				this.service.getProjectSources(id, new AsyncCallback<String>() {
					@Override
					public void onSuccess(String res) {
						populateSourceMeta(res);
					}

					@Override
					public void onFailure(Throwable arg0) {
						Window.alert("Error to get Source detail!!");
					}
				});
			}
		}
	}

	void populateSourceMeta(String res) {
		try {
			if (this.sourceMeta == null) {
				this.sourceMeta = new SourceMetaDto();
			}

			SdfUtils.getSourceMeta(res, this.sourceMeta);

			this.txtDelimiter.setText(this.sourceMeta.getDelimiter());
			this.txtFileType.setText(this.sourceMeta.getRecordType());
			this.txtSource.setText(this.sourceMeta.getSource());
			StringBuffer bff = new StringBuffer();
			Map<Integer, ColumnDto> m = new TreeMap<Integer, ColumnDto>();
			for (ColumnDto c : this.sourceMeta.getColumns()) {
				m.put(c.getPos(), c);
			}

			for (Entry<Integer, ColumnDto> cd : m.entrySet()) {
				if (bff.length() > 0) {
					bff.append("\n");
				}
				ColumnDto dto = cd.getValue();
				bff.append(dto.getName()).append("\t").append(dto.getDataType()).append("\t").append(dto.getSensitiveFlag() ? "Sensitive" : "");
			}

			this.taFields.setText(bff.toString());
		} catch (Exception e) {
			Window.alert("ERROR" + e.getMessage());
		}

	}

	private boolean enableSource() {
		SDPWidget p = this.widget.getPredecessors().get(0);
		return p.getType() != ComponentTypes.SOURCE_LOCAL;
	}
}
