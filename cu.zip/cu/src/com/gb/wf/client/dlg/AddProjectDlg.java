package com.gb.wf.client.dlg;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.WFDesignerPage;
import com.gb.wf.client.dto.UserDto;
import com.gb.wf.client.util.SdfUtils;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class AddProjectDlg extends SdpDialogBox {
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	TextBox txtName = new TextBox();
	TextBox txtDesc = new TextBox();

	TextBox txtHost = new TextBox();
	TextBox txtPort = new TextBox();
	TextBox txtUser = new TextBox();
	TextBox txtHome = new TextBox();
	PasswordTextBox txtPwd = new PasswordTextBox();
	
	Label lblMsg = new Label();
	WFDesignerPage designerPage;
	
	public AddProjectDlg(WFDesignerPage designerPage) {
		super(false, false);
		this.designerPage = designerPage;
		this.setSize("500px", "450px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Create Project");

		VerticalPanel vp = new VerticalPanel();
		vp.setSize("500px", "250px");

		lblMsg.getElement().getStyle().setBackgroundColor("#ff0000");
		vp.add(lblMsg);

		Label lbl = new Label("Add Project");
		lbl.setStyleName("titleText");
		vp.add(lbl);

		HorizontalPanel hp = new HorizontalPanel();
		lbl = new Label("Project Name:");
		lbl.setWidth("150px");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtName);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Project Description:");
		lbl.setWidth("150px");
		this.txtDesc.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtDesc);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Hadoop Cluster Host:"));
		this.txtHost.setWidth("400px");
		hp.add(this.txtHost);
		vp.add(hp);
		
		hp = new HorizontalPanel();
		hp.add(new Label("SFTP connection Port:"));
		this.txtPort.setWidth("100px");
		hp.add(this.txtPort);
		vp.add(hp);
		
		hp = new HorizontalPanel();
		hp.add(new Label("Hadoop Cluster User:"));
		this.txtUser.setWidth("300px");
		hp.add(this.txtUser);
		vp.add(hp);
		
		hp = new HorizontalPanel();
		hp.add(new Label("Workflow Home:"));
		this.txtHome.setWidth("400px");
		hp.add(this.txtHome);
		vp.add(hp);
		
		hp = new HorizontalPanel();
		hp.add(new Label("Hadoop Cluster Password:"));
		this.txtPwd.setWidth("400px");
		hp.add(this.txtPwd);
		vp.add(hp);
		
		
		FlowPanel fp = new FlowPanel();
		Button btn = new Button("Add", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Cancel", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		vp.add(fp);

		this.add(vp);
	}

	void processOk() {
		try {

			JSONObject json = new JSONObject();
			json.put("name", new JSONString(this.txtName.getText()));
			json.put("description", new JSONString(this.txtDesc.getText()));
			json.put("userId", new JSONString(this.designerPage.getUser().getUserId()));
			json.put("clusterUser", new JSONString(this.txtUser.getText()));
			json.put("clusterPwd", new JSONString(this.txtPwd.getText()));
			json.put("clusterHost", new JSONString(this.txtHost.getText()));
			json.put("clusterPort", new JSONString(this.txtPort.getText()));
			json.put("clusterHome", new JSONString(this.txtHome.getText()));
			
			this.service.addProject(json.toString(), new AsyncCallback<String>() {
				@Override
				public void onSuccess(String res) {
					processAdd(res);
				}

				@Override
				public void onFailure(Throwable arg0) {
					Window.alert("Server ERROR");
				}
			});
		} catch (Exception e) {
		}
	}

	void processCancel() {
		this.hide();
	}

	void processAdd(String res) {
		if ("ERROR".equals(res)) {
			lblMsg.setText("Error adding Project!!!");
		} else {
			JSONObject json = (JSONObject) JSONParser.parseStrict(res);
			String status = json.get("status").isString().stringValue();
			if ("EXIST".equals(status)) {
				lblMsg.setText("Project exist with the name!!");
			} else if ("FAIL".equals(status)) {
				lblMsg.setText("Fail to add project!!");
			} else if ("SUCCESS".equals(status)) {
				UserDto user = SdfUtils.getUserDto(json);
				this.designerPage.setUser(user);
				this.hide();
			}
		}
	}
}
