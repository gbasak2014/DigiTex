package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.SDPButtonActions;
import com.gb.wf.client.component.TransformationRow;
import com.gb.wf.client.component.TransformationTable;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.TransformationDto;
import com.gb.wf.client.handler.TransRowSelectionHandler;
import com.gb.wf.client.widget.ImageButton;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Transformation;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class TransformationPropDlg extends SdpDialogBox implements ClickHandler, TransRowSelectionHandler {
	TextBox txtName = new TextBox();
	ListBox lstFields = new ListBox(true);
	ListBox lstFunction = new ListBox();

	TransformationTable transformationTable;
	TransformationRow selectedRow;

	Transformation widget;

	public TransformationPropDlg(SDPWidget widget) {
		super(false, false);
		this.transformationTable = new TransformationTable(this);
		this.widget = (Transformation) widget;

		this.setSize("750px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Transformation Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		this.lstFields.setVisibleItemCount(20);
		this.lstFields.setWidth("150px");

		this.lstFunction.setWidth("150px");

		this.lstFunction.getElement().getStyle().setFloat(Float.LEFT);
		Button btn = new Button("Add Function");
		btn.getElement().getStyle().setFloat(Float.LEFT);
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				addFunction();
			}
		});

		VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Label lblName = new Label("Name:");
		lblName.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lblName);
		fp.add(txtName);
		vpn.add(fp);

		fp = new FlowPanel();
		fp.add(this.lstFunction);
		fp.add(btn);
		vpn.add(fp);

		dp.addNorth(vpn, 60);

		HorizontalPanel vp = new HorizontalPanel();

		VerticalPanel vp1 = new VerticalPanel();
		vp1.add(new ImageButton("images/btn-add.jpg", SDPButtonActions.ADD_COLUMN, "Add selected column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-add-all.jpg", SDPButtonActions.ADD_ALL_COLUMNS, "Add all column", this, 20, 20));

		vp.add(lstFields);
		vp.add(vp1);

		vp.add(this.transformationTable);

		vp1 = new VerticalPanel();
		vp1.add(new ImageButton("images/btn-add-row.jpg", SDPButtonActions.INSERT_COLUMN, "Insert column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_ROW, "Delete selected column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-move-up.jpg", SDPButtonActions.MOVE_UP, "Move selected row up", this, 20, 20));
		vp1.add(new ImageButton("images/btn-move-down.jpg", SDPButtonActions.MOVE_DOWN, "Move selected row down", this, 20, 20));

		vp.add(vp1);
		dp.add(vp);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void addFunction() {
		int idx = this.lstFunction.getSelectedIndex();
		if (idx > 0) {
			String func = this.lstFunction.getItemText(idx);
			boolean isFunc = false;
			if ("If-Else-If".equals(func)) {
				int i = this.lstFields.getSelectedIndex();
				if (i < 0) {
					Window.alert("Please select field!!");
					return;
				}
				isFunc = true;
				String col = this.lstFields.getItemText(i);
				func = func + "{" + col + "}";
			}
			this.transformationTable.insertRow(func, "", isFunc);
		}
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());

		for (ColumnDto f : this.widget.getPredecessors().get(0).getFields()) {
			this.lstFields.addItem(f.getName());
		}

		int idx = 0;
		for (TransformationDto tdto : this.widget.getTransformations()) {
			boolean flag = false;
			if (tdto.getFunction().startsWith("If-Else-If")) {
				flag = true;
			}
			this.transformationTable.insertRow(tdto.getFunction(), tdto.getFieldName(), idx, flag);
			idx++;
		}

		initFunction();
	}

	void initFunction() {
		this.lstFunction.addItem("Select Function");
		this.lstFunction.addItem("Add(<data1>, <data2>)");
		this.lstFunction.addItem("Concat(<data1>, <data2>, ...)");
		this.lstFunction.addItem("Subtract(<data1>, <data2>)");
		this.lstFunction.addItem("Format(<data>, <input format>, <output format>)");
		this.lstFunction.addItem("Replace(<data>, <Old String>, <New String>)");
		this.lstFunction.addItem("If-Else-If");
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		List<TransformationDto> tList = new ArrayList<TransformationDto>();
		List<ColumnDto> fields = new ArrayList<ColumnDto>();
		int idx = 0;
		for (TransformationRow tr : this.transformationTable.getModel()) {
			String trns = tr.getTransformation();
			if (trns.startsWith("If-Else-If")) {
				trns = trns + "#" + tr.getFunction();
			}

			tList.add(new TransformationDto(idx, trns, tr.getFieldName()));
			ColumnDto dto = new ColumnDto();
			dto.setName(tr.getFieldName());
			dto.setPos(idx);
			dto.setId(-1);
			dto.setDataType("NA");
			dto.setSensitiveFlag(false);
			fields.add(dto);
			idx++;
		}

		this.widget.setTransformations(tList);
		this.widget.setFields(fields);
		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	@Override
	public void onClick(ClickEvent event) {
		int cmd = ((ImageButton) event.getSource()).getCommand();
		int idx;
		int s;
		switch (cmd) {
		case SDPButtonActions.ADD_COLUMN:
			s = this.lstFields.getItemCount();
			for (idx = 0; idx < s; idx++) {
				if (this.lstFields.isItemSelected(idx)) {
					String field = this.lstFields.getItemText(idx);
					this.transformationTable.insertRow("$" + field, field, false);
				}
			}
			break;
		case SDPButtonActions.ADD_ALL_COLUMNS:
			s = this.lstFields.getItemCount();
			for (idx = 0; idx < s; idx++) {
				String field = this.lstFields.getItemText(idx);
				this.transformationTable.insertRow("$" + field, field, false);
			}
			break;
		case SDPButtonActions.INSERT_COLUMN:
			this.transformationTable.insertRow("", "", false);
			break;
		case SDPButtonActions.DELETE_ROW:
			if (this.selectedRow != null) {
				this.transformationTable.removeRow(this.selectedRow);
				this.selectedRow = null;
			}
		}
	}

	@Override
	public void rowSelected(TransformationRow row) {
		if (this.selectedRow != null) {
			this.selectedRow.deselectRow();
		}
		this.selectedRow = row;
		this.selectedRow.selectRow();
	}
}
