package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.IfElseRow;
import com.gb.wf.client.component.TransformationRow;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class IfElseDlg extends SdpDialogBox {

	VerticalPanel vp = new VerticalPanel();
	TransformationRow row;
	String column;

	List<IfElseRow> list = new ArrayList<IfElseRow>();
	ListBox lstType = new ListBox();
	
	public IfElseDlg(TransformationRow row) {
		super(false, true);

		this.row = row;
		this.column = row.getTransformation().substring("If-Else-If".length());
		this.setSize("750px", "600px");
		this.setStyleName("gwt-DialogBox");
		this.setText("If-Else-If");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "600px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");
		this.add(dp);

		// VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Button btnAdd = new Button("Add");
		fp.add(btnAdd);
		dp.addNorth(fp, 30);

		fp = new FlowPanel();
		fp.add(new Label("Column Type"));
		fp.add(this.lstType);
		dp.addNorth(fp, 30);
		
		
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		fp = new FlowPanel();
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		ScrollPanel sp = new ScrollPanel();
		sp.add(vp);
		dp.add(sp);

		initFunction(row);
		
		btnAdd.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addPressed();
			}
		});
		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				okPressed();
			}
		});
		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				cancelPressed();
			}
		});

	}

	FlowPanel getHeader() {
		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Column");
		lbl.getElement().getStyle().setWidth(60, Unit.PX);
		lbl.getElement().getStyle().setHeight(20, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);

		lbl = new Label("Operation");
		lbl.getElement().getStyle().setWidth(60, Unit.PX);
		lbl.getElement().getStyle().setHeight(20, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);

		lbl = new Label("Source data");
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		lbl.getElement().getStyle().setHeight(20, Unit.PX);

		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Output Data");
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		lbl.getElement().getStyle().setHeight(20, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		return fp;
	}

	void initFunction(TransformationRow row) {
		String colType = "String";
		if (row.getFunction() != null && row.getFunction().length() > 0) {
			String[] fStr = row.getFunction().split("#");
			if (fStr.length > 1)
			{
				colType = fStr[1];
			}
			
			JSONObject func = (JSONObject)JSONParser.parseStrict(fStr[0]);
			
			JSONArray arr = func.get("function").isArray();
			
			int s = arr.size();
			for (int i = 0; i < s; i++) {
				JSONObject obj = arr.get(i).isObject();
				String op = obj.get("operation").isString().stringValue();
				String src = obj.get("source").isString().stringValue();
				String trg = obj.get("target").isString().stringValue();
				IfElseRow r = new IfElseRow(this.column, op, src, trg);
				this.vp.add(r);
				this.list.add(r);
			}

		}
		
		this.lstType.addItem("String");
		this.lstType.addItem("Int");
		this.lstType.addItem("Double");
		this.lstType.addItem("Long");
		int len = this.lstType.getItemCount();
		for (int i=0; i<len; i++)
		{
			if (this.lstType.getItemText(i).equals(colType))
			{
				this.lstType.setSelectedIndex(i);
				break;
			}
		}
	}

	void addPressed() {
		IfElseRow row = new IfElseRow(this.column);
		this.vp.add(row);
		this.list.add(row);
	}

	void okPressed() {
		JSONObject obj = new JSONObject();
		JSONArray arr = new JSONArray();
		int i = 0;
		for (IfElseRow r : list) {
			arr.set(i, r.getJson());
			i++;
		}

		obj.put("function", arr);

		i = this.lstType.getSelectedIndex();
		String colType = this.lstType.getItemText(i);
		this.row.setFunction(obj.toString() + "#" + colType);

		this.hide();
	}

	void cancelPressed() {
		this.hide();
	}
}
