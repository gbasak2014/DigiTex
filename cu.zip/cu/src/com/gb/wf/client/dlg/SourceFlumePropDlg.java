package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SourceFlume;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class SourceFlumePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtHost = new TextBox();
	TextBox txtPort = new TextBox();
	TextBox txtInterval = new TextBox();

	TextArea taFields = new TextArea();
	ListBox lstFields = new ListBox();

	TextBox txtDelimiter = new TextBox();
	Label lblDelimiter = new Label("Record Element");

	ListBox lstRecType = new ListBox();

	SDPWidget widget;

	public SourceFlumePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("650px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Flume Source Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("650px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtName);

		lbl = new Label("Batch Interval:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtInterval.setStyleName("textBox");
		this.txtInterval.setWidth("50px");
		this.txtInterval.setTitle("Batch Interval in Second");
		hp.add(lbl);
		hp.add(this.txtInterval);

		hp.add(lstRecType);
		lblDelimiter.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtDelimiter.setStyleName("textBox");
		this.txtDelimiter.setWidth("100px");
		this.txtDelimiter.setTitle("Field delimiter/XML Record Element");
		hp.add(lblDelimiter);
		hp.add(this.txtDelimiter);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();

		hp.add(new Label("Flume sink Host"));
		hp.add(txtHost);
		hp.add(new Label("Port"));
		hp.add(txtPort);
		dp.addNorth(hp, 30);

		lbl = new Label("Comma (,) separated fields name");
		this.taFields.setSize("580px", "50px");
		dp.addNorth(lbl, 25);
		dp.addNorth(this.taFields, 75);

		Button btn = new Button("Add Fields to List");
		btn.setSize("200px", "25px");
		btn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processFields();
			}
		});

		dp.addNorth(btn, 25);

		dp.addNorth(new Label("Fields in Source"), 20);
		this.lstFields.setSize("100px", "200px");
		this.lstFields.setVisibleItemCount(20);
		dp.addNorth(this.lstFields, 200);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);

		lstRecType.addItem("Select Record Type");
		lstRecType.addItem("Delimited");
		lstRecType.addItem("XML");
		lstRecType.addItem("JSON");

		this.initComponens();

		lstRecType.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				recordTypeChanged();
			}
		});
	}

	void recordTypeChanged() {
		int idx = lstRecType.getSelectedIndex();
		if (idx == 1) {
			this.lblDelimiter.setText("Delimiter:");
			this.txtDelimiter.setEnabled(true);
		} else if (idx == 2) {
			this.lblDelimiter.setText("Record Element:");
			this.txtDelimiter.setEnabled(true);
		} else {
			this.lblDelimiter.setText("");
			this.txtDelimiter.setEnabled(false);
		}
	}

	void initComponens() {
		SourceFlume st = (SourceFlume) this.widget;
		this.txtName.setText(st.getName());
		this.txtDelimiter.setText(st.getDelimiter());
		this.txtHost.setText(st.getHost());
		this.txtPort.setText(String.valueOf(st.getPort()));
		this.txtInterval.setText(String.valueOf(st.getInterval()));

		StringBuffer buff = new StringBuffer();
		if (st.getFields() != null && st.getFields().size() > 0) {
			for (int i = 0; i < st.getFields().size(); i++) {
				this.lstFields.addItem(st.getFields().get(i).getName());
				if (i > 0) {
					buff.append(",");
				}
				buff.append(st.getFields().get(i));
			}
		}

		int cnt = this.lstRecType.getItemCount();
		for (int i = 0; i < cnt; i++) {
			if (st.getRecordType().equalsIgnoreCase(this.lstRecType.getItemText(i))) {
				this.lstRecType.setSelectedIndex(i);
				break;
			}
		}

		this.taFields.setText(buff.toString());
	}

	void processOk() {
		SourceFlume st = (SourceFlume) this.widget;
		st.setName(this.txtName.getText());
		st.setDelimiter(txtDelimiter.getText());
		st.setInterval(Integer.parseInt(txtInterval.getText()));
		st.setHost(txtHost.getText());
		st.setPort(Integer.parseInt(txtPort.getText()));

		List<ColumnDto> lst = new ArrayList<ColumnDto>();
		for (int i = 0; i < this.lstFields.getItemCount(); i++) {
			ColumnDto dto = new ColumnDto();
			dto.setName(this.lstFields.getItemText(i));
			lst.add(dto);
		}

		st.setFields(lst);

		int idx = this.lstRecType.getSelectedIndex();
		st.setRecordType(this.lstRecType.getItemText(idx));

		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void processFields() {
		String[] fields = this.taFields.getText().split(",");
		this.lstFields.clear();

		for (String field : fields) {
			this.lstFields.addItem(field);
		}
	}
}
