package com.gb.wf.client.dlg;

import com.gb.wf.client.component.WFDesignerPage;
import com.gb.wf.client.dto.ProjectDto;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ScrollPanel;

public class ViewProjectDlg extends SdpDialogBox {

	long pId;
	WFDesignerPage designerPage;

	public ViewProjectDlg(WFDesignerPage designerPage) {
		this.designerPage = designerPage;

		try {
			this.setSize("800px", "600px");
			this.setStyleName("gwt-DialogBox");
			this.setText("Project Select");
			DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
			dp.setSize("800px", "600px");
			dp.getElement().getStyle().setMargin(5, Unit.PX);
			dp.setStyleName("gwt-DialogBox");

			FlexTable tbl = new FlexTable();
			tbl.setText(0, 0, "SL No");
			tbl.setText(0, 1, "Select");
			tbl.setText(0, 2, "ID");
			tbl.setText(0, 3, "Name");
			tbl.setText(0, 4, "Description");
			tbl.getColumnFormatter().getElement(0).getStyle().setWidth(50, Unit.PX);
			tbl.getColumnFormatter().getElement(1).getStyle().setWidth(50, Unit.PX);
			tbl.getColumnFormatter().getElement(2).getStyle().setWidth(100, Unit.PX);
			tbl.getColumnFormatter().getElement(3).getStyle().setWidth(100, Unit.PX);
			tbl.getColumnFormatter().getElement(4).getStyle().setWidth(490, Unit.PX);
	
			int r = 1;
			for (ProjectDto p : designerPage.getUser().getProjects()) {
				tbl.setText(r, 0, String.valueOf(r));
				RadioButton rb = new RadioButton("select");//, String.valueOf(p.getName())
				rb.setText(String.valueOf(p.getId()));
				tbl.setWidget(r, 1, rb);
				tbl.setText(r, 2, String.valueOf(p.getId()));
				tbl.setText(r, 3, p.getName());
				tbl.setText(r, 4, p.getDescription());
				rb.addClickHandler(new ClickHandler() {
					@Override
					public void onClick(ClickEvent ce) {
						String id = ((RadioButton) ce.getSource()).getText();
						selectClicked(id);
					}
				});
				r++;
			}

			FlowPanel fp = new FlowPanel();
			Button btn = new Button("Close", new ClickHandler() {
				@Override
				public void onClick(ClickEvent arg0) {
					closeMe();
				}
			});
			btn.getElement().getStyle().setFloat(Float.RIGHT);
			fp.add(btn);
			btn = new Button("Select And Close", new ClickHandler() {
				@Override
				public void onClick(ClickEvent arg0) {
					selectProject();
				}
			});
			btn.getElement().getStyle().setFloat(Float.RIGHT);
			fp.add(btn);

			Label lbl = new Label("Select Project");
			lbl.getElement().getStyle().setFontSize(18, Unit.PX);
			ScrollPanel sp = new ScrollPanel();
			sp.setSize("800px", "500px");
			sp.add(tbl);

			dp.addNorth(lbl, 60);
			dp.add(sp);
			dp.addSouth(fp, 30);

			this.add(dp);
		} catch (Exception e) {
			Window.alert("Error-" + e.getMessage());
		}
	}

	void selectProject() {
		if (this.pId <= 0) {
			Window.alert("Please select project!!!");
			return;
		}

		this.designerPage.selectProject(this.pId);
		this.hide();
	}

	void selectClicked(String id) {
		this.pId = Long.parseLong(id);
	}

	void closeMe() {
		this.hide();
	}
}
