package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.ExpandableFileTableCols;
import com.gb.wf.client.component.ExpandableTableCols;
import com.gb.wf.client.component.FileUploadWin;
import com.gb.wf.client.component.MdmReqWin;
import com.gb.wf.client.handler.MdmReqHandler;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.TabPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class CreateSourceSystemDlg extends SdpDialogBox implements MdmReqHandler {

	long id = -1;
	long projectId;
	long version = 0;
	String status = "NEW";

	TextBox txtTechnicalName = new TextBox();
	TextBox txtBusinessName = new TextBox();
	TextBox txtDescription = new TextBox();
	TextBox txtPurpose = new TextBox();
	TextBox txtOwner = new TextBox();
	TextBox txtApprover = new TextBox();

	VerticalPanel pnlDbTable = new VerticalPanel();
	VerticalPanel pnlFileTable = new VerticalPanel();
	List<ExpandableTableCols> lstDbTable = new ArrayList<ExpandableTableCols>();
	List<ExpandableFileTableCols> lstFileTable = new ArrayList<ExpandableFileTableCols>();

	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public CreateSourceSystemDlg(long projectId, String projectName, JSONObject data) {
		super(false, false);
		this.projectId = projectId;

		int cw = (Window.getClientWidth() - 50);
		int ch = (Window.getClientHeight() - 50);
		this.setSize(cw + "px", ch + "px");
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize(cw + "px", ch + "px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");
		this.setTitle("Source System for Prokect - " + projectName);
		this.pnlDbTable.setWidth((cw - 20) + "px");

		FlexTable ft = new FlexTable();
		dp.addNorth(ft, 150);

		ft.setText(0, 0, "Technical Name");
		ft.setWidget(0, 1, this.txtTechnicalName);
		this.txtTechnicalName.setWidth("300px");
		ft.setText(0, 2, "Business Name");
		this.txtBusinessName.setWidth("300px");
		ft.setWidget(0, 3, this.txtBusinessName);

		ft.setText(1, 0, "Description");
		ft.getFlexCellFormatter().setColSpan(1, 1, 3);
		this.txtDescription.setWidth("800px");
		ft.setWidget(1, 1, this.txtDescription);

		ft.setText(2, 0, "Purpose");
		ft.getFlexCellFormatter().setColSpan(2, 1, 3);
		this.txtPurpose.setWidth("800px");
		ft.setWidget(2, 1, this.txtPurpose);

		ft.setText(3, 0, "Owner");
		ft.setWidget(3, 1, this.txtOwner);
		ft.setText(3, 2, "Approver");
		ft.setWidget(3, 3, this.txtApprover);

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("Save Source System", new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				saveSourceSystem();
			}
		});
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		btn = new Button("Import Metadata from Database", new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				importDBMetaData();
			}
		});
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);

		btn = new Button("Import File Metadata from Excel", new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				importFileMetaData();
			}
		});
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);

		btn = new Button("Close", new ClickHandler() {

			@Override
			public void onClick(ClickEvent arg0) {
				closeMe();
			}
		});
		btn.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(btn);
		dp.addNorth(fp, 30);

		// Start Source Tab
		TabPanel tpSrc = new TabPanel();
		// Start DB Source tab
		ScrollPanel sp = new ScrollPanel();
		sp.setSize((cw - 10) + "px", "500px");
		sp.setAlwaysShowScrollBars(true);
		sp.add(this.pnlDbTable);
		DockLayoutPanel dpTbl = new DockLayoutPanel(Unit.PX);
		dpTbl.setWidth((cw - 10) + "px");
		dpTbl.setHeight("500px");
		dpTbl.addNorth(new Button("Save All Tables", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				updateDbTables();
			}
		}), 30);
		dpTbl.add(sp);
		tpSrc.add(dpTbl, "DB Source");
		// End DB Source tab
		// Start File Source Tab
		sp = new ScrollPanel();
		sp.setSize((cw - 10) + "px", "500px");
		sp.setAlwaysShowScrollBars(true);
		sp.add(this.pnlFileTable);
		dpTbl = new DockLayoutPanel(Unit.PX);
		dpTbl.setWidth((cw - 10) + "px");
		dpTbl.setHeight("500px");
		dpTbl.addNorth(new Button("Save All Files", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				updateFileTables();
			}
		}), 30);
		dpTbl.add(sp);
		tpSrc.add(dpTbl, "File Source");

		// End File Source Tab
		tpSrc.add(new Label("-----Remote SFTO File Source------"), "SFTP Source");

		dp.add(tpSrc);
		// End Source Tab
		this.add(dp);

		if (data != null) {
			initComponens(data);
		}
	}

	void closeMe() {
		this.hide();
	}

	void updateDbTables() {
		JSONArray arr = new JSONArray();
		int i = 0;
		for (ExpandableTableCols etc : this.lstDbTable) {
			arr.set(i, etc.getJSON());
			i++;
		}

		JSONObject obj = new JSONObject();
		obj.put("sourceSystem", new JSONNumber(this.id));
		obj.put("tables", arr);

		this.service.saveSourceTables(obj.toString(), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String resp) {
				processResp(resp);
			}

			@Override
			public void onFailure(Throwable e) {
				Window.alert(e.getMessage());
			}
		});
	}

	void updateFileTables() {
		JSONArray arr = new JSONArray();
		int i = 0;
		for (ExpandableFileTableCols eftc : this.lstFileTable) {
			arr.set(i, eftc.getJSON());
			i++;
		}

		JSONObject obj = new JSONObject();
		obj.put("sourceSystem", new JSONNumber(this.id));
		obj.put("files", arr);

		this.service.saveSourceFiles(obj.toString(), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String resp) {
				processResp(resp);
			}

			@Override
			public void onFailure(Throwable e) {
				Window.alert(e.getMessage());
			}
		});
	}

	void processResp(String resp) {
		JSONObject obj = JSONParser.parseStrict(resp).isObject();
		if ("SUCCESS".equalsIgnoreCase(obj.get("status").isString().stringValue())) {
			JSONObject out = obj.get("data").isObject();
			initComponens(out);
		} else {
			Window.alert(obj.get("data").isString().stringValue());
		}
	}

	void initComponens(JSONObject data) {
		if (data == null) {
			return;
		}

		if (data.get("id") != null) {
			this.id = (long) data.get("id").isNumber().doubleValue();
		}

		if (data.get("approver") != null) {
			this.txtApprover.setText(data.get("approver").isString().stringValue());
		}
		if (data.get("businessName") != null) {
			this.txtBusinessName.setText(data.get("businessName").isString().stringValue());
		}
		if (data.get("technicalName") != null) {
			this.txtTechnicalName.setText(data.get("technicalName").isString().stringValue());
		}
		if (data.get("description") != null) {
			this.txtDescription.setText(data.get("description").isString().stringValue());
		}
		if (data.get("purpose") != null) {
			this.txtPurpose.setText(data.get("purpose").isString().stringValue());
		}
		if (data.get("owner") != null) {
			this.txtOwner.setText(data.get("owner").isString().stringValue());
		}
		if (data.get("status") != null) {
			this.status = data.get("status").isString().stringValue();
		}

		if (data.get("dbSources") != null) {
			JSONArray arr = data.get("dbSources").isArray();
			if (arr != null && arr.size() > 0) {
				this.pnlDbTable.clear();
				this.lstDbTable.clear();
				processSourceTables(arr);
			}
		}

		if (data.get("fileSources") != null) {
			JSONArray arr = data.get("fileSources").isArray();
			if (arr != null && arr.size() > 0) {
				this.pnlFileTable.clear();
				this.lstFileTable.clear();
				processSourceFiles(arr);
			}
		}

	}

	void saveSourceSystem() {
		try {
			JSONObject obj = new JSONObject();
			obj.put("id", new JSONNumber(this.id));
			obj.put("projectId", new JSONNumber(this.projectId));
			obj.put("version", new JSONNumber(this.version));
			obj.put("technicalName", new JSONString(this.txtTechnicalName.getText()));
			obj.put("businessName", new JSONString(this.txtBusinessName.getText()));
			obj.put("description", new JSONString(this.txtDescription.getText()));
			obj.put("purpose", new JSONString(this.txtPurpose.getText()));
			obj.put("owner", new JSONString(this.txtOwner.getText()));
			obj.put("approver", new JSONString(txtApprover.getText()));
			obj.put("status", new JSONString(this.status));

			this.service.saveSourceSystem(obj.toString(), new AsyncCallback<String>() {
				@Override
				public void onSuccess(String resp) {
					processResp(resp);
					//initComponens(JSONParser.parseStrict(resp).isObject().get("data").isObject());
				}

				@Override
				public void onFailure(Throwable err) {
					Window.alert(err.getMessage());
				}
			});

		} catch (Exception e) {
			Window.alert(e.getMessage());
		}
	}

	void importDBMetaData() {
		MdmReqWin win = new MdmReqWin(this);
		win.showWin();
	}

	void importFileMetaData() {
		if (this.id <= 0) {
			Window.alert("Please save Source System!!");
			return;
		}

		FileUploadWin win = new FileUploadWin(this, this.id);
		win.showMe();
	}

	void processSourceTables(JSONArray arr) {
		int len = arr.size();
		for (int i = 0; i < len; i++) {
			JSONObject obj = arr.get(i).isObject();
			ExpandableTableCols etc = new ExpandableTableCols(obj, this.id);
			this.pnlDbTable.add(etc.getRow());
			this.lstDbTable.add(etc);
		}
	}

	void processSourceFiles(JSONArray arr) {
		int len = arr.size();
		for (int i = 0; i < len; i++) {
			JSONObject obj = arr.get(i).isObject();
			ExpandableFileTableCols etc = new ExpandableFileTableCols(obj, this.id);
			this.pnlFileTable.add(etc.getRow());
			this.lstFileTable.add(etc);
		}
	}

	@Override
	public void getSourceData(final JSONObject jsonDB) {
		this.service.getAllTablesStruct(jsonDB.toString(), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String resp) {
				processResp(resp);
				//initComponens(JSONParser.parseStrict(resp).isObject().get("data").isObject());
			}

			@Override
			public void onFailure(Throwable err) {

			}
		});
	}

	@Override
	public void processFileMeta(String data) {
		processResp(data);
/*		JSONObject res = JSONParser.parseStrict(data).isObject();
		if ("SUCCESS".equalsIgnoreCase(res.get("status").isString().stringValue())) {
			initComponens(res.get("data").isObject());
		} else {
			Window.alert(res.get("data").isString().stringValue());
		}
		*/
	}
}
