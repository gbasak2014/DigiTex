package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.widget.CommonService;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class ServicePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextArea taDesc = new TextArea();
	ListBox lstService = new ListBox();

	CommonService widget;

	Map<String, String> serviceMap = new HashMap<String, String>();
	Map<String, ListBox> paramMap = new HashMap<String, ListBox>();

	VerticalPanel vpParams = new VerticalPanel();
	ListBox lstRetType = new ListBox();
	TextBox txtRetCat = new TextBox();

	List<ColumnDto> fields = new ArrayList<ColumnDto>();
	long projectId;

	//Map<String, SDPWidget> predecesorMap = new HashMap<String, SDPWidget>();

	List<String> lstParamAvailable = new ArrayList<String>();
	
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public ServicePropDlg(SDPWidget widget, long projectId, List<ParamDto> inParams) {
		super(false, false);
		this.widget = (CommonService) widget;
		this.projectId = projectId;
		
		for (SDPWidget w : this.widget.getPredecessors())
		{
			this.lstParamAvailable.add(w.getName());
		}
		for (ParamDto pd : inParams)
		{
			this.lstParamAvailable.add("inParam$" + pd.getParam());
		}
		
		this.setSize("800px", "400px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Filter Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("800px", "400px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		this.taDesc.setEnabled(false);
		hp.add(new Label("Name:"));
		hp.add(txtName);
		hp.add(this.lstService);
		hp.add(new Button("Get Service Details", new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				getServiceDetails();
			}
		}));
		dp.addNorth(hp, 30);

		this.taDesc.setWidth("750px");
		dp.addNorth(this.taDesc, 50);

		VerticalPanel vpw = new VerticalPanel();
		vpw.add(new Label("Input parameters"));
		vpw.add(this.vpParams);
		dp.addWest(vpw, 350);

		VerticalPanel vp = new VerticalPanel();
		this.txtRetCat.setWidth("400px");
		this.lstRetType.setWidth("410px");
		this.lstRetType.setVisibleItemCount(10);
		this.txtRetCat.setEnabled(false);
		vp.add(new Label("Return Type"));
		vp.add(this.txtRetCat);
		vp.add(this.lstRetType);
		dp.add(vp);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
		this.lstService.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				serviceChanged();
			}
		});
	}

	void serviceChanged() {
		int idx = this.lstService.getSelectedIndex();
		if (idx > 0) {
			this.taDesc.setText(this.serviceMap.get(this.lstService.getItemText(idx)));
		}
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());
		this.txtRetCat.setText(this.widget.getReturnCategory());

		this.service.getServiceList(this.projectId, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String json) {
				initServiceList(json);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Error getting service list!!");
			}
		});
	}

	void getServiceDetails() {
		int idx = this.lstService.getSelectedIndex();
		if (idx <= 0) {
			Window.alert("Please select service!!");
			return;
		}
		long sId = Long.parseLong(this.lstService.getItemText(this.lstService.getSelectedIndex()).split("-")[0].trim());
		this.service.getServiceDetail(sId, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String res) {
				processServiceDetails(res);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Error getting service detail!!");
			}
		});
	}

	void initServiceList(String json) {
		JSONObject res = JSONParser.parseStrict(json).isObject();
		if (!"SUCCESS".equalsIgnoreCase(res.get("status").isString().stringValue())) {
			Window.alert(res.get("data").isString().stringValue());
			return;
		}

		JSONArray arr = res.get("data").isArray();
		int s = arr.size();
		this.lstService.addItem("Select Service");
		int selIdx = 0;
		String selDsc = "";
		for (int i = 0; i < s; i++) {
			JSONObject obj = arr.get(i).isObject();
			long sId = (long) obj.get("id").isNumber().doubleValue();
			String key = sId + "-" + obj.get("name").toString().replace("\"", "");
			String desc = obj.get("description").toString();
			this.serviceMap.put(key, desc);
			this.lstService.addItem(key);
			if (sId == this.widget.getServiceId()) {
				selIdx = i + 1;
				selDsc = desc;
			}
		}

		this.taDesc.setText(selDsc);
		this.lstService.setSelectedIndex(selIdx);

		if (selIdx > 0) {
			for (String nm : this.widget.getParams().keySet()) {
				String value = this.widget.getParams().get(nm);
				ListBox lst = new ListBox();
				int i = 0;
				selIdx = 0;
				
				for (String v : this.lstParamAvailable) {
					lst.addItem(v);
					if (value.equals(v)) {
						selIdx = i;
					}
					i++;
				}
				
				lst.setSelectedIndex(selIdx);
				HorizontalPanel hp = new HorizontalPanel();
				hp.add(new Label(nm));
				hp.add(lst);
				this.vpParams.add(hp);
				this.paramMap.put(nm, lst);
			}
		}

		for (ColumnDto dto : this.widget.getFields()) {
			this.lstRetType.addItem(dto.getName() + ": " + dto.getDataType() + (dto.getSensitiveFlag() ? " -> sensitive" : ""));
			this.fields.add(dto);
		}
	}

	void processServiceDetails(String res) {
		JSONObject oRes = JSONParser.parseStrict(res).isObject();
		if (!"SUCCESS".equalsIgnoreCase(oRes.get("status").isString().stringValue())) {
			Window.alert(oRes.get("data").isString().stringValue());
			return;
		}

		JSONObject obj = oRes.get("data").isObject();
		JSONArray pArr = obj.get("params").isArray();
		int s = pArr.size();
		this.vpParams.clear();
		this.paramMap.clear();

		for (int i = 0; i < s; i++) {
			JSONObject po = pArr.get(i).isObject();
			String p = po.get("pos").isNumber().toString() + ": " +  po.get("name").isString().stringValue() + ":" + po.get("dataType").isString().stringValue();
			Label lbl = new Label(p);
			ListBox lst = new ListBox();
			for (String ip : this.lstParamAvailable) {
				lst.addItem(ip);
			}
			HorizontalPanel hp = new HorizontalPanel();
			hp.add(lbl);
			hp.add(lst);
			this.vpParams.add(hp);
			this.paramMap.put(p, lst);
		}

		this.txtRetCat.setText(obj.get("retCategory").isString().stringValue());

		JSONArray rArr = obj.get("returnTypes").isArray();
		s = rArr.size();

		this.fields.clear();
		this.lstRetType.clear();
		for (int i = 0; i < s; i++) {
			JSONObject rO = rArr.get(i).isObject();
			String nm = rO.get("name").isString().stringValue();
			String type = rO.get("dataType").isString().stringValue();
			boolean sensitive = rO.get("sensitive").isBoolean().booleanValue();
			int pos = (int) rO.get("pos").isNumber().doubleValue();

			this.lstRetType.addItem(nm + ": " + type + (sensitive ? " -> sensitive" : ""));

			ColumnDto cd = new ColumnDto();
			cd.setName(nm);
			cd.setDataType(type);
			cd.setPos(pos);
			cd.setSensitiveFlag(sensitive);
			this.fields.add(cd);
		}
	}

	void processOk() {

		int idx = this.lstService.getSelectedIndex();
		if (idx <= 0) {
			Window.alert("Please select service!!");
			return;
		}

		try {
			long sId = Long.parseLong(this.lstService.getItemText(idx).split("-")[0].trim());
			String sName = this.lstService.getItemText(idx).split("-")[1].trim();
			this.widget.setServiceId(sId);
			this.widget.setServiceName(sName);
		} catch (Exception e) {
			Window.alert("ERROR:" + e.getMessage());
			return;
		}

		this.widget.setName(this.txtName.getText());
		this.widget.setReturnCategory(this.txtRetCat.getText());

		Map<String, String> params = this.widget.getParams();
		params.clear();
		for (String p : this.paramMap.keySet()) {
			ListBox lst = this.paramMap.get(p);
			String pNm = lst.getItemText(lst.getSelectedIndex());
			params.put(p, pNm);
		}

		this.widget.getFields().clear();
		for (ColumnDto cd : this.fields) {
			this.widget.getFields().add(cd);
		}

		Window.alert(this.widget.getJSON().toString());

		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
