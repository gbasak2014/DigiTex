package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SubWf;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class SubWfDlg extends SdpDialogBox {
	SubWf subWf;

	Map<String, JSONObject> inParamsMap = new HashMap<String, JSONObject>();
	List<String> args = new ArrayList<String>();
	VerticalPanel vpArgs = new VerticalPanel();
	Map<String, ListBox> argMap = new HashMap<String, ListBox>();

	TextArea taDesc = new TextArea();
	TextArea taFields = new TextArea();
	ListBox lstSubWf = new ListBox();
	TextBox txtName = new TextBox();

	long subWfId;
	List<ParamDto> inParams;
	String subWfName;

	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public SubWfDlg(SubWf subWf, List<ParamDto> inParams) {
		super(false, false);
		this.subWf = subWf;
		this.inParams = inParams;

		for (SDPWidget w : this.subWf.getPredecessors()) {
			args.add(w.getName());
		}

		this.setSize("700px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Sub Workflow - ");
		this.setWidth("700px");
		this.setHeight("500px");

		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("700px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		this.txtName.setWidth("200px");
		this.lstSubWf.setWidth("200px");
		hp.add(new Label("Name:"));
		hp.add(this.txtName);
		hp.add(this.lstSubWf);
		hp.add(new Button("Refresh", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				refresfSubWf();
			}
		}));

		dp.addNorth(hp, 30);
		this.taDesc.setVisibleLines(2);
		this.taDesc.setWidth("690px");
		dp.addNorth(this.taDesc, 60);

		VerticalPanel vp = new VerticalPanel();
		this.vpArgs.setWidth("200px");
		vp.add(new Label("Parameter Argiment Map"));
		vp.add(this.vpArgs);
		dp.addWest(vp, 200);

		this.taFields.setWidth("490px");
		this.taFields.setVisibleLines(20);
		dp.add(this.taFields);

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("OK", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				save();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Close", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				close();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		dp.addSouth(fp, 30);

		this.add(dp);
		this.subWfId = this.subWf.getSubWfId();
		iniSubWfList();
		this.txtName.setText(this.subWf.getName());
		this.taDesc.setText(this.subWf.getDescription());
	}

	void refresfSubWf() {
		int idx = this.lstSubWf.getSelectedIndex();
		if (idx > 0) {
			long id = Long.parseLong(this.lstSubWf.getItemText(idx).split("-")[0].trim());
			if (this.subWfId != id) {
				this.subWfId = id;
				initComponent(this.subWfId);
			}
		}
	}

	void iniSubWfList() {

		this.service.getSubWfs(this.subWf.getProjectId(), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String data) {
				processSubWfList(data);

			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Error getting sun workflow list!!");
			}
		});
	}

	void processSubWfList(String data) {
		JSONArray json = JSONParser.parseStrict(data).isArray();
		int sz = json.size();

		this.lstSubWf.addItem("Select Sub Workflow");
		int selIdx = 0;
		for (int i = 0; i < sz; i++) {
			JSONObject row = json.get(i).isObject();
			this.lstSubWf.addItem(row.get("id").toString() + " - " + row.get("name").toString());
			if (this.subWfId == (long) row.get("id").isNumber().doubleValue()) {
				selIdx = i + 1;
			}
		}

		if (this.subWfId > 0) {
			initComponent(this.subWfId);
		}
		this.lstSubWf.setSelectedIndex(selIdx);
	}

	void initComponent(long sId) {

		if (sId > 0) {
			this.service.getSubWfHeader(sId, new AsyncCallback<String>() {

				@Override
				public void onSuccess(String data) {
					JSONObject resp = JSONParser.parseStrict(data).isObject();
					if ("SUCCESS".equalsIgnoreCase(resp.get("status").isString().stringValue())) {
						JSONObject obj = resp.get("data").isObject();
						processSubWFDetails(obj);
					} else {
						Window.alert(resp.get("data").isString().stringValue());
					}
				}

				@Override
				public void onFailure(Throwable arg0) {
					Window.alert("ERROR - getting sub workflow for id: " + sId);
				}
			});
		}
	}

	void processSubWFDetails(JSONObject wf) {
		JSONObject start = wf.get("start").isObject();
		JSONArray arr = start.get("successors").isArray();
		int s = arr.size();
		this.inParamsMap.clear();
		this.vpArgs.clear();
		this.argMap.clear();
		this.taDesc.setText(start.get("jobDesc").isString().stringValue());
		this.subWfName = start.get("subWfName") != null ? start.get("subWfName").isString().stringValue() : "";

		for (int i = 0; i < s; i++) {
			String sNm = arr.get(i).isString().stringValue();
			JSONObject ss = wf.get(sNm).isObject();
			this.inParamsMap.put(sNm, ss);

			HorizontalPanel hp = new HorizontalPanel();
			ListBox lst = new ListBox();
			for (String arg : this.args) {
				lst.addItem(arg);
			}
			for (ParamDto pd : this.inParams) {
				lst.addItem("inParam$" + pd.getParam());
			}

			Label lbl = new Label(sNm);
			lbl.getElement().getStyle().setBorderColor("GRAY");
			lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
			lbl.setWidth("100px");
			lbl.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent ce) {
					String nm = ((Label) ce.getSource()).getText();
					refreshParamStructure(nm);
				}
			});
			hp.add(lbl);
			hp.add(lst);
			this.vpArgs.add(hp);
			this.argMap.put(i + ":" + sNm, lst);
		}

		for (ParamDto dto : this.subWf.getArgParamList()) {
			String kk = dto.getPos() + ":" + dto.getParam();
			String tp = dto.getType();
			ListBox lb = this.argMap.get(kk);
			if (lb != null) {
				s = lb.getItemCount();
				for (int i = 0; i < s; i++) {
					if (tp.equals(lb.getItemText(i))) {
						lb.setSelectedIndex(i);
						break;
					}
				}
			}
		}

		List<ColumnDto> fields = this.subWf.getFields();
		fields.clear();
		if (wf.get("end") != null) {
			JSONObject end = wf.get("end").isObject();
			this.subWf.setReturnType(end.get("returnType") != null ? end.get("returnType").isString().stringValue() : "DataFrame");
			if (end.get("fields") != null) {
				JSONArray fArr = end.get("fields").isArray();
				s = fArr.size();
				for (int i = 0; i < s; i++) {
					JSONObject f = fArr.get(i).isObject();
					ColumnDto dto = new ColumnDto();
					dto.setDataType(f.get("dataType") != null ? f.get("dataType").isString().stringValue() : "");
					dto.setId(f.get("id") != null ? (long) f.get("id").isNumber().doubleValue() : -1);
					dto.setName(f.get("name") != null ? f.get("name").isString().stringValue() : "");
					dto.setPos(f.get("pos") != null ? (int) f.get("pos").isNumber().doubleValue() : -1);
					dto.setSensitiveFlag(f.get("sensitiveFlag") != null ? "true".equals(f.get("sensitiveFlag").isString().stringValue()) : false);
					fields.add(dto);
				}
			}
		}
	}

	void refreshParamStructure(String pName) {
		JSONObject obj = this.inParamsMap.get(pName);
		JSONArray arr = obj.get("fields").isArray();
		int s = arr.size();
		this.taFields.setText("");
		for (int i = 0; i < s; i++) {
			JSONObject oP = arr.get(i).isObject();
			String nm = oP.get("name").isString().stringValue();
			this.taFields.setText(nm + "\n" + this.taFields.getText());
		}

	}

	void save() {
		int idx = this.lstSubWf.getSelectedIndex();
		if (idx <= 0) {
			Window.alert("Please select sub workflow!!");
			return;
		}

		this.subWf.setName(this.txtName.getText());
		this.subWf.setDescription(this.taDesc.getText());
		this.subWf.setSubWfId(this.subWfId);
		this.subWf.setSubWfName(this.subWfName);

		List<ParamDto> lstPrm = this.subWf.getArgParamList();
		lstPrm.clear();
		for (String prm : this.argMap.keySet()) {
			int pos = Integer.parseInt(prm.split(":")[0].trim());
			String pNm = prm.split(":")[1];
			ListBox lstArg = this.argMap.get(prm);
			String arg = lstArg.getItemText(lstArg.getSelectedIndex());
			ParamDto pd = new ParamDto(-1, pNm, arg, pos);
			lstPrm.add(pd);
		}

		this.hide();
	}

	void close() {
		this.hide();
	}
}
