package com.gb.wf.client.dlg;

import com.gb.wf.client.component.JobDetailRow;
import com.gb.wf.client.handler.JobOpenHandler;
import com.gb.wf.client.handler.WFActionHandler;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class JobDetailDlg extends SdpDialogBox implements JobOpenHandler{
	WFActionHandler handler;
	
	public JobDetailDlg(WFActionHandler handler, String data) {
		this.handler = handler;
		
		this.setSize("750px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Job Details");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		VerticalPanel vp = new VerticalPanel();
		dp.setSize("750px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");
		dp.getElement().getStyle().setWidth(740, Unit.PX);
		
		JSONArray json = JSONParser.parseStrict(data).isArray();
		int sz = json.size();
		vp.add(new JobDetailRow());
		for (int i=0; i<sz; i++)
		{
			JSONObject row = json.get(i).isObject();
			vp.add(new JobDetailRow(row.get("id").toString(), row.get("name").toString(), row.get("desc").toString(), this));
		}
		
		FlowPanel fp = new FlowPanel();
		Button btn = new Button("Close");
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				closeMe();
			}
		});
		
		dp.add(vp);
		dp.addSouth(fp, 30);
		this.add(dp);
	}
	
	void closeMe()
	{
		this.hide();
	}
	
	@Override
	public void openJob(long jobId) {
		this.handler.openWorkflow(jobId);
		this.closeMe();
	}
}
