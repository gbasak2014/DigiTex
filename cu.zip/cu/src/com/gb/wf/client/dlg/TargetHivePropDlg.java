package com.gb.wf.client.dlg;

import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.TargetHive;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class TargetHivePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtSchema = new TextBox();
	TextBox txtTable = new TextBox();
	CheckBox chkOverwrite = new CheckBox();

	TextBox txtPath = new TextBox();
	ListBox lstPartition = new ListBox();

	TargetHive widget;

	public TargetHivePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (TargetHive) widget;

		this.setSize("600px", "300px");
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("650px", "300px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		VerticalPanel vp = new VerticalPanel();

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtName);
		vp.add(hp);
		// dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Schema:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtSchema.setWidth("450px");
		this.txtSchema.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtSchema);

		lbl = new Label("Table:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtTable.setWidth("450px");
		this.txtTable.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtTable);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Target Path:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtPath.setWidth("450px");
		this.txtPath.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtPath);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Overwrite:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.chkOverwrite.setWidth("450px");
		this.chkOverwrite.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.chkOverwrite);

		lbl = new Label("Partition By:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.lstPartition.setWidth("450px");
		this.lstPartition.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.lstPartition);
		vp.add(hp);

		this.lstPartition.addItem("Select pattern");
		this.lstPartition.addItem("Execution Date (yyyyMMdd)");
		this.lstPartition.addItem("Execution Month (yyyyMM)");
		this.lstPartition.addItem("Execution Year (yyyy)");
		this.lstPartition.addItem("Execution Hour (yyyyMMddHH)");

		dp.add(vp);
		// dp.addNorth(hp, 30);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
		this.chkOverwrite.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
			@Override
			public void onValueChange(ValueChangeEvent<Boolean> arg0) {
				overwriteChanged();
			}
		});
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());
		this.txtPath.setText(this.widget.getPath());
		this.txtSchema.setText(this.widget.getSchema());
		this.txtTable.setText(this.widget.getTable());
		this.chkOverwrite.setValue(this.widget.isOverwrite());

		if (!this.widget.isOverwrite()) {
			for (int i = 0; i < this.lstPartition.getItemCount(); i++) {
				if (this.widget.getPartition().equals(this.lstPartition.getItemText(i))) {
					this.lstPartition.setSelectedIndex(i);
					break;
				}
			}
		}

	}

	void overwriteChanged() {
		if (this.chkOverwrite.getValue()) {
			this.lstPartition.setEnabled(false);
		} else {
			this.lstPartition.setEnabled(true);
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		this.widget.setPath(this.txtPath.getText());
		this.widget.setSchema(this.txtSchema.getText());
		this.widget.setTable(this.txtTable.getText());
		this.widget.setOverwrite(this.chkOverwrite.getValue());

		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
