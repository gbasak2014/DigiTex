package com.gb.wf.client.dlg;

import com.gb.wf.client.LoginService;
import com.gb.wf.client.LoginServiceAsync;
import com.gb.wf.client.component.LoginPanel;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class UserRegistrationDlg extends DockLayoutPanel {
	private final LoginServiceAsync service = GWT.create(LoginService.class);

	TextBox txtLoginid = new TextBox();
	TextBox txtName = new TextBox();
	TextBox txtEmail = new TextBox();
	TextBox txtQuestion1 = new TextBox();
	TextBox txtQuestion2 = new TextBox();
	TextBox txtAnswer1 = new TextBox();
	TextBox txtAnswer2 = new TextBox();
	PasswordTextBox ptxt1 = new PasswordTextBox();
	PasswordTextBox ptxt2 = new PasswordTextBox();

	TextBox txtProjectName = new TextBox();
	TextBox txtProjectDesc = new TextBox();
	TextBox txtClusterHost = new TextBox();
	TextBox txtClusterPort = new TextBox();
	TextBox txtClusterUser = new TextBox();
	TextBox txtClusterHome = new TextBox();
	PasswordTextBox txtClusterPwd = new PasswordTextBox();

	Label lblMsg = new Label();

	public UserRegistrationDlg() {
		super(Unit.PX);

		setSize("500px", "550px");

		VerticalPanel vp = new VerticalPanel();
		vp.setSize("500px", "550px");
		lblMsg.getElement().getStyle().setBackgroundColor("#ff0000");

		vp.add(lblMsg);
		Label lbl = new Label("User Registration");
		lbl.setStyleName("titleText");
		vp.add(lbl);

		HorizontalPanel hp = new HorizontalPanel();
		lbl = new Label("Login Id:");
		lbl.setWidth("150px");
		this.txtLoginid.setWidth("200px");
		hp.add(lbl);
		hp.add(txtLoginid);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Name:");
		lbl.setWidth("150px");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(txtName);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Email:");
		lbl.setWidth("150px");
		this.txtEmail.setWidth("200px");
		hp.add(lbl);
		hp.add(txtEmail);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Security Question one:");
		lbl.setWidth("150px");
		this.txtQuestion1.setWidth("200px");
		hp.add(lbl);
		hp.add(txtQuestion1);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Answer:");
		lbl.setWidth("150px");
		this.txtAnswer1.setWidth("200px");
		hp.add(lbl);
		hp.add(txtAnswer1);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Security Question two:");
		lbl.setWidth("150px");
		this.txtQuestion2.setWidth("200px");
		hp.add(lbl);
		hp.add(txtQuestion2);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Answer:");
		lbl.setWidth("150px");
		this.txtAnswer2.setWidth("200px");
		hp.add(lbl);
		hp.add(txtAnswer2);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Password:");
		lbl.setWidth("150px");
		this.ptxt1.setWidth("200px");
		hp.add(lbl);
		hp.add(ptxt1);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Retype Password:");
		lbl.setWidth("150px");
		this.ptxt2.setWidth("200px");
		hp.add(lbl);
		hp.add(ptxt2);
		vp.add(hp);

		// Project details
		hp = new HorizontalPanel();
		lbl = new Label("Project Name:");
		lbl.setWidth("150px");
		this.txtProjectName.setWidth("200px");
		hp.add(lbl);
		hp.add(txtProjectName);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Project Description:");
		lbl.setWidth("150px");
		this.txtProjectDesc.setWidth("200px");
		hp.add(lbl);
		hp.add(txtProjectDesc);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Hadoop Cluster Host:");
		lbl.setWidth("150px");
		this.txtClusterHost.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtClusterHost);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("SFTP Port:");
		lbl.setWidth("150px");
		this.txtClusterPort.setWidth("50px");
		hp.add(lbl);
		hp.add(this.txtClusterPort);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Connection User:");
		lbl.setWidth("150px");
		this.txtClusterUser.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtClusterUser);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Password:");
		lbl.setWidth("150px");
		this.txtClusterPwd.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtClusterPwd);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Project Home in Cluster:");
		lbl.setWidth("150px");
		this.txtClusterHome.setWidth("300px");
		hp.add(lbl);
		hp.add(this.txtClusterHome);
		vp.add(hp);

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("Register", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Cancel", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		vp.add(fp);

		this.add(vp);
	}

	void processOk() {
		try {
			JSONObject json = new JSONObject();
			json.put("userId", new JSONString(txtLoginid.getText()));
			json.put("name", new JSONString(txtName.getText()));
			json.put("email", new JSONString(txtEmail.getText()));
			json.put("question1", new JSONString(txtQuestion1.getText()));
			json.put("question2", new JSONString(txtQuestion2.getText()));
			json.put("answer1", new JSONString(txtAnswer1.getText()));
			json.put("answer2", new JSONString(txtAnswer2.getText()));
			json.put("ptxt1", new JSONString(ptxt1.getText()));
			json.put("ptxt2", new JSONString(ptxt2.getText()));

			json.put("projectName", new JSONString(txtProjectName.getText()));
			json.put("projectDesc", new JSONString(txtProjectDesc.getText()));
			json.put("clusterUser", new JSONString(this.txtClusterUser.getText()));
			json.put("clusterPwd", new JSONString(this.txtClusterPwd.getText()));
			json.put("clusterHost", new JSONString(this.txtClusterHost.getText()));
			json.put("clusterPort", new JSONString(this.txtClusterPort.getText()));
			json.put("clusterHome", new JSONString(this.txtClusterHome.getText()));

			this.service.registerUser(json.toString(), new AsyncCallback<String>() {
				@Override
				public void onSuccess(String res) {
					processRegister(res);
				}

				@Override
				public void onFailure(Throwable tt) {
					Window.alert("ERROR:" + tt.getMessage());
				}
			});

		} catch (Exception e) {
		}
	}

	void processCancel() {
		RootPanel.get().clear();
		RootPanel.get().add(new LoginPanel());
	}

	void processRegister(String res) {
		if ("ERROR".equals(res)) {
			lblMsg.setText("Error registering user!!!");
		} else {
			JSONObject json = (JSONObject) JSONParser.parseStrict(res);
			String status = json.get("status").isString().stringValue();
			if ("EXIST".equals(status)) {
				lblMsg.setText("User exist with the Id.");
			} else if ("FAIL".equals(status)) {
				lblMsg.setText("Fail to register user!!");
			} else if ("SUCCESS".equals(status)) {
				Window.alert("Registration success, please login...");
				RootPanel.get().clear();
				RootPanel.get().add(new LoginPanel());
			}
		}
	}
}
