package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.SourceColumnTable;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class SourceMetaDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextArea taDesc = new TextArea();
	TextBox txtSource = new TextBox();
	TextBox txtUser = new TextBox();
	TextBox txtPwd = new TextBox();
	ListBox lstDataType = new ListBox();
	ListBox lstSourceType = new ListBox();
	ListBox lstRecType = new ListBox();
	Label lblSource = new Label("Source Path");
	Label lblDel = new Label("Source Path");
	TextBox txtDel = new TextBox();

	SourceColumnTable columnTable;

	List<String> srcType;
	List<String> recType;
	List<String> dataType;

	/*
	 * String technicalName; String businessName; String description; String
	 * purpose;
	 * 
	 * String owner; String approver;
	 * 
	 * String status;
	 * 
	 */
	long projectId;
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public SourceMetaDlg(long projectId, List<String> srcType, List<String> recType, List<String> dataType) {
		super(false, false);
		this.srcType = srcType;
		this.recType = recType;
		this.dataType = dataType;
		this.projectId = projectId;

		int cw = Window.getClientWidth() - 50;
		int ch = Window.getClientHeight() - 50;

		this.setSize(cw + "px", ch + "px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Configure Source Metadata");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize(cw + "px", ch + "px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.getElement().getStyle().setWidth(200, Unit.PX);
		this.lstSourceType.getElement().getStyle().setFloat(Float.LEFT);
		this.lstRecType.getElement().getStyle().setFloat(Float.LEFT);
		this.lblDel.getElement().getStyle().setFloat(Float.LEFT);
		this.txtDel.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(this.txtName);
		fp.add(this.lstSourceType);
		fp.add(this.lstRecType);
		fp.add(this.lblDel);
		fp.add(this.txtDel);

		vpn.add(fp);
		this.taDesc.setVisibleLines(2);
		this.taDesc.getElement().getStyle().setWidth(500, Unit.PX);
		vpn.add(new Label("Description"));
		vpn.add(this.taDesc);
		fp = new FlowPanel();
		this.lblSource.getElement().getStyle().setFloat(Float.LEFT);
		this.txtSource.getElement().getStyle().setFloat(Float.LEFT);
		this.txtSource.getElement().getStyle().setWidth(400, Unit.PX);

		fp.add(this.lblSource);
		fp.add(this.txtSource);
		vpn.add(fp);
		fp = new FlowPanel();
		lbl = new Label("User:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtUser.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(this.txtUser);
		lbl = new Label("Password:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtPwd.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(this.txtPwd);
		vpn.add(fp);
		dp.addNorth(vpn, 160);
		this.columnTable = new SourceColumnTable(this.dataType);
		HorizontalPanel hp = new HorizontalPanel();

		hp.add(this.columnTable);

		dp.add(hp);
		fp = new FlowPanel();
		Button btnOk = new Button("ADD");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);
		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		FlexTable t = new FlexTable();
		t.setSize(cw + "px", "200px");
		t.getElement().getStyle().setBorderColor("#0");
		ScrollPanel spt = new ScrollPanel(t);
		spt.setSize(cw + "px", "100px");
		for (int r = 0; r < 10; r++)
		{
			for (int c = 0; c < 5; c++)
			{
				t.setText(r, c, "Row-" + r + " Col-" + c);
			}
			Button btn = new Button("View");
			btn.setTitle("row-"+r);
			btn.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent ce) {
					String xx = ((Button)ce.getSource()).getTitle();	
					test(xx);
				}
			});
			t.setWidget(r, 5, btn);
			
			if (r%2 == 0)
			{
				t.getRowFormatter().addStyleName(r, "flexTable-OddRow");
			}
			else
			{
				t.getRowFormatter().addStyleName(r, "flexTable-EvenRow");
			}
		}
		
		dp.addSouth(spt, 100);
		this.add(dp);
		this.initComponens();
		if (this.columnTable.getModel().size() <= 0) {
			this.columnTable.insertRow();
		}

		this.lstSourceType.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				SourceTypeChanged();
			}
		});

		this.lstRecType.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				recTypeChanged();
			}
		});
	}

	void test(String no)
	{
		Window.alert("Number:" + no);
	}
	
	void initComponens() {
		this.lstSourceType.addItem("Select Source Type");
		this.lstRecType.addItem("Select Record Format");

		for (String s : this.srcType) {
			this.lstSourceType.addItem(s);
		}
		for (String s : this.recType) {
			this.lstRecType.addItem(s);
		}
	}

	void processOk() {

		JSONObject json = this.getJSON();
		json.put("projectId", new JSONNumber(this.projectId));

		this.service.saveSourceMetaDate(json.toString(), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String res) {
				if (res.startsWith("SUCCESS")) {
					String id = res.split(":")[1];
					Window.alert("Metadata saved successfuly with Id:" + id);
				} else {
					Window.alert("Could not save Metadata");
				}
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("System ERROR!!!");
			}
		});
	}

	void processCancel() {
		this.hide();
	}

	void SourceTypeChanged() {
		String v = this.lstSourceType.getItemText(this.lstSourceType.getSelectedIndex());
		if ("FILE".equalsIgnoreCase(v)) {
			this.lblSource.setText("Source Path:");
			this.lblDel.setText("Delimiter");
			this.txtUser.setEnabled(false);
			this.txtPwd.setEnabled(false);
		} else {
			this.lblSource.setText("JDBC URL:");
			this.lblDel.setText("Schema:Table");
			this.txtDel.setTitle("Enter <Schema Name>:<Table Name>");
			this.txtUser.setEnabled(true);
			this.txtPwd.setEnabled(true);
		}
	}

	void recTypeChanged() {
		String v = this.lstRecType.getItemText(this.lstRecType.getSelectedIndex());
		if ("XML".equals(v)) {
			this.lblDel.setText("Record Element");
			this.txtDel.setEnabled(true);
			this.txtDel.setTitle("Enter Record Element");
		} else if (v.startsWith("DEL")) {
			this.lblDel.setText("Delimiter");
			this.txtDel.setEnabled(true);
			this.txtDel.setTitle("Enter Field Separator");
		} else {
			this.txtDel.setEnabled(false);
			this.txtDel.setTitle("");
		}
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("columnTable", this.columnTable.getJSON());
		json.put("delimiter", new JSONString(this.txtDel.getText()));
		json.put("description", new JSONString(this.taDesc.getText()));
		json.put("metaName", new JSONString(this.txtName.getText()));
		json.put("password", new JSONString(this.txtPwd.getText()));
		json.put("recordType", new JSONString(this.lstRecType.getItemText(this.lstRecType.getSelectedIndex())));
		json.put("source", new JSONString(this.txtSource.getText()));
		json.put("sourceType", new JSONString(this.lstSourceType.getItemText(this.lstSourceType.getSelectedIndex())));
		json.put("user", new JSONString(this.txtUser.getText()));
		json.put("projectId", new JSONNumber(this.projectId));

		return json;
	}
}
