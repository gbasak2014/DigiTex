insert into SOURCE_TYPE values('FILE','Source data is file which is located in edge node');
insert into SOURCE_TYPE values('RDBMS','Source data is RDBMS');
insert into SOURCE_TYPE values('HIVE','Source data is Hive');

insert into RECORD_TYPE values('DELIMIMTED','Record is delimited');
insert into RECORD_TYPE values('XML','Record is in XML format');
insert into RECORD_TYPE values('FIXED','Record is in FIXED length');
insert into RECORD_TYPE values('JSON','Record is in JSON format');

insert into DATA_TYPE values('String','String');
insert into DATA_TYPE values('Integer','Integer');
insert into DATA_TYPE values('Long','Long');
insert into DATA_TYPE values('Double','Double');
insert into DATA_TYPE values('DataFrame','DataFrame');
insert into DATA_TYPE values('Row','Row');

insert into ROLE_DETAIL values ('1', 'ADMIN');
insert into ROLE_DETAIL values ('2', 'USER');
commit;
