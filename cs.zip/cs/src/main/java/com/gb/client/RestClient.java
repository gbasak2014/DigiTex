package com.gb.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.gb.common.dto.JobDto;
import com.google.gson.Gson;

public class RestClient {

	static HttpURLConnection getConnection(String cnnUrl, String method) throws Exception {
		URL url = new URL(cnnUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);

		conn.setRequestMethod(method);

		conn.setRequestProperty("Content-Type", "application/json");
		return conn;
	}
	
	public static void main1(String[] args) {

		try {
			String url = "http://localhost:8080/sdfService/project/projectsource/1";
			HttpURLConnection cnn = getConnection(url, "GET");
			
			//JSONObject json = new JSONObject();
			//json.put("userId", "shourya");
			//json.put("password", "1234");
			
			//System.out.println(json.toString());
			
			//OutputStream os = cnn.getOutputStream();
			//os.write(json.toString().getBytes());
			//os.flush();

			BufferedReader br = new BufferedReader(new InputStreamReader(cnn.getInputStream()));
			String line = br.readLine();
			System.out.println(line);
			
			JSONParser p = new JSONParser();
		
			JSONArray arr = new JSONArray(line);
			JSONObject o = (JSONObject)arr.get(1);
			System.out.println(o.get("metaName"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		List<JobDto> list = new ArrayList<JobDto>();
		list.add(new JobDto(100, "job-100", "desc 100"));
		list.add(new JobDto(200, "job-200", "desc 200"));
		list.add(new JobDto(300, "job-300", "desc 300"));
		list.add(new JobDto(400, "job-400", "desc 400"));
		
		JSONParser p = new JSONParser();
		Gson g = new Gson();
		System.out.println(g.toJson(list));
	}
}
