package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.InParamDto;
import com.gb.common.job.dto.StartDto;
import com.gb.common.job.util.ComponentTypes;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;
import com.gb.spark.wf.dependency.mvn.MavenDependency;

public class StartTask extends AbstractTask {

	boolean sparkConfig;
	boolean sparkContext;
	boolean streamingCntext;
	boolean hiveContext;

	public StartTask(StartDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList, Map<String, String> inParams) {
		super(dto, actions, imports, dependencyList, configList);
		for (InParamDto p : dto.getParams()) {
			inParams.put(p.getParam(), p.getType());
		}

		configList.setConfig(JobConstants.PARAM_JOB_NAME, dto.getJobName());
		System.out.println(JobConstants.PARAM_JOB_NAME + ">>>" + dto.getJobName());
		System.out.println(JobConstants.PARAM_JOB_NAME + ">>>" + configList.getConfig(JobConstants.PARAM_JOB_NAME));
	}

	@Override
	public String getCode() {
		identifyContextRequire();

		if (this.sparkConfig) {
			this.dependencyList.addDependency("sparkConfig", new MavenDependency("org.apache.spark", "spark-core_2.10", "1.5.2", MavenDependency.MAVEN));
			this.imports.addImport("org.apache.spark.SparkConf");
			this.configList.setConfig(JobConstants.PARAM_SPARK_FLAG, JobConstants.TRUE);
		}

		if (this.sparkContext) {
			this.imports.addImport("org.apache.spark.SparkContext");
			this.configList.setConfig(JobConstants.PARAM_SPARK_FLAG, JobConstants.TRUE);
		}

		if (this.hiveContext) {
			this.dependencyList.addDependency("hiveContext-1", new MavenDependency("org.apache.spark", "spark-sql_2.10", "1.5.2", MavenDependency.MAVEN));
			this.dependencyList.addDependency("hiveContext-2", new MavenDependency("org.apache.spark", "spark-hive_2.10", "1.5.2", MavenDependency.MAVEN));
			this.imports.addImport("org.apache.spark.sql.hive.HiveContext");
			this.configList.setConfig(JobConstants.PARAM_HIVE_FLAG, JobConstants.TRUE);
			this.configList.setConfig(JobConstants.PARAM_SPARK_FLAG, JobConstants.TRUE);
		}

		if (this.streamingCntext) {
			this.dependencyList.addDependency("streamingCntext", new MavenDependency("org.apache.spark", "spark-streaming_2.10", "1.5.0", MavenDependency.MAVEN));
			this.imports.addImport("org.apache.spark._");
			this.imports.addImport("org.apache.spark.streaming._");
			this.imports.addImport("org.apache.spark.streaming.StreamingContext._");
			this.configList.setConfig(JobConstants.PARAM_STREAM_FLAG, JobConstants.TRUE);
			this.configList.setConfig(JobConstants.PARAM_SPARK_FLAG, JobConstants.TRUE);
		}

		return null;
	}

	private void identifyContextRequire() {
		for (BaseDto d : this.actions.values()) {
			switch (d.getComponentType()) {
			case ComponentTypes.SOURCE_LOCAL:
				break;
			case ComponentTypes.SOURCE_HDFS:
			case ComponentTypes.TRANSFORMATION:
			case ComponentTypes.FILTER:
			case ComponentTypes.GROUP:
			case ComponentTypes.JOIN:
			case ComponentTypes.SPLIT:
			case ComponentTypes.SORT:
			case ComponentTypes.TARGET_HDFS:
			case ComponentTypes.SOURCE_HIVE:
			case ComponentTypes.TARGET_HIVE:
				this.sparkConfig = true;
				this.sparkContext = true;
				this.hiveContext = true;
				break;
			case ComponentTypes.SOURCE_KAFKA:
			case ComponentTypes.SOURCE_FLUME:
			case ComponentTypes.SOURCE_FILE_STREAM:
			case ComponentTypes.SOURCE_TCP:
				this.sparkConfig = true;
				this.sparkContext = true;
				this.streamingCntext = true;
				break;
			}
		}
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return null;
	}
}
