package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.OrderByDto;
import com.gb.common.job.dto.SortDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class SortTask extends AbstractTask {

	public SortTask(SortDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		SortDto sd = (SortDto) this.dto;
		String dfName = sd.getDataFrameName();
		//String parentDf = sd.getDataFrameName(sd.getPredecessors().get(0));
		String parentDf = this.actions.get(sd.getPredecessors().get(0)).getVariableName();
		
		code.append("\nval ").append(dfName).append(" = ");
		code.append(parentDf).append(".sort(");
		StringBuffer bff = new StringBuffer();
		for (OrderByDto obd : sd.getOrderBy()) {
			if (bff.length() > 0) {
				bff.append(",");
			}
			bff.append(dfName).append(".col(\"").append(obd.getColumn()).append("\").")
					.append("DESC".equalsIgnoreCase(obd.getOrder()) ? "desc" : "asc");
		}
		code.append(bff.toString());
		code.append(")");

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
