package com.gb.spark.wf.component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Map;

import com.gb.common.SDPConstnts;
import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.SqoopDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class SqoopTask extends AbstractTask {

	public SqoopTask(SqoopDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList, Map<String, String> inParams) {
		super(dto, actions, imports, dependencyList, configList);
		sqoopExecScript(dto);
		generateSqoopJobCreateScript(dto);
	}

	@Override
	public String getCode() {
		return null;
	}

	void sqoopExecScript(SqoopDto sd) {
		StringBuffer code = new StringBuffer();

		code.append("\n").append(sd.getName()).append("_st_sec=$(date +'%s')");
		code.append("\n#Delete target data directory if exist");
		code.append("\nif hadoop fs -test -d ").append(sd.getTargetDir());
		code.append("\nthen");
		code.append("\n   echo \"Deleting ").append(sd.getTargetDir()).append("\"");
		code.append("\n   hadoop fs -rm -r ").append(sd.getTargetDir());
		code.append("\nfi");
		code.append("\n\n#execute Sqoop import");
		code.append("\nsqoop --exec ").append(sd.getName());
		code.append("\n\n").append(sd.getName()).append("_et_sec=$(date +'%s')");
		code.append("\n").append(sd.getName()).append("time=((").append(sd.getName()).append("_et_sec - ").append(sd.getName()).append("_st_sec ))");
		code.append("\necho \"Sqoop import completed in ${").append(sd.getName()).append("time} seconds \"");

		String tmpPath = this.configList.getConfig(SDPConstnts.CODE_TMP_PATH);
		File file = new File(tmpPath);
		if (!file.exists()) {
			file.mkdirs();
		}
		if (file.exists() && !file.isDirectory()) {
			file.delete();
		}

		String execFile = sd.getName() + SDPConstnts.SQOOP_JOB_EXEC_SUFF;
		file = new File(file.getAbsolutePath() + "/" + execFile);
		if (file.exists()) {
			file.delete();
		}

		try {
			OutputStream out = new FileOutputStream(file);
			out.write(code.toString().getBytes());
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * sqoop job --create $JOB_NAME -- import --connect
	 * jdbc:mysql://10.112.13.91/nagios001?zeroDateTimeBehavior=convertToNull
	 * --username oaasimi --password '0aas!m!@20!7$' --driver
	 * com.mysql.jdbc.Driver --table nagios_commenthistory --target-dir
	 * ${IMPORT_PATH} --outdir /app/nagios-import/job/outclass
	 * --fields-terminated-by '\001' --check-column entry_time --incremental
	 * lastmodified --last-value '0000-00-00 00:00:00'
	 */
	void generateSqoopJobCreateScript(SqoopDto sd) {
		String tmpPath = this.configList.getConfig(SDPConstnts.CODE_TMP_PATH);
		File file = new File(tmpPath);
		if (!file.exists()) {
			file.mkdirs();
		}
		if (file.exists() && !file.isDirectory()) {
			file.delete();
		}

		String genFile = sd.getName() + SDPConstnts.SQOOP_JOB_CREATE_SUFF;
		file = new File(file.getAbsolutePath() + "/" + genFile);
		if (file.exists()) {
			file.delete();
		}

		try {
			OutputStream out = new FileOutputStream(file);
			out.write(sd.getCreateJobScript().getBytes());
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
