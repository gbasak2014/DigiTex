package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.TargetJSONDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class TargetJSONTask extends AbstractTask {

	public TargetJSONTask(TargetJSONDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		TargetJSONDto tjd = (TargetJSONDto) this.dto;
		code.append("\n//Destination Path");
		//String df = tjd.getDataFrameName(tjd.getPredecessors().get(0));
		String df = this.actions.get(tjd.getPredecessors().get(0)).getVariableName();
		configList.setConfig(JobConstants.PARAM_TASK_TARGET, tjd.getPath(), tjd.getName());
		code.append("\n");
		code.append(InstanceList.dfServiceInstance).append(".saveAsJSONFile(")
		.append(df).append(", \"")
		.append(tjd.getName()).append("\")\n");

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return null;
	}
}
