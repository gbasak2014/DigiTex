package com.gb.spark.wf.component;

import java.util.List;
import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnDto;
import com.gb.common.job.dto.SourceHiveDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class SourceHiveTask extends AbstractTask {

	public SourceHiveTask(SourceHiveDto dto, Map<String, BaseDto> actions, ImportList imports,
			DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		SourceHiveDto sh = (SourceHiveDto) this.dto;
		String dfName = sh.getDataFrameName();

		List<ColumnDto> fields = sh.getFields();
		int len = fields.size();
		code.append("\\Get dataframe from hive\n");
		code.append("val ").append(dfName).append(" = ").append(JobConstants.VAR_HIVE_CONTEXT).append(".sql(\"\"\"SELECT ");
		for (int i = 0; i < len; i++) {
			if (i > 0) {
				code.append(", ");
			}
			code.append(fields.get(i).getName());
		}

		code.append(" FROM ").append(sh.getSchema()).append(".").append(sh.getTable());
		code.append(this.getCondition(sh));
		code.append("\"\"\")");
		
		return code.toString();
	}

	String getCondition(SourceHiveDto sh)
	{
		String cond = sh.getCondition();
		if (cond != null && cond.trim().length() > 0)
		{
			return " WHERE " + cond;
		}
		
		return "";
	}
	
	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
