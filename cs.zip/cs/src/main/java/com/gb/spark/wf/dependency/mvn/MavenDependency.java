package com.gb.spark.wf.dependency.mvn;

public class MavenDependency {
	String groupId = "org.apache.spark"; // code and jar name too
	String artifactId = "spark-core_2.10";
	String version = "1.5.1";

	int type;

	public final static int MAVEN = 0;
	public final static int CLASS = 1;
	public final static int JAR = 2;

	public MavenDependency(String code, int type) {
		this.groupId = code;
		this.type = type;
	}

	public MavenDependency(String groupId, String artifactId, String version, int type) {
		this.groupId = groupId;
		this.artifactId = artifactId;
		this.version = version;
		this.type = type;
	}

	@Override
	public int hashCode() {
		return (this.groupId + ":" + this.artifactId).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj != null && obj instanceof MavenDependency) {
			MavenDependency other = (MavenDependency) obj;
			return this.groupId.equals(other.groupId) && this.artifactId.equals(other.artifactId);
		}

		return false;
	}

	@Override
	public String toString() {
		if (this.type == JAR || this.type == CLASS) {
			return this.groupId;
		}

		StringBuffer buff = new StringBuffer();
		buff.append("   <dependency>\n");
		buff.append("      <groupId>").append(this.groupId).append("</groupId>\n");
		buff.append("      <artifactId>").append(this.artifactId).append("</artifactId>\n");
		buff.append("      <version>").append(this.version).append("</version>\n");
		buff.append("   </dependency>\n");

		return buff.toString();
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getArtifactId() {
		return artifactId;
	}

	public void setArtifactId(String artifactId) {
		this.artifactId = artifactId;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getJarName() {
		return this.groupId;
	}

	public String getClassCode() {
		return this.groupId;
	}
	
	public int getType()
	{
		return this.type;
	}
}
