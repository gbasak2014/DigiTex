package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnTransformationDto;
import com.gb.common.job.dto.TransformationDto;
import com.gb.common.job.transformation.IfElseUdf;
import com.gb.common.job.transformation.Transformation;
import com.gb.common.job.transformation.TransformationFactory;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class TransformationTask extends AbstractTask {

	IfElseUdf udf;
	
	public TransformationTask(TransformationDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList,
			ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
		this.imports.addImport("org.apache.spark.sql.functions._");
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		TransformationDto td = (TransformationDto) this.dto;
		String parent = td.getPredecessors().get(0);
		//String parentDf = td.getDataFrameName(parent);
		String parentDf = this.actions.get(parent).getVariableName();
		
		code.append("\n//Select columns");
		code.append("\nval ").append(td.getDataFrameName()).append(" = ").append(getSelect(parentDf));
		
		return code.toString();
	}

	private String getSelect(String df) {
		StringBuffer sel = new StringBuffer();
		TransformationDto td = (TransformationDto) this.dto;
		sel.append(df);
		sel.append(".select(");
		boolean isFirst = true;
		for (ColumnTransformationDto t : td.getTransformations()) {
			if (!isFirst) {
				sel.append("\n\t,");
			}
			isFirst = false;
			
			System.out.println("-------------------------------------------------------");
			System.out.println(t.getTransform());
			System.out.println("-------------------------------------------------------");
			Transformation tf = TransformationFactory.getTransformation(t.getTransform(), df);
			sel.append(tf.evaluate()).append(".as(\"").append(t.getTargetField()).append("\")");
			
			if (t.getTransform().startsWith("If-Else-If"))
			{
				udf = (IfElseUdf)tf;
			}
		}

		sel.append(")");
		return sel.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}

	public IfElseUdf getIfElseUDF()
	{
		return this.udf;
	}
}
