package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.SourceLocalDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class SourceLocalTask extends AbstractTask {

	public SourceLocalTask(SourceLocalDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList,
			ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		SourceLocalDto sld = (SourceLocalDto) this.dto;
		String taskName = this.dto.getName();
		this.configList.setConfig(JobConstants.PARAM_TASK_SOURCE, sld.getSourcePath(), taskName);
		this.configList.setConfig(JobConstants.PARAM_TASK_TARGET, sld.getTargetPath(), taskName);
		this.configList.setConfig(JobConstants.PARAM_TASK_DEL_SUCCESS, String.valueOf(sld.isDeleteOnSuccess()), taskName);
		this.configList.setConfig(JobConstants.PARAM_TASK_REN_SUCCESS, String.valueOf(sld.isRenameOnSuccess()), taskName);
		this.configList.setConfig(JobConstants.PARAM_TASK_REN_SUFFIX, sld.getSuffix(), taskName);
		this.configList.addConfig(JobConstants.PARAM_LIST_TASK_FILE_CPPY, taskName);

		this.configList.setConfig(JobConstants.PARAM_LOCAL_FLAG, JobConstants.TRUE);

		return null;
	}

	@Override
	public String getCleanupCode() {
		return dto.getName() + "Service.cleanup();";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
