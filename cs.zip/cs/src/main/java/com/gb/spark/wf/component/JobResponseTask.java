package com.gb.spark.wf.component;

import java.util.Map;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.gb.common.config.JobConfiguration;
import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.JobResponseDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;
import com.gb.spark.wf.dependency.mvn.MavenDependency;

public class JobResponseTask extends AbstractTask {
	Map<String, String> inParams;
	static final Logger logger = Logger.getLogger(JobConfiguration.class);
	
	public JobResponseTask(JobResponseDto dto, Map<String, BaseDto> actions, ImportList imports,
			DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
		logger.debug("Entered JobResponseTask");
		this.inParams = inParams;
		this.imports.addImport("java.util._");
		this.imports.addImport("org.apache.spark.sql.DataFrame");

		String df = dto.getDataFrameName();
		JobResponseDto jrd = (JobResponseDto) this.dto;

		this.configList.setConfig(df + ".url", jrd.getTargetUrl());
		this.configList.setConfig(df + ".user", jrd.getTargetUser());
		this.configList.setConfig(df + ".pwd", jrd.getTargetPwd());
		this.configList.setConfig(df + ".table", jrd.getTargetTable());
		this.configList.setConfig(df + ".key.column", jrd.getTargetKeyColumn());
		this.configList.setConfig(df + ".value.column", jrd.getTargetValColumn());
		this.dependencyList.addDependency(dto.getName(), new MavenDependency("mysql-connector-java-5.1.17.jar", MavenDependency.JAR));
		// String pName = op.substring("$param.".length());
		// String pType = this.inParams.get(pName);
		logger.debug("Exiting JobResponseTask");
	}

	@Override
	public String getCode() {
		logger.debug("Entered getCode");
		StringBuffer code = new StringBuffer();
		JobResponseDto jrd = (JobResponseDto) this.dto;
		String respVal = jrd.getName() + "Resp";
		code.append(getResponseGenCode(jrd, respVal));
		code.append("\n//Key for response\n");
		String keyName = jrd.getName() + "respKey";
		code.append(generateKeyVal(jrd, keyName));
		code.append("\ndfService.writeMySql(\"").append(jrd.getDataFrameName()).append("\",").append(keyName).append(",").append(respVal).append(")");

		logger.debug("----------------------------------------");
		logger.debug(code.toString());
		logger.debug("----------------------------------------");
		logger.debug("Exiting getCode");
		return code.toString();
	}

	String getResponseGenCode(JobResponseDto jrd, String valResp) {
		logger.debug("Entered getResponseGenCode");
		StringBuffer sb = new StringBuffer();
		sb.append("\n//====== Gest JSON from DataFrames start========");
		String mapVal = jrd.getName() + "Map";
		sb.append("\n   val ").append(mapVal).append(" = new HashMap[String, DataFrame]()\n");
		Map<String, String> m = jrd.getDfResponseMap();
		for (String nm : m.keySet()) {
			//String df = jrd.getDataFrameName(m.get(nm));
			String df = this.actions.get(m.get(nm)).getVariableName();
			sb.append(mapVal).append(".put(\"").append(nm).append("\",").append(df).append(")\n");
		}

		sb.append("val ").append(valResp).append(" = dfService.dataframeToJSONString(").append(mapVal).append(",\"").append(jrd.getResponseRoot()).append("\")");
		sb.append("\n//====== Gest JSON from DataFrames start========");

		logger.debug("Exiting getResponseGenCode");
		return sb.toString();
	}

	String generateKeyVal(JobResponseDto jrd, String valName) {
		logger.debug("Entered generateKeyVal");
		String keyTmp = jrd.getTargetKey();

		String[] arrKey = keyTmp.split(Pattern.quote("$"));
		StringBuffer sb = new StringBuffer();
		for (String keyPart : arrKey) {
			if (sb.length() > 0) {
				sb.append(" + ");
			}

			if (keyPart.startsWith("{")) {
				int idx1 = keyPart.indexOf("}");
				String keyPrm = keyPart.substring(1, idx1);
				String keyStr = null;
				if (idx1 < keyPart.length()) {
					keyStr = keyPart.substring(idx1 + 1);
				}

				String t = "inParams.get(\"" + keyPrm.substring(keyPrm.indexOf(".") + 1) + "\")";
				if (keyStr != null && keyStr.length() > 0) {
					t = t + " + \"" + keyStr + "\"";
				}

				sb.append(t);
			} else if (keyPart.length() > 0) {

				sb.append("\"").append(keyPart).append("\"");
			}
		}

		logger.debug("Exiting generateKeyVal");
		return "\n   val " + valName + " = " + sb.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
