package com.gb.spark.wf.component;

import java.util.Map;
import java.util.TreeMap;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnDto;
import com.gb.common.job.dto.TargetXMLDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class TargetXMLTask extends AbstractTask {

	public TargetXMLTask(TargetXMLDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		TargetXMLDto xmld = (TargetXMLDto) this.dto;

		//String df = xmld.getDataFrameName(xmld.getPredecessors().get(0));
		String df = this.actions.get(xmld.getPredecessors().get(0)).getVariableName();

		StringBuffer fields = new StringBuffer();
		Map<Integer, ColumnDto> map = new TreeMap<Integer, ColumnDto>();
		for (ColumnDto f : xmld.getFields())
		{
			map.put(f.getPos(), f);
		}
		
		for (Integer k : map.keySet())
		{
			if (fields.length()>0)
			{
				fields.append(",");
			}
			
			fields.append(map.get(k).getName());
		}
		
		configList.setConfig(JobConstants.PARAM_TASK_XML_ROW_TAG, xmld.getRootElement(), xmld.getName());
		configList.setConfig(JobConstants.PARAM_TASK_TARGET, xmld.getPath(), xmld.getName());
		configList.setConfig(JobConstants.PARAM_TASK_FIELDS, fields.toString(), xmld.getName());
		
		code.append("\n");
		code.append(InstanceList.dfServiceInstance).append(".saveAsXMLFile(")
		.append(df).append(", \"")
		.append(xmld.getName()).append("\")\n ");

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return null;
	}
}
