package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.PrimeTypeDto;
import com.gb.common.job.util.ComponentTypes;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class PrimeTypeTask extends AbstractTask {
	public PrimeTypeTask(PrimeTypeDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		PrimeTypeDto ptd = (PrimeTypeDto) this.dto;

		String parentName = ptd.getPredecessors().get(0);
		BaseDto pDto = this.actions.get(parentName);
		if (pDto.getComponentType() != ComponentTypes.START) {
			String parentVar = pDto.getVariableName();
			
			if ("dataframe".equalsIgnoreCase(pDto.getDataType()))
			{
				code.append("\nval ").append(ptd.getVariableName()).append(" = ").append(parentVar).append(".select(\"").append(ptd.getParentColumn()).append("\"").append(".first().get(0)");
			}
			else if ("row".equalsIgnoreCase(pDto.getDataType()))
			{
				code.append("\nval ").append(ptd.getVariableName()).append(" = {");
				code.append("\n   val colMap = (0 until ").append(pDto.getVariableName()).append(".schema.length).map(i => ").append(pDto.getVariableName()).append(".schema(i).name -> i).toMap");
				code.append("\n   ").append(pDto.getVariableName()).append(".get(colMap(\"").append(ptd.getParentColumn()).append("\"))");
				code.append("\n}"); 
			}
		}

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
