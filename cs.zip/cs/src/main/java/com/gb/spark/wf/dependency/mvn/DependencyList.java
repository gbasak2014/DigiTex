package com.gb.spark.wf.dependency.mvn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DependencyList {

	Map<String, MavenDependency> map = new HashMap<String, MavenDependency>();
	Set<Long> lstService = new HashSet<Long>();
	Set<Long> lstSubWorkflow = new HashSet<Long>();

	public void addDependency(String key, MavenDependency d) {
		map.put(key, d);
	}

	public Set<MavenDependency> getDepenencies() {
		Set<MavenDependency> set = new HashSet<MavenDependency>();
		for (MavenDependency md : map.values()) {
			if (md.getType() == md.MAVEN) {
				set.add(md);
			}
		}
		return set;
	}

	public List<String> getExternalJars() {
		List<String> jarList = new ArrayList<String>();
		for (MavenDependency md : map.values()) {
			if (md.getType() == md.JAR) {
				jarList.add(md.toString());
			}
		}

		return jarList;
	}

	public MavenDependency getDependency(String key) {
		return this.map.get(key);
	}

	public void addServiceId(Long id) {
		this.lstService.add(id);
	}

	public Set<Long> getServiceList() {
		return this.lstService;
	}

	public void addSubWorkflow(Long swId) {
		this.lstSubWorkflow.add(swId);
	}

	public Set<Long> getSubWorkflowList() {
		return this.lstSubWorkflow;
	}

	@Override
	public String toString() {
		return this.map.toString();
	}
}
