package com.gb.spark.wf.component;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.FilterDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.util.StringUtils;
import com.gb.common.util.TaskUtils;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class FilterTask extends AbstractTask {
	Map<String, String> inParams;
	public FilterTask(FilterDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList, Map<String, String> inParams) {
		super(dto, actions, imports, dependencyList, configList);
		this.inParams = inParams;
		this.imports.addImport("org.apache.spark.sql.functions._");
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		FilterDto fd = (FilterDto) this.dto;
		code.append("\nval ").append(fd.getDataFrameName()).append(" = ").append(getFilter(fd));

		return code.toString();
	}

	private String getFilter(FilterDto fd) {
		//String parentDf = fd.getDataFrameName(fd.getPredecessors().get(0));
		String parentDf = this.actions.get(fd.getPredecessors().get(0)).getVariableName();
		String condition = fd.getConditions();
		Deque<String> stack = new ArrayDeque<String>();
		StringBuffer bff = new StringBuffer();
		int len = condition.length();
		for (int i = 0; i < len; i++) {
			char ch = condition.charAt(i);
			if (ch == '(' || ch == ')') {
				if (bff.length() > 0) {
					stack.push(bff.toString());
					bff.delete(0, bff.length());
				}
				stack.push(String.valueOf(ch));
			} else {
				bff.append(ch);
			}
		}
		
		if (bff.length() > 0) {
			stack.push(bff.toString());
		}

		Deque<String> expStack = new ArrayDeque<String>();
		while (!stack.isEmpty()) {
			String exp = stack.pop();
			if (exp.equals("(") || exp.equals(")")) {
				expStack.push(exp);
			} else if (TaskUtils.isOperator(exp.trim())) {
				expStack.push(TaskUtils.getOperator(exp.trim()));
			} else {
				expStack.push(getExpression(exp.trim(), parentDf));
			}
		}

		bff.delete(0, bff.length());
		bff.append(parentDf).append(".filter(");
		while(!expStack.isEmpty())
		{
			bff.append(expStack.pop());
		}
		bff.append(")");
		return bff.toString();
	}

	String getExpression(String exp, String df) {
		StringBuffer bff = new StringBuffer();
		exp = exp.trim();
		int len = exp.length();

		StringBuffer cond = new StringBuffer();

		boolean opFound = false;
		boolean logicFound = false;
		for (int i = 0; i < len; i++) {
			char ch = exp.charAt(i);
			if (StringUtils.isExprSeparator(ch) || i == (len-1)) {
				if (i == len-1)
				{
					bff.append(ch);
				}
				
				String op = bff.toString().trim();
				bff.delete(0, bff.length());
				if (TaskUtils.isOperator(op)) {
					cond.append(TaskUtils.getOperator(op)).append("(");
					opFound = true;
				} else if ("AND".equalsIgnoreCase(op) || "OR".equalsIgnoreCase(op)) {
					cond.append(".").append(op.toLowerCase()).append("(");
					logicFound = true;
				} else {
					if(op.startsWith("$param."))
					{
						String pName = op.substring("$param.".length());
						String pType = this.inParams.get(pName);
						if ("DOUBLE".equalsIgnoreCase(pType))
						{
							cond.append("lit(").append("inParams.get(\"" + pName + "\").toDouble").append(")");
						}
						else if ("LONG".equalsIgnoreCase(pType))
						{
							cond.append("lit(").append("inParams.get(\"" + pName + "\").toLong").append(")");
						}
						else
						{
							cond.append("lit(").append("inParams.get(\"" + pName + "\")").append(")");
						}    
					}
					else if (op.startsWith("$")) {
						cond.append(df).append(".col(\"").append(op.substring(1)).append("\")");
					} else {
						cond.append("lit(").append(op).append(")");
					}
					
					if (opFound) {
						cond.append(")");
					}
					if (opFound && logicFound) {
						cond.append(")");
						logicFound = false;
					}
					opFound = false;
				}
			} else {
				bff.append(ch);
			}
		}

		return cond.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
	
	public static void main(String[] args) {
		System.out.println("Start...");
		FilterDto fd =new FilterDto();
		fd.setConditions("($col1 - $col2) > 100");
		fd.setPredecessors(Arrays.asList("P01","P02"));
		FilterTask fs = new FilterTask(fd, new HashMap<String, BaseDto>(), new ImportList(), new DependencyList(), new ConfigList(), new HashMap<String, String>());
		
		System.out.println(fs.getCode());
		System.out.println("Done....");
	}
}
