package com.gb.spark.wf.component;

import java.util.List;
import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnTransformationDto;
import com.gb.common.job.dto.GroupDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.util.TaskUtils;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class GroupTask extends AbstractTask {

	public GroupTask(GroupDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
		imports.addImport("org.apache.spark.sql.functions._");
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		GroupDto gd = (GroupDto) this.dto;
		String parent = gd.getPredecessors().get(0);
		//String parentDf = gd.getDataFrameName(parent);
		String parentDf = this.actions.get(parent).getVariableName();
		List<String> grpCols = gd.getGroupByColumnsAsList();
		
		code.append("\n//Group by columns");
		code.append("\nval ").append(gd.getDataFrameName()).append(" = ");
		code.append(parentDf).append(".groupBy(");
		StringBuffer tmp = new StringBuffer();
		for (String col : grpCols)
		{
			if (tmp.length() > 0)
			{
				tmp.append(",");
			}
			tmp.append(parentDf).append(".col(\"").append(col).append("\")");
		}
		
		code.append(tmp.toString());
		code.append(").agg(\n");
		tmp.delete(0, tmp.length());
		for( ColumnTransformationDto ctd : gd.getTransformations())
		{
			if (tmp.length() > 0)
			{
				tmp.append(",\n");
			}
			
			String tt = ctd.getTransform();
			int idx1 = tt.indexOf('(');
			int idx2 = tt.indexOf(')');
			String fName=null;
			String arg = null;
			if (idx1 > 1 && idx2 > idx1)
			{
				fName = tt.substring(0,idx1);
				arg = tt.substring(idx1+1, idx2);
			}
			else if (!tt.startsWith("$"))
			{
				arg = tt;
			}
			
			if (arg != null)
			{
				String agg = TaskUtils.getAggColumns(fName, arg, parentDf);
				tmp.append("\t\t").append(agg).append(".as(\"").append(ctd.getTargetField()).append("\")");				
			}
		}

		code.append(tmp).append(")");
		
		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
