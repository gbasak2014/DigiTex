package com.gb.common.util;

import java.util.HashMap;
import java.util.Map;

import com.gb.common.job.transformation.TransformationFactory;

//expression function


public class TaskUtils {
	static Map<String, String> dataTypeMap = new HashMap<String, String>();
	static Map<String, String> functionMap = new HashMap<String, String>();
	static Map<String, String> aggFunctionMap = new HashMap<String, String>();
	static Map<String, String> opMap = new HashMap<String, String>();
	static{
		dataTypeMap.put("STRING", "StringType");
		dataTypeMap.put("INTEGER", "IntegerType");
		dataTypeMap.put("INT", "IntegerType");
		dataTypeMap.put("DOUBLE", "DoubleType");
		dataTypeMap.put("LONG", "LongType");
		
		functionMap.put("CONCAT", "concat");
		functionMap.put("CONCAT_WS", "concat_ws");
		functionMap.put("ABS", "abs");
		functionMap.put("CEIL", "ceil");
		functionMap.put("SUM", "sum");
		functionMap.put("MAX", "max");
		functionMap.put("MIN", "min");
		functionMap.put("AVG", "avg");
		
		aggFunctionMap.put("SUM", "sum");
		aggFunctionMap.put("MAX", "max");
		aggFunctionMap.put("MIN", "min");
		aggFunctionMap.put("AVG", "avg");
		aggFunctionMap.put("COUNT", "count");
		
		opMap.put("=", ".equalTo");
		opMap.put(">", ".gt");
		opMap.put("<", ".lt");
		opMap.put(">=", ".geq");
		opMap.put("<=", ".leq");
		opMap.put("STARTSWITH", ".startsWith");
		opMap.put("ENDSWITH", ".endsWith");
		opMap.put("LIKE", ".like");
		opMap.put("IN", ".isin");
		opMap.put("NOTEQUAL", ".ne");
		opMap.put("CONTAINS", ".contains");	
	}
	
	public static String getOperator(String op)
	{
		return opMap.get(op.toUpperCase());
	}

	public static boolean isOperator(String op)
	{
		return opMap.containsKey(op.toUpperCase());
	}
	
	public static String getFunction(String name)
	{
		return functionMap.get(name.toUpperCase()) != null ? functionMap.get(name.toUpperCase()) : name;
	}
	
	public static String getSparkSchemaType(String dataType)
	{
		return dataTypeMap.get(dataType.toUpperCase());
	}

	public static String getAggFunction(String name)
	{
		return aggFunctionMap.get(name.toUpperCase());
	}
	
	public static boolean isOperator(char ch)
	{
		if ('+' == ch || '-' == ch || '*' == ch || '/' == ch)
			return true;
		
		return false;
	}
	
	public static boolean isNumeric(String str)
	{
		int len = str.length();
		for(int i=0; i<len; i++)
		{
			char ch = str.charAt(i);
			if (!Character.isDigit(ch) && ch != '.')
			{
				return false;
			}
		}
		
		return true;
	}
	
	public static String getOperand(String col, String df)
	{
		StringBuffer bff = new StringBuffer();
		if (col.startsWith("$"))
		{
			bff.append(df).append(".col(\"").append(col.substring(1)).append("\")");
		}
		else
		{
			if (isNumeric(col))
			{
				bff.append("lit(").append(col).append(")");
			}
			else
			{
				bff.append("lit(").append(col).append(")");
			}
		}
		
		return bff.toString();
	}
	
	public static String getAggColumns(String function, String arg, String df)
	{
		String fName = null;
		
		if (function != null)
		{
			fName = aggFunctionMap.get(function.toUpperCase());
		}
		
		if (fName != null)
		{
			if (fName.equalsIgnoreCase("count"))
			{
				return fName + "(\"*\")";
			}
			
			return fName + "(" + df + ".col(\"" + arg.substring(1) + "\"))";
		}
		
		if (arg.startsWith("$"))
		{
			return df + ".col(\"" + arg.substring(1) + "\")";
		}
		
		return "lit(" + arg + ")";
	}
	
	public static void main(String[] args) {
		String s = "SUM(123)";
		System.out.println(s.substring(0, s.indexOf('(')));
		System.out.println(s.substring(s.indexOf('(')+1, s.indexOf(')')));
		
		System.out.println("EXPR::" + TransformationFactory.getTransformation("concat($state, \"    \" , $city)", "myDf").evaluate());
	}
}
