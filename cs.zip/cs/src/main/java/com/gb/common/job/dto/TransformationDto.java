package com.gb.common.job.dto;

import java.util.List;

public class TransformationDto extends BaseDto {
	List<ColumnTransformationDto> transformations;

	public List<ColumnTransformationDto> getTransformations() {
		return transformations;
	}

	public void setTransformations(List<ColumnTransformationDto> transformations) {
		this.transformations = transformations;
	}

	@Override
	public String toString() {
		return super.toString() + ", transformations:" + this.transformations;
	}
}
