package com.gb.common.config;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.JobResponseDto;
import com.gb.common.job.dto.StartDto;
import com.gb.common.job.dto.SubWorkflowDto;
import com.gb.common.job.util.ComponentToDto;
import com.google.gson.Gson;

public class JobConfiguration {
	static final Logger logger = Logger.getLogger(JobConfiguration.class);

	public Map<String, BaseDto> convertJsonToDtoMap(String json) {
		logger.debug("Entered convertJsonToTasksMap");
		Map<String, BaseDto> map = new HashMap<String, BaseDto>();
		JSONObject jsonMain = new JSONObject(json);
		Gson gson = new Gson();

		StartDto start = gson.fromJson(jsonMain.getJSONObject("start").toString(), StartDto.class);
		map.put("start", start);
		Deque<String> queue = new ArrayDeque<String>();
		queue.addAll(start.getSuccessors());
		logger.debug("------------------------------------------------------------------------------------------");
		logger.debug("------------------------------------------------------------------------------------------");
		while (!queue.isEmpty()) {
			String actionName = queue.pop();
			if (!map.containsKey(actionName)) {
				try {
					JSONObject obj = new JSONObject(jsonMain.getJSONObject(actionName).toString());
					int type = obj.getInt("componentType");
					Class clazz = ComponentToDto.getClass(type);
					logger.debug(type + ":>>" + clazz);
					if (clazz != null) {
						logger.debug(type + ":>>" + obj.toString());
						BaseDto dto = (BaseDto) gson.fromJson(obj.toString(), clazz);
						if (dto instanceof JobResponseDto) {
							JobResponseDto jrd = (JobResponseDto) dto;
							JSONArray arr = obj.getJSONArray("responseMap");
							Map<String, String> dfMap = new HashMap<String, String>();
							int len = arr.length();
							for (int i = 0; i < len; i++) {
								JSONObject jo = arr.getJSONObject(i);
								String v = jo.keys().next();
								String k = jo.getString(v);
								dfMap.put(k, v);
							}
							jrd.setDfResponseMap(dfMap);
							logger.debug("jrd.getDfResponseMap :>>" + jrd.getDfResponseMap().toString());
						}
						map.put(actionName, dto);
						if (dto.getSuccessors() != null) {
							queue.addAll(dto.getSuccessors());
						}

					}
				} catch (Exception e) {
					logger.debug("ERROR - Converting JSON to BaseDto");
					e.printStackTrace();
				}
			}
		}
		logger.debug("------------------------------------------------------------------------------------------");
		logger.debug("------------------------------------------------------------------------------------------");
		logger.debug("Exiting convertJsonToTasksMap");
		return map;
	}

	public Map<String, JSONObject> getTaskJsonMap(JSONObject jsonMain) {
		Map<String, JSONObject> map = new HashMap<String, JSONObject>();
		Gson gson = new Gson();

		JSONObject taskJson = jsonMain.getJSONObject("start");
		StartDto start = gson.fromJson(taskJson.toString(), StartDto.class);
		map.put("start", taskJson);
		Deque<String> queue = new ArrayDeque<String>();
		queue.addAll(start.getSuccessors());

		while (!queue.isEmpty()) {
			String actionName = queue.pop();
			if (!map.containsKey(actionName)) {
				try {
					taskJson = new JSONObject(jsonMain.getJSONObject(actionName).toString());
					int type = taskJson.getInt("componentType");
					Class clazz = ComponentToDto.getClass(type);
					if (clazz != null) {
						// taskJson = obj.toString();
						BaseDto dto = (BaseDto) gson.fromJson(taskJson.toString(), clazz);
						map.put(actionName, taskJson);
						if (dto.getSuccessors() != null) {
							queue.addAll(dto.getSuccessors());
						}

					}
				} catch (Exception e) {
					logger.debug("ERROR - Converting JSON to BaseDto");
					e.printStackTrace();
				}
			}
		}

		return map;
	}

	public SubWorkflowDto getSubWfDto(JSONObject jsonMain) {
		Gson gson = new Gson();
		SubWorkflowDto subWf = (SubWorkflowDto) gson.fromJson(jsonMain.getJSONObject("subWfDetail").toString(), SubWorkflowDto.class);
		return subWf;
	}

	public static void main(String[] args) throws Exception {
		String str = JSONSource.getConfigJSON();
		JobConfiguration c = new JobConfiguration();
		Map<String, BaseDto> map = c.convertJsonToDtoMap(str);

		for (Entry<String, BaseDto> e : map.entrySet()) {
			logger.debug(e.getKey() + ":::::" + e.getValue());
		}

	}

}
