package com.gb.common.controller;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gb.common.dto.AuthenticateDto;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.UserDetailReqDto;
import com.gb.common.service.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	static final Logger logger = Logger.getLogger(UserController.class);

	@Resource(name = "userService")
	UserService userService;

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDto authenticate(@RequestBody AuthenticateDto auth) {
		System.out.println("Entered getUserDetails");
		ResponseDto response = userService.authenticateUser(auth);

		System.out.println("response:" + response);
		System.out.println("Exiting getUserDetails");
		return response;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDto insertUserDetails(@RequestBody UserDetailReqDto user) {
		System.out.println("Entered insertUserDetails");

		ResponseDto response = userService.registerUser(user);

		System.out.println("Exiting insertUserDetails");
		return response;
	}

	@RequestMapping(value = "/adduser", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDto addUser(@RequestBody UserDetailReqDto user) {
		System.out.println("Entered saveUserDetails");
		System.out.println("USER:" + user);
		ResponseDto res = userService.addUserToProject(user);
		System.out.println("Exiting saveUserDetails");
		return res;
	}

	@RequestMapping(value = "/addproject", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDto addProject(@RequestBody UserDetailReqDto user) {
		System.out.println("Entered saveUserDetails");
		System.out.println("USER:" + user);
		ResponseDto res = userService.addUserToProject(user);
		System.out.println("Exiting saveUserDetails");
		return res;
	}

}