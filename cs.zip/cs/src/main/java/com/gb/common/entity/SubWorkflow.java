package com.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "SUB_WORKFLOW")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class SubWorkflow {

	@Id
	@Column(name = "SUB_WF_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long subWfId;

	@Column(name = "NAME", length = 100)
	String name;

	@Column(name = "DESCRIPTION", length = 250)
	String description;

	@ManyToOne
	@JoinColumn(name = "JOB_ID")
	JobDetails jobDetails;

	@Column(name = "CODE", length = 1024)
	String code;
	
	@Column(name = "RETURN_TYPE", length = 100)
	String returnType;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "subWorkflow", orphanRemoval = true)
	Set<SubWfStep> steps;

	@Version
	@Column(name = "VERSION")
	long version;

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof SubWorkflow))
			return false;

		SubWorkflow jd = (SubWorkflow) obj;

		return this.subWfId != null && this.name != null && this.subWfId.equals(jd.subWfId) && this.name.equals(jd.name);
	}

	public Long getSubWfId() {
		return subWfId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public JobDetails getJobDetails() {
		return jobDetails;
	}

	public void setJobDetails(JobDetails jobDetails) {
		this.jobDetails = jobDetails;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public Set<SubWfStep> getSteps() {
		return steps;
	}

	public void setSteps(Set<SubWfStep> steps) {
		this.steps = steps;
	}

}
