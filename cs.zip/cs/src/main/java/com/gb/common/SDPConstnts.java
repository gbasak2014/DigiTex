package com.gb.common;

public interface SDPConstnts {
	String SOURCE_DB = "RDBMS";
	String SOURCE_FILE = "FILE";
	
	String PROJECT_ID = "project.id";
	String TMP_PATH = "job.tmp.path";
	String JOB_NAME = "job.name";
	String CODE_TMP_PATH = "code.tmp.path";
	
	String SQOOP_JOB_CREATE_SUFF = "_gen_job.sh";
	String SQOOP_JOB_EXEC_SUFF = "_exec_job.sh";
}
