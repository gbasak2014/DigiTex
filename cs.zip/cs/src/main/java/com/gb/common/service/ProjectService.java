package com.gb.common.service;

import java.util.List;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gb.common.dto.ProjectReqDtl;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.SourceConfDto;
import com.gb.common.dto.SourceMetaDto;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.Project;
import com.gb.common.entity.ProjectConfig;
import com.gb.common.entity.UserDetails;

public interface ProjectService {
	Project getProjectById(Long projectId);

	Set<UserDetails> getUsersByProjectId(Long projectId);

	Set<ProjectConfig> getConfigByProjectId(Long projectId);

	ProjectConfig saveProjectConfig(ProjectConfig pc, Long projectId);

	ResponseDto saveProject(ProjectReqDtl project);

	List<String> getRecordTypes();

	List<String> getSourceTypes();

	long saveSourceMetaData(SourceMetaDto data);

	SourceConfDto getSourceConfig();

	SourceMetaDto getSourceMetaData(long id);

	List<String> getJobNamesForProject(long projectId);

	List<JobDetails> getJobsForProject(long projectId);

	List<JobDetails> getSubWfsForProject(long projectId);
	
	long saveService(String json);

	JSONArray getService(long projectId);

	JSONArray getUdf(long projectId);

	JSONObject getServiceDetail(long serviceId);
}
