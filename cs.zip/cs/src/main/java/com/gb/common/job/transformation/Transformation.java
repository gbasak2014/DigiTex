package com.gb.common.job.transformation;

public interface Transformation {
	String evaluate();
}
