package com.gb.common.job.dto;

public class SourceRdbmsDto extends BaseDto {
	String jdbcUrl;
	String user;
	String password;
	String table;
	String schema;

	public String getJdbcUrl() {
		return jdbcUrl;
	}

	public void setJdbcUrl(String jdbcUrl) {
		this.jdbcUrl = jdbcUrl;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	@Override
	public String toString() {
		return super.toString() + ", url:" + this.jdbcUrl + ", user: " + this.user + ", schema:" + this.schema + ", table:" + this.table;
	}
}
