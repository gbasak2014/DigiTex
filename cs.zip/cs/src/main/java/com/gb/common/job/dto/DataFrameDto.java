package com.gb.common.job.dto;

public class DataFrameDto extends BaseDto {
	@Override
	public String getVariableName() {
		return this.name;
	}
	
	@Override
	public String getDataFrameName() {
		return this.name;
	}
}
