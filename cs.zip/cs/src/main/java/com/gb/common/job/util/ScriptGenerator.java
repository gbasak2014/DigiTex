package com.gb.common.job.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.Map;

import com.gb.common.SDPConstnts;
import com.gb.common.config.ApplicationConfig;
import com.gb.spark.wf.component.AbstractTask;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class ScriptGenerator {
	public String generateShellScript(ApplicationConfig appConfig, ConfigList configList, String jobName, DependencyList dependencyList, Map<String, AbstractTask> taskMap,
			String tmpPath) {
		StringBuffer code = new StringBuffer();
		code.append("#!/bin/bash\n\n");
		code.append("#System Generated script, do not modify this\n");

		code.append("export REQ_ID=`date +%Y%m%d%H%M%S`\n");
		code.append("export YYYYMMDDHH=`date +%Y%m%d%H`\n");
		code.append("export YYYYMMDD=`echo $YYYYMMDDHH | cut -c1-8`\n");
		code.append("export YYYY=`echo $YYYYMMDDHH | cut -c1-4`\n");
		code.append("export MM=`echo $YYYYMMDDHH | cut -c5-6`\n");
		code.append("export DD=`echo $YYYYMMDDHH | cut -c7-8`\n");
		code.append("export HH=`echo $YYYYMMDDHH | cut -c9-10`\n\n");

		code.append("########\n#Create input parametsrs\n###########\n");

		if (JobConstants.TRUE.equalsIgnoreCase(configList.getConfig(JobConstants.PARAM_LOCAL_FLAG))) {
			code.append("\n######\n");
			code.append("# File copy From Local to HDFS\n");
			code.append("######\n");
			code.append(appConfig.getValue(JobConstants.CONF_JOB_FILE_CP_SCRIPT).replace("$job.name", jobName)).append("\n");
		}

		for (AbstractTask task : taskMap.values()) {
			if (task.getComponentType() == ComponentTypes.SQOOP) {
				try {
					code.append("\n#Sqoop import\n");
					BufferedReader br = new BufferedReader(new FileReader(tmpPath + "/" + task.getName() + SDPConstnts.SQOOP_JOB_EXEC_SUFF));
					String line = br.readLine();
					while (line != null) {
						code.append(line).append("\n");
						line = br.readLine();
					}
					br.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		if (JobConstants.TRUE.equalsIgnoreCase(configList.getConfig(JobConstants.PARAM_SPARK_FLAG))) {
			code.append("\n######\n");
			code.append("# Execute Spark workflow\n");
			code.append("######\n");

			List<String> extJarsLst = dependencyList.getExternalJars();
			String extJars = "";
			for (String ej : extJarsLst) {
				if (extJars.length() > 0) {
					extJars = ",";
				} else {
					extJars = " --jars ";
				}
				extJars = extJars + ej;
			}

			code.append(appConfig.getValue(JobConstants.CONF_JOB_SPARK_SUBMIT_SCRIPT).replace("$job.name", jobName).replace("<EXTJARS>", extJars)).append("\n");
		}
		code.append("\n");

		return code.toString();
	}

	public String generateCompileCmd(String home) {
		StringBuffer sb = new StringBuffer();
		sb.append("cd " + home).append("\nmvn clean install");
		return sb.toString();

	}

	public void generateConfigcript(ApplicationConfig appConfig, ConfigList configList) {
		System.out.println("===================================" + appConfig.getConfig(JobConstants.CONF_JOB_PROP_FILE));
		System.out.println(configList.getAsString());
		System.out.println("===================================");
	}

	public String getReadme(Map<String, String> inParams) {
		StringBuffer bff = new StringBuffer();
		bff.append("This is maven based application, it need to be compiled and packaged using maven tool");
		//
		bff.append("\n\nPrerequisite:\n 1.Maven build tool 4.0.0 should be available");
		bff.append("\n\nSteps to start job");
		bff.append("\n1. Open command prompt and cd to the directory");
		bff.append("\n2. Build application using mvn clean install");
		bff.append("\n3. Copy below files to edge node in the cluster");
		bff.append("\n\ti. ").append(JobConstants.WF_PROP_FILE);
		bff.append("\n\tii. ").append(JobConstants.WF_SCRIPT_FILE);
		bff.append("\n\tiii. target/sdp-job-1.0-SNAPSHOT.jar");
		bff.append("\n\nStart job:\n");
		bff.append(JobConstants.WF_SCRIPT_FILE);
		for (String p : inParams.keySet()) {
			bff.append(" -").append(p).append("<value of ").append(p).append(">");
		}

		return bff.toString();
	}

}
