package com.gb.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "JOB_PARAM")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class JobParam {
	@Id
	@Column(name = "PARAM_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long paramId;

	@Column(name = "PARAM_KEY")
	String paramKey;

	@Column(name = "PARAM_TYPE")
	String paramType;

	@Column(name = "PARAM_POS")
	@ColumnDefault(value = "0")
	Integer pos;

	@ManyToOne
	@JoinColumn(name = "JOB_ID")
	JobDetails jobDetails;

	@ManyToOne
	@JoinColumn(name = "WF_ID")
	SubWorkflow subWorkflow;

	@Version
	@Column(name = "VERSION")
	long version;

	public Long getParamId() {
		return paramId;
	}

	public void setParamId(Long paramId) {
		this.paramId = paramId;
	}

	public String getParamKey() {
		return paramKey;
	}

	public void setParamKey(String paramKey) {
		this.paramKey = paramKey;
	}

	public String getParamType() {
		return paramType;
	}

	public void setParamType(String paramType) {
		this.paramType = paramType;
	}

	public JobDetails getJobDetails() {
		return jobDetails;
	}

	public void setJobDetails(JobDetails jobDetails) {
		this.jobDetails = jobDetails;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof JobParam))
			return false;

		JobParam jp = (JobParam) obj;
		return this.paramKey != null && this.paramType != null && this.paramKey.equals(jp.getParamKey()) && this.paramType.equals(jp.getParamType());
	}

	@Override
	public String toString() {
		return "{id:" + this.paramId + ", paramKey:" + this.paramKey + ", Type:" + this.paramType + "}";
	}
}
