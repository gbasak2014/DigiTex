package com.gb.common.job.transformation;

import com.gb.common.util.TaskUtils;

public class Function implements Transformation {
	String name;
	String args;
	String df;

	public Function(String name, String args, String dfName) {
		this.name = name;
		this.args = args;
		this.df = dfName;
	}

	@Override
	public String evaluate() {
		String fName = TaskUtils.getFunction(this.name);
		StringBuffer argBuff = new StringBuffer();

		for (String arg : this.args.split(",")) {
			if (argBuff.length() > 0) {
				argBuff.append(",");
			}
			argBuff.append(TaskUtils.getOperand(arg.trim(), this.df));
		}

		return fName + "(" + argBuff.toString() + ")";
	}
}
