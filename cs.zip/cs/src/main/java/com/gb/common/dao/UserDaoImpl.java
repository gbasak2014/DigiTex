package com.gb.common.dao;

import java.io.Serializable;

import org.springframework.stereotype.Component;

import com.gb.common.entity.UserDetails;

@Component(value = "userDao")
public class UserDaoImpl extends AbstractDao implements UserDao {
	@Override
	public UserDetails getUserById(String userId) {
		return (UserDetails) this.getById(UserDetails.class, userId);
	}

	@Override
	public UserDetails saveUser(UserDetails ud) {
		Serializable uId = this.save(ud);

		return (UserDetails) this.getById(UserDetails.class, uId);
	}
}
