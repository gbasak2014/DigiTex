package com.gb.common.job.dto;

import java.util.ArrayList;
import java.util.List;

public class GroupDto extends BaseDto {
	String groupByColumns;
	List<ColumnTransformationDto> transformations;

	public List<ColumnTransformationDto> getTransformations() {
		return transformations;
	}

	public void setTransformations(List<ColumnTransformationDto> transformations) {
		this.transformations = transformations;
	}

	public String getGroupByColumns() {
		return groupByColumns;
	}

	public List<String> getGroupByColumnsAsList() {
		List<String> cols = new ArrayList<String>();
		for (String col: this.groupByColumns.split(","))
		{
			cols.add(col);
		}
		
		return cols;
	}
	
	
	public void setGroupByColumns(String groupByColumns) {
		this.groupByColumns = groupByColumns;
	}

	@Override
	public String toString() {
		return super.toString() + ", groupByColumns:" + this.groupByColumns + ", transformations:" + this.transformations;
	}
}
