package com.gb.common.job.dto;

import java.util.List;

public class CommonServiceDto extends BaseDto {

	long serviceId;
	String serviceName;
	String returnCategory;
	List<ParamDto> params;

	public long getServiceId() {
		return serviceId;
	}

	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}

	public String getReturnCategory() {
		return returnCategory;
	}

	public void setReturnCategory(String returnCategory) {
		this.returnCategory = returnCategory;
	}

	public List<ParamDto> getParams() {
		return params;
	}

	public void setParams(List<ParamDto> params) {
		this.params = params;
	}

	@Override
	public String toString() {
		return this.serviceId + "," + this.name + "," + this.returnCategory + ", " + this.params;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

}
