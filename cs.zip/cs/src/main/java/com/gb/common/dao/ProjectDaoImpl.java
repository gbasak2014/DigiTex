package com.gb.common.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;

import com.gb.common.entity.DataType;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.Project;
import com.gb.common.entity.ProjectConfig;
import com.gb.common.entity.RecordType;
import com.gb.common.entity.Role;
import com.gb.common.entity.ServiceDetail;
import com.gb.common.entity.SourceMetaData;
import com.gb.common.entity.SourceType;
import com.gb.common.job.util.JobConstants;

@Component(value = "projectDao")
public class ProjectDaoImpl extends AbstractDao implements ProjectDao {

	@Override
	public Project getProjectById(Long projectId) {
		return (Project) this.getById(Project.class, projectId);
	}

	@Override
	public ProjectConfig saveConfig(ProjectConfig pc) {
		Serializable id = this.save(pc);

		return (ProjectConfig) this.getById(ProjectConfig.class, id);
	}

	@Override
	public ProjectConfig deleteConfig(ProjectConfig pc) {
		this.delete(pc);
		return pc;
	}

	@Override
	public Project saveProject(Project project) {
		Serializable id = this.save(project);
		return (Project) this.getById(Project.class, id);
	}

	@Override
	public Role getRoleByName(String name) {
		Criteria c = this.getSession().createCriteria(Role.class);

		Role role = (Role) c.add(Restrictions.eq("name", name)).uniqueResult();

		return role;
	}

	@Override
	public List<RecordType> getAllRecordType() {
		return this.getAll(RecordType.class);
	}

	@Override
	public List<SourceType> getAllSourceType() {
		return this.getAll(SourceType.class);
	}

	@Override
	public long saveSourceMetaData(SourceMetaData data) {
		long id = (long) this.save(data);
		return id;
	}

	@Override
	public List<DataType> getAllDataType() {
		return this.getAll(DataType.class);
	}

	@Override
	public SourceMetaData getSourceMetaData(Long id) {
		return (SourceMetaData) this.getById(SourceMetaData.class, id);
	}

	@Override
	public List<JobDetails> getJobs(long projectId) {
		Criteria cr = this.getSession().createCriteria(JobDetails.class);
		cr.add(Restrictions.and(Restrictions.eq("projectId", projectId), Restrictions.eq("type", JobConstants.TYPE_JOB)));
		
		List<JobDetails> list = cr.list();
		Set<JobDetails> set = new HashSet<JobDetails>();
		if (list != null) {
			for (JobDetails jd : list) {
				if (!set.contains(jd)) {
					set.add(jd);
				}
			}
		}

		return new ArrayList<JobDetails>(set);
	}

	@Override
	public List<JobDetails> getSubWorkflows(long projectId) {
		Criteria cr = this.getSession().createCriteria(JobDetails.class);
		cr.add(Restrictions.and(Restrictions.eq("projectId", projectId), Restrictions.eq("type", JobConstants.TYPE_SUB_WF)));
		
		List<JobDetails> list = cr.list();
		Set<JobDetails> set = new HashSet<JobDetails>();
		if (list != null) {
			for (JobDetails jd : list) {
				if (!set.contains(jd)) {
					set.add(jd);
				}
			}
		}

		return new ArrayList<JobDetails>(set);
	}
	
	@Override
	public ServiceDetail getService(long projectId, String serviceName) {
		Criteria cr = this.getSession().createCriteria(ServiceDetail.class);
		cr.add(Restrictions.and(Restrictions.eq("projectId", projectId), Restrictions.eq("name", serviceName)));

		List<ServiceDetail> list = cr.list();

		if (list != null && list.size() > 0) {
			list.get(0);
		}

		return null;
	}

	@Override
	public long saveService(ServiceDetail sd) {
		long id = (long) this.save(sd);
		return id;
	}

	@Override
	public List<ServiceDetail> getServiceList(long projectId, String type) {
		System.out.println("projectId: "  + projectId + ", type: " + type);
		Criteria cr = this.getSession().createCriteria(ServiceDetail.class);
		cr.add(Restrictions.and(Restrictions.eq("projectId", projectId), Restrictions.eq("type", type)));

		List<ServiceDetail> list = cr.list();
		System.out.println("LIST: " + list);
		return list;
	}

	@Override
	public ServiceDetail getServiceDetail(long serviceId) {
		return (ServiceDetail) this.getById(ServiceDetail.class, serviceId);
	}
}
