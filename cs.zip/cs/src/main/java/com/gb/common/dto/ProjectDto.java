package com.gb.common.dto;

public class ProjectDto {

	Long id;

	String name;
	String description;

	String clusterUser;
	String clusterPwd;
	String clusterHost;
	String clusterPort;
	String clusterHome;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return this.id + ", " + this.name;
	}

	public String getClusterUser() {
		return clusterUser;
	}

	public void setClusterUser(String clusterUser) {
		this.clusterUser = clusterUser;
	}

	public String getClusterPwd() {
		return clusterPwd;
	}

	public void setClusterPwd(String clusterPwd) {
		this.clusterPwd = clusterPwd;
	}

	public String getClusterHost() {
		return clusterHost;
	}

	public void setClusterHost(String clusterHost) {
		this.clusterHost = clusterHost;
	}

	public String getClusterPort() {
		return clusterPort;
	}

	public void setClusterPort(String clusterPort) {
		this.clusterPort = clusterPort;
	}

	public String getClusterHome() {
		return clusterHome;
	}

	public void setClusterHome(String clusterHome) {
		this.clusterHome = clusterHome;
	}
}
