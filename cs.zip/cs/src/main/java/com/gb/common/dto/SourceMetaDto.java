package com.gb.common.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SourceMetaDto {
	Long id;
	String metaName;
	String source;
	String description;
	String user;
	String password;
	String delimiter;
	String sourceType;
	String recordType;
	long projectId;

	List<ColumnDto> columnTable;

	public String getMetaName() {
		return metaName;
	}

	public void setMetaName(String metaName) {
		this.metaName = metaName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public long getProjectId() {
		return projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	public List<ColumnDto> getColumnTable() {
		return columnTable;
	}

	public void setColumnTable(List<ColumnDto> columnTable) {
		this.columnTable = columnTable;
	}

	@Override
	public String toString() {
		return "{metaName:" + metaName + ", source:" + source + ", description:" + description + ", user:" + user + ", password:" + password
				+ ", delimiter:" + delimiter + ", sourceType:" + sourceType + ", recordType:" + recordType + ", projectId:" + projectId + ", columns:"
				+ columnTable + "}";

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
