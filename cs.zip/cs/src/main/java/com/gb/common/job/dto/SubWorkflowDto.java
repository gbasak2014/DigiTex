package com.gb.common.job.dto;

import java.util.List;

public class SubWorkflowDto extends BaseDto {
	long jobId;
	List<ParamDto> params;
	String returnType;
	List<ArgParamEntry> paramArgMap;
	String description;
	long subWfId;
	long projectId;
	String subWfName;

	public List<ParamDto> getParams() {
		return params;
	}

	public void setParams(List<ParamDto> params) {
		this.params = params;
	}

	public long getJobId() {
		return jobId;
	}

	public void setJobId(long jobId) {
		this.jobId = jobId;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public List<ArgParamEntry> getParamArgMap() {
		return paramArgMap;
	}

	public void setParamArgMap(List<ArgParamEntry> paramArgMap) {
		this.paramArgMap = paramArgMap;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getSubWfId() {
		return subWfId;
	}

	public void setSubWfId(long subWfId) {
		this.subWfId = subWfId;
	}

	public long getProjectId() {
		return projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	@Override
	public String getVariableName() {
		if (this.getReturnType() == null || this.getReturnType().trim().length() <= 0)
			return null;

		if ("DataFrame".equalsIgnoreCase(this.getReturnType()))
			return this.getName() + "Df";

		if ("Row".equalsIgnoreCase(this.getReturnType()))
			return this.getName() + "Rw";

		return "_" + this.getName();
	}

	@Override
	public String toString() {
		return this.jobId + "," + this.name + "," + this.returnType + ", " + this.params + ", " + this.paramArgMap;
	}

	public String getSubWfName() {
		return subWfName;
	}

	public void setSubWfName(String subWfName) {
		this.subWfName = subWfName;
	}
}
