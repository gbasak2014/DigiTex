package com.gb.common.job.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class RemoteExecute {

	public static void main(String[] args) throws Exception {
		System.out.println("********Started...................");
		JSch jsch = new JSch();
		Session s = jsch.getSession("gbasak", "10.77.167.11", 22);

		s.setConfig("StrictHostKeyChecking", "no");
		s.setPassword("Ibm@2017");
		s.connect();
		
		ChannelExec channelExec = (ChannelExec)s.openChannel("exec");
		channelExec.setCommand("sh /home/gbasak/sparkWf/wfTrans0022/startJob.sh");
		channelExec.connect();
		
		
		channelExec.setErrStream(System.out);
		channelExec.setOutputStream(System.out);
		InputStream in = channelExec.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line = br.readLine();
		while (line != null)
		{
			System.out.println(line);
			line = br.readLine();
		}
		
		int st = channelExec.getExitStatus();
		channelExec.disconnect();
		s.disconnect();
		
		System.out.println("Done......................:" + st);
	}

}
