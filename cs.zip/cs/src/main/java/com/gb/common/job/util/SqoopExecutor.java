package com.gb.common.job.util;

import org.json.JSONObject;

import com.gb.common.job.dto.SqoopDto;
import com.google.gson.Gson;

public class SqoopExecutor {
	String codePath;
	String host;
	String user;
	String pwd;
	int port;
	String home;
	
	SqoopDto sqoopDto;
	public SqoopExecutor(String data) {
		JSONObject obj = new JSONObject(data);
		JSONObject cluster = obj.getJSONObject("cluster");
		JSONObject sqoop = obj.getJSONObject("sqoop");
		Gson gson = new Gson();
		this.sqoopDto = gson.fromJson(sqoop.toString(), SqoopDto.class);
		
		host = cluster.getString("host");
		user = cluster.getString("user");
		pwd = cluster.getString("password");
		port = cluster.getInt("port");
		home = cluster.getString("home");
	}
	
	public void createSqoopJob() throws Exception
	{
		SftpClient sftp = new SftpClient(host, port, user, pwd);
		String exec = this.sqoopDto.getCreateJobScript();
		
		sftp.executeOnCluster(this.home, exec);
	}
}
