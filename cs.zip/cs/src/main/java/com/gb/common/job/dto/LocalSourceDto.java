package com.gb.common.job.dto;

import java.util.List;

public class LocalSourceDto {
    String name;
    int componentType;
    List<String> fields;  
    List<String> predecessor;
    List<String> successors;
    String sourcePath;
    String fileType;
    String delimiter;
    String deleteSource;
    boolean renameSource;
    String renameSuffix;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getComponentType() {
		return componentType;
	}
	public void setComponentType(int componentType) {
		this.componentType = componentType;
	}
	public List<String> getFields() {
		return fields;
	}
	public void setFields(List<String> fields) {
		this.fields = fields;
	}
	public List<String> getPredecessor() {
		return predecessor;
	}
	public void setPredecessor(List<String> predecessor) {
		this.predecessor = predecessor;
	}
	public List<String> getSuccessors() {
		return successors;
	}
	public void setSuccessors(List<String> successors) {
		this.successors = successors;
	}
	public String getSourcePath() {
		return sourcePath;
	}
	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getDelimiter() {
		return delimiter;
	}
	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}
	public String getDeleteSource() {
		return deleteSource;
	}
	public void setDeleteSource(String deleteSource) {
		this.deleteSource = deleteSource;
	}
	public boolean isRenameSource() {
		return renameSource;
	}
	public void setRenameSource(boolean renameSource) {
		this.renameSource = renameSource;
	}
	public String getRenameSuffix() {
		return renameSuffix;
	}
	public void setRenameSuffix(String renameSuffix) {
		this.renameSuffix = renameSuffix;
	}
    
    
}
