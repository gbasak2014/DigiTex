package com.gb.common.job.dto;

import java.util.ArrayList;
import java.util.List;

public class StartDto extends BaseDto {
	String jobName;
	List<InParamDto> params = new ArrayList<InParamDto>();
	Long projectId;

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public List<InParamDto> getParams() {
		return params;
	}

	public void setParams(List<InParamDto> params) {
		this.params = params;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	@Override
	public String toString() {
		return super.toString();
	}

}
