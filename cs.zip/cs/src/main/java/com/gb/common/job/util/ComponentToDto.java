package com.gb.common.job.util;

import java.util.HashMap;
import java.util.Map;

import com.gb.common.job.dto.CommonServiceDto;
import com.gb.common.job.dto.CustomActionDto;
import com.gb.common.job.dto.DataFrameDto;
import com.gb.common.job.dto.EndDto;
import com.gb.common.job.dto.FilterDto;
import com.gb.common.job.dto.GroupDto;
import com.gb.common.job.dto.JobResponseDto;
import com.gb.common.job.dto.JoinDto;
import com.gb.common.job.dto.PrimeTypeDto;
import com.gb.common.job.dto.RowDto;
import com.gb.common.job.dto.SortDto;
import com.gb.common.job.dto.SourceFileStreamDto;
import com.gb.common.job.dto.SourceFlumeDto;
import com.gb.common.job.dto.SourceHdfsDto;
import com.gb.common.job.dto.SourceHiveDto;
import com.gb.common.job.dto.SourceKafkaDto;
import com.gb.common.job.dto.SourceLocalDto;
import com.gb.common.job.dto.SourceRdbmsDto;
import com.gb.common.job.dto.SourceTcpDto;
import com.gb.common.job.dto.SqoopDto;
import com.gb.common.job.dto.StartDto;
import com.gb.common.job.dto.SubWorkflowDto;
import com.gb.common.job.dto.TargetDelimitedDto;
import com.gb.common.job.dto.TargetHdfsDto;
import com.gb.common.job.dto.TargetHiveDto;
import com.gb.common.job.dto.TargetJSONDto;
import com.gb.common.job.dto.TargetXMLDto;
import com.gb.common.job.dto.TransformationDto;

public class ComponentToDto {
	private static Map<Integer, Class> map = new HashMap<Integer, Class>();
	static {
		map.put(ComponentTypes.SOURCE_HDFS, SourceHdfsDto.class);
		map.put(ComponentTypes.SOURCE_LOCAL, SourceLocalDto.class);
		map.put(ComponentTypes.SOURCE_HIVE, SourceHiveDto.class);
		map.put(ComponentTypes.SOURCE_RDBMS, SourceRdbmsDto.class);
		map.put(ComponentTypes.SOURCE_HBASE, SourceLocalDto.class);// /
		map.put(ComponentTypes.SOURCE_CASSANDRA, SourceLocalDto.class);// //
		map.put(ComponentTypes.SOURCE_KAFKA, SourceKafkaDto.class);
		map.put(ComponentTypes.SOURCE_FLUME, SourceFlumeDto.class);
		map.put(ComponentTypes.SOURCE_FILE_STREAM, SourceFileStreamDto.class);
		map.put(ComponentTypes.SOURCE_TCP, SourceTcpDto.class);
		map.put(ComponentTypes.SOURCE_JSON, SourceLocalDto.class);// ///
		map.put(ComponentTypes.SOURCE_XML, SourceLocalDto.class);//
		map.put(ComponentTypes.SOURCE_DELIM, SourceLocalDto.class);//
		map.put(ComponentTypes.TRANSFORMATION, TransformationDto.class);
		map.put(ComponentTypes.FILTER, FilterDto.class);
		map.put(ComponentTypes.GROUP, GroupDto.class);
		map.put(ComponentTypes.JOIN, JoinDto.class);
		map.put(ComponentTypes.SORT, SortDto.class);
		map.put(ComponentTypes.START, StartDto.class);
		map.put(ComponentTypes.END, EndDto.class);
		map.put(ComponentTypes.TARGET_HDFS, TargetHdfsDto.class);
		map.put(ComponentTypes.TARGET_HIVE, TargetHiveDto.class);
		map.put(ComponentTypes.TARGET_HBASE, TargetHiveDto.class);// ///
		map.put(ComponentTypes.TARGET_CASSANDRA, TargetHdfsDto.class);// ///
		map.put(ComponentTypes.TARGET_JSON, TargetJSONDto.class);
		map.put(ComponentTypes.TARGET_XML, TargetXMLDto.class);//
		map.put(ComponentTypes.TARGET_DELIM, TargetDelimitedDto.class);//
		map.put(ComponentTypes.RESPONSE_JSON, JobResponseDto.class);//
		map.put(ComponentTypes.CUSTOM_ACTION, CustomActionDto.class);//
		map.put(ComponentTypes.SQOOP, SqoopDto.class);
		map.put(ComponentTypes.COMMON_SERVICE, CommonServiceDto.class);
		map.put(ComponentTypes.SUB_WF, SubWorkflowDto.class);
		map.put(ComponentTypes.DATAFRAME, DataFrameDto.class);
		map.put(ComponentTypes.ROW, RowDto.class);
		map.put(ComponentTypes.PRIME_TYPE, PrimeTypeDto.class);
	}

	public static Class getClass(int type) {
		return map.get(type);
	}
}
