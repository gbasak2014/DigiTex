package com.gb.common.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "JOB_STEP")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class SubWfStep {

	@Id
	@Column(name = "TASK_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long taskId;

	@Column(name = "NAME", length = 100)
	String name;

	@Column(name = "CODE", length = 1024)
	String code;

	@ManyToOne
	@JoinColumn(name = "WF_ID")
	SubWorkflow subWorkflow;

	@Version
	@Column(name = "VERSION")
	long version;

	@Override
	public String toString() {
		return "{id:" + this.taskId + ", name:" + this.name + ", version:" + this.version + "}";
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public SubWorkflow getSubWorkflow() {
		return subWorkflow;
	}

	public void setSubWorkflow(SubWorkflow subWorkflow) {
		this.subWorkflow = subWorkflow;
	}
}
