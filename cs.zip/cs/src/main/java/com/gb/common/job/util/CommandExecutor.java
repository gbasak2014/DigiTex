package com.gb.common.job.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CommandExecutor {
	String command;

	public CommandExecutor(String command) {
		this.command = command;
	}

	public int execute() throws Exception {
		ProcessBuilder pb = new ProcessBuilder(command);
		Process p = pb.start();

		BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

		String line = br.readLine();
		while (line != null) {
			System.out.println(line);
			line = br.readLine();

		}
		int status = p.waitFor();
		return status;
	}
}
