package com.gb.common.job.dto;

import java.util.List;

public class JoinDto extends BaseDto{

	List<ColumnTransformationDto> transformations;
	List<JoinConditionDto> join;

	public List<ColumnTransformationDto> getTransformations() {
		return transformations;
	}

	public void setTransformations(List<ColumnTransformationDto> transformations) {
		this.transformations = transformations;
	}

	public List<JoinConditionDto> getJoin() {
		return join;
	}

	public void setJoin(List<JoinConditionDto> join) {
		this.join = join;
	}

	@Override
	public String toString() {
		return super.toString() + ", join:" + this.join + ", transformations:" + this.transformations;
	}
}
