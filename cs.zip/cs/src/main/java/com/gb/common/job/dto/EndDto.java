package com.gb.common.job.dto;

public class EndDto extends BaseDto {
	@Override
	public String toString() {
		return super.toString();
	}
}
