package com.gb.common.job.dto;

public class TargetHiveDto extends BaseDto {
	String schema;
	String table;
	boolean overwrite;
	String partition;
	String path;

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public boolean isOverwrite() {
		return overwrite;
	}

	public void setOverwrite(boolean overwrite) {
		this.overwrite = overwrite;
	}

	public String getPartition() {
		return partition;
	}

	public void setPartition(String partition) {
		this.partition = partition;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public String toString() {
		return super.toString() + ", schema" + schema + ", table:" + table + ", overwrite:" + overwrite + ", partition" + partition + ", path:" + path;
	}
}
