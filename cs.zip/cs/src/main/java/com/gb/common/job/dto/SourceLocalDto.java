package com.gb.common.job.dto;

public class SourceLocalDto extends SourceFileDto {
}
