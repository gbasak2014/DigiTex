package com.gb.common.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gb.common.SDPConstnts;
import com.gb.common.dto.JobDto;
import com.gb.common.dto.ProjectReqDtl;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.SourceConfDto;
import com.gb.common.dto.SourceMetaDto;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.Project;
import com.gb.common.entity.SourceMetaData;
import com.gb.common.service.ProjectService;
import com.gb.common.service.UserService;
import com.gb.common.util.MessageUtils;
import com.gb.common.util.ServiceUtils;

@Controller
@RequestMapping("/project")
public class ProjectController {
	static final Logger logger = Logger.getLogger(ProjectController.class);

	@Resource(name = "userService")
	UserService userService;

	@Resource(name = "projectService")
	ProjectService projectService;

	@RequestMapping(value = "/add", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseDto addUserDetails(@RequestBody ProjectReqDtl project) {
		logger.debug("Entered addUserDetails");

		System.out.println("##############################################");
		System.out.println("USER:::" + project);
		System.out.println("##############################################");
		this.projectService.saveProject(project);

		ResponseDto response = this.userService.getUserById(project.getUserId());

		System.out.println("RESPONSE:::" + response);

		logger.debug("Exiting addUserDetails");
		return response;
	}

	@RequestMapping(value = "/getsourcetype", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<String> getSourceTypes() {
		logger.debug("Entered addUserDetails");

		List<String> list = this.projectService.getSourceTypes();

		System.out.println("list:::" + list);

		logger.debug("Exiting addUserDetails");
		return list;
	}

	@RequestMapping(value = "/getrecordtype", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<String> getRecordTypes() {
		logger.debug("Entered addUserDetails");

		List<String> list = this.projectService.getRecordTypes();

		System.out.println("list:::" + list);

		logger.debug("Exiting addUserDetails");
		return list;
	}

	@RequestMapping(value = "/savemetadata", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String addMetaData(@RequestBody SourceMetaDto data) {
		logger.debug("Entered addMetaData");
		System.out.println("XXXXXXXX::" + data);
		try {
			long id = this.projectService.saveSourceMetaData(data);
			System.out.println("SAVED:::" + id);
			return "SUCCESS:" + id;
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Exiting addMetaData");
		return "ERROR";
	}

	@RequestMapping(value = "/srcconfdata", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody SourceConfDto getSourceConfData() {
		logger.debug("Entered addSourceConfData");

		try {
			return this.projectService.getSourceConfig();
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Exiting addSourceConfData");
		return new SourceConfDto();
	}

	@RequestMapping(value = "/source/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody SourceMetaDto getSourceDetails(@PathVariable("id") long id) {
		logger.debug("Entered getSourceDetails");

		try {
			return this.projectService.getSourceMetaData(id);
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Exiting getSourceDetails");
		return new SourceMetaDto();
	}

	@RequestMapping(value = "/projectsource/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<SourceMetaDto> getProjectSources(@PathVariable("projectId") long projectId) {
		logger.debug("Entered getProjectSources");
		List<SourceMetaDto> list = new ArrayList<SourceMetaDto>();
		try {
			Project prg = this.projectService.getProjectById(projectId);

			for (SourceMetaData smd : prg.getSourceMetaData()) {
				list.add(ServiceUtils.getSourceMetaDto(smd));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("List::" + list);
		logger.debug("Exiting getProjectSources");
		return list;
	}

	@RequestMapping(value = "/projectdbsource/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<SourceMetaDto> getProjectDBSources(@PathVariable("projectId") long projectId) {
		logger.debug("Entered getProjectDBSources");
		List<SourceMetaDto> list = new ArrayList<SourceMetaDto>();
		try {
			Project prg = this.projectService.getProjectById(projectId);

			for (SourceMetaData smd : prg.getSourceMetaData()) {
				if (SDPConstnts.SOURCE_DB.equals(smd.getSourceType().getName())) {
					list.add(ServiceUtils.getSourceMetaDto(smd));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("DB Source List>>" + list);
		logger.debug("Exiting getProjectDBSources");
		return list;
	}

	@RequestMapping(value = "/jobs/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<JobDto> getJobs(@PathVariable("projectId") long projectId) {
		logger.debug("Entered getJobs: " + projectId);
		List<JobDto> list = new ArrayList<JobDto>();
		try {
			List<JobDetails> jdList = this.projectService.getJobsForProject(projectId);

			if (jdList != null) {
				for (JobDetails jd : jdList) {
					list.add(new JobDto(jd.getJobId(), jd.getName(), jd.getDescription()));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("List::" + list);
		logger.debug("Exiting getJobs");
		return list;
	}

	@RequestMapping(value = "/wfs/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<JobDto> getWfs(@PathVariable("projectId") long projectId) {
		logger.debug("Entered getWfs: " + projectId);
		List<JobDto> list = new ArrayList<JobDto>();
		try {
			List<JobDetails> jdList = this.projectService.getSubWfsForProject(projectId);

			if (jdList != null) {
				for (JobDetails jd : jdList) {
					list.add(new JobDto(jd.getJobId(), jd.getName(), jd.getDescription()));
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("List::" + list);
		logger.debug("Exiting getWfs");
		return list;
	}

	@RequestMapping(value = "/addservice", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String addService(@RequestBody String data) {
		logger.debug("Entered addService");
		logger.debug("Request>>" + data);
		String msg = null;
		try {
			long id = this.projectService.saveService(data);
			if (id < 0) {
				msg = MessageUtils.getResponseMessage("ERROR", "Service already exist with name!!");
			} else {
				msg = MessageUtils.getResponseMessage("SUCCESS", "Service added successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (msg == null) {
			msg = MessageUtils.getResponseMessage("ERROR", "Fail to add Service");
		}

		logger.debug("Exiting addService");

		return msg;
	}

	@RequestMapping(value = "/getservices/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getServices(@PathVariable("projectId") long projectId) {
		logger.debug("Entered getServices");
		logger.debug("projectId>>" + projectId);
		String msg = null;
		try {
			JSONArray data = this.projectService.getService(projectId);
			logger.debug("data>>" + data);

			msg = MessageUtils.getResponseMessage("SUCCESS", data);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (msg == null) {
			msg = MessageUtils.getResponseMessage("ERROR", "Fail to get Services");
		}

		logger.debug("Response>>" + msg);
		logger.debug("Exiting getServices");

		return msg;
	}

	@RequestMapping(value = "/getudfs/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getUdfs(@PathVariable("projectId") long projectId) {
		logger.debug("Entered getUdfs");
		logger.debug("projectId>>" + projectId);
		String msg = null;
		try {
			JSONArray data = this.projectService.getUdf(projectId);
			logger.debug("data>>" + data);
			msg = MessageUtils.getResponseMessage("SUCCESS", data);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (msg == null) {
			msg = MessageUtils.getResponseMessage("ERROR", "Fail to get UDFs");
		}

		logger.debug("Response>>" + msg);
		logger.debug("Exiting getUdfs");

		return msg;
	}

	@RequestMapping(value = "/getservicedetail/{serviceId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getServiceDetails(@PathVariable("serviceId") long serviceId) {
		logger.debug("Entered getServiceDetails");
		String msg = null;
		try {
			JSONObject sd = this.projectService.getServiceDetail(serviceId);
			logger.debug("DATA>>" + sd);
			msg = MessageUtils.getResponseMessage("SUCCESS", sd);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (msg == null) {
			msg = MessageUtils.getResponseMessage("ERROR", "Fail to get UDFs");
		}

		logger.debug("Response>>" + msg);
		logger.debug("Exiting getServiceDetails");

		return msg;
	}
}
