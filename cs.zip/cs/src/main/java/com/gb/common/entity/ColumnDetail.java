package com.gb.common.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "SOURCE_COLUMN", uniqueConstraints=@UniqueConstraint(columnNames={"name","SOURCE_ID"}))
public class ColumnDetail {
	@Id
	@Column(name = "COLUMN_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	Long id;

	String name;

	Boolean sensitiveFlag;
	Integer pos;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "DATA_TYPE_NAME")
	DataType dateType;

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "SOURCE_ID")
	SourceMetaData sourceMetaData;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPos() {
		return pos;
	}

	public void setPos(Integer pos) {
		this.pos = pos;
	}

	public SourceMetaData getSourceMetaData() {
		return sourceMetaData;
	}

	public void setSourceMetaData(SourceMetaData sourceMetaData) {
		this.sourceMetaData = sourceMetaData;
	}

	public Boolean getSensitiveFlag() {
		return sensitiveFlag;
	}

	public void setSensitiveFlag(Boolean sensitiveFlag) {
		this.sensitiveFlag = sensitiveFlag;
	}

	public DataType getDateType() {
		return dateType;
	}

	public void setDateType(DataType dateType) {
		this.dateType = dateType;
	}
	
	@Override
	public String toString() {
		return "{name: " + this.name + ", pos:" + this.pos + "}";
	}
}
