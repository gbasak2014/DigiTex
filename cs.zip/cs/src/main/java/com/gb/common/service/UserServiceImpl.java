package com.gb.common.service;

import java.util.HashSet;
import java.util.Set;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.gb.common.dao.ProjectDao;
import com.gb.common.dao.UserDao;
import com.gb.common.dto.AuthenticateDto;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.UserDetailReqDto;
import com.gb.common.entity.Project;
import com.gb.common.entity.Role;
import com.gb.common.entity.UserDetails;
import com.gb.common.util.ServiceUtils;

@Service(value = "userService")
public class UserServiceImpl implements UserService {
	static final Logger logger = Logger.getLogger(UserServiceImpl.class);

	@Autowired
	@Qualifier("userDao")
	UserDao userDao;

	@Autowired
	@Qualifier("projectDao")
	ProjectDao projectDao;

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public ResponseDto getUserById(String userId) {
		UserDetails ud = this.userDao.getUserById(userId);
		return ServiceUtils.getDto(ud);
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public ResponseDto registerUser(UserDetailReqDto user) {

		if (this.userDao.getUserById(user.getUserId()) != null) {
			ResponseDto dto = new ResponseDto();
			dto.setStatus("EXIST");
			return dto;
		}

		UserDetails ud = new UserDetails();
		ud.setUserId(user.getUserId());
		ud.setAnswer1(user.getAnswer1());
		ud.setAnswer2(user.getAnswer2());
		ud.setName(user.getName());
		ud.setPwd(user.getPtxt1());
		ud.setQuestion1(user.getQuestion1());
		ud.setQuestion2(user.getQuestion2());

		Project p = new Project();
		p.setDescription(user.getProjectDesc());
		p.setName(user.getProjectName());
		p.setClusterHost(user.getClusterHost());
		p.setClusterPort(user.getClusterPort());
		p.setClusterUser(user.getClusterUser());
		p.setClusterPassword(user.getClusterPwd());
		p.setClusterHome(user.getClusterHome());
		
		Set<Project> projects = new HashSet<Project>();
		projects.add(p);
		ud.setProjects(projects);

		Set<Role> roles = new HashSet<Role>();
		Role r = this.projectDao.getRoleByName("ADMIN");
		if (r != null) {
			roles.add(r);
		} else {
			r = new Role();
			r.setName("ADMIN");
			r.setId(null);
			roles.add(r);
		}

		r = this.projectDao.getRoleByName("USER");
		if (r != null) {
			roles.add(r);
		} else {
			r = new Role();
			r.setName("USER");
			r.setId(null);
			roles.add(r);
		}

		ud.setRoles(roles);

		UserDetails newUd = this.userDao.saveUser(ud);

		if (newUd == null) {
			ResponseDto dto = new ResponseDto();
			dto.setStatus("FAIL");
			return dto;
		}

		ResponseDto dto = ServiceUtils.getDto(newUd);
		dto.setStatus("SUCCESS");

		return dto;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public ResponseDto authenticateUser(AuthenticateDto authJson) {
		System.out.println("===================================================");
		System.out.println("authJson:::" + authJson);
		UserDetails ud = this.userDao.getUserById(authJson.getUserId());

		System.out.println("ud:::" + ud);
		if (ud == null || !ud.getPwd().equals(authJson.getPassword())) {
			ResponseDto r = new ResponseDto();
			r.setStatus("FAIL");
			return r;
		}

		System.out.println("UserDetails::" + ud.toString());
		ResponseDto r = ServiceUtils.getDto(ud);
		r.setStatus("SUCCESS");

		System.out.println("===================================================");
		return r;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public ResponseDto addUserToProject(UserDetailReqDto user) {

		UserDetails ud = new UserDetails();
		ud.setUserId(user.getUserId());
		ud.setAnswer1(user.getAnswer1());
		ud.setAnswer2(user.getAnswer2());
		ud.setName(user.getName());
		ud.setPwd(user.getPtxt1());
		ud.setQuestion1(user.getQuestion1());
		ud.setQuestion2(user.getQuestion2());

		Project project = this.projectDao.getProjectById(user.getProjectId());
		Set<Project> projects = new HashSet<Project>();
		projects.add(project);
		ud.setProjects(projects);

		Role role = this.projectDao.getRoleByName("USER");
		Set<Role> roles = new HashSet<Role>();
		roles.add(role);
		ud.setRoles(roles);

		UserDetails newUd = this.userDao.saveUser(ud);

		if (newUd == null) {
			ResponseDto dto = new ResponseDto();
			dto.setStatus("FAIL");
			return dto;
		}

		ResponseDto dto = ServiceUtils.getDto(newUd);
		dto.setStatus("SUCCESS");

		return dto;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public ResponseDto addProject(UserDetailReqDto user) {
		UserDetails ud = this.userDao.getUserById(user.getUserId());
		Project p = new Project();
		p.setName(user.getProjectName());
		p.setDescription(user.getProjectDesc());
		ud.getProjects().add(p);

		UserDetails newUd = this.userDao.saveUser(ud);

		if (newUd == null) {
			ResponseDto dto = new ResponseDto();
			dto.setStatus("FAIL");
			return dto;
		}

		ResponseDto dto = ServiceUtils.getDto(newUd);
		dto.setStatus("SUCCESS");

		return dto;
	}
}
