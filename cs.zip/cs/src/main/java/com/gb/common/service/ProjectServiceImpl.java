package com.gb.common.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.gb.common.dao.ProjectDao;
import com.gb.common.dao.UserDao;
import com.gb.common.dto.ColumnDto;
import com.gb.common.dto.ProjectReqDtl;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.SourceConfDto;
import com.gb.common.dto.SourceMetaDto;
import com.gb.common.entity.ColumnDetail;
import com.gb.common.entity.DataType;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.Project;
import com.gb.common.entity.ProjectConfig;
import com.gb.common.entity.RecordType;
import com.gb.common.entity.ServiceDetail;
import com.gb.common.entity.ServiceParams;
import com.gb.common.entity.ServiceRetType;
import com.gb.common.entity.SourceMetaData;
import com.gb.common.entity.SourceType;
import com.gb.common.entity.UserDetails;
import com.gb.common.util.ServiceUtils;

@Service(value = "projectService")
public class ProjectServiceImpl implements ProjectService {
	static final Logger logger = Logger.getLogger(ProjectServiceImpl.class);

	@Autowired
	@Qualifier("projectDao")
	ProjectDao projectDao;

	@Autowired
	@Qualifier("userDao")
	UserDao userDao;

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public Project getProjectById(Long projectId) {
		return this.projectDao.getProjectById(projectId);
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public Set<UserDetails> getUsersByProjectId(Long projectId) {
		Project p = this.getProjectById(projectId);

		return p.getUsers();
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public Set<ProjectConfig> getConfigByProjectId(Long projectId) {
		Project p = this.getProjectById(projectId);
		return p.getConfigSet();
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public ProjectConfig saveProjectConfig(ProjectConfig pc, Long projectId) {
		Project p = this.getProjectById(projectId);
		pc.setProject(p);
		ProjectConfig pcNew = this.projectDao.saveConfig(pc);
		return pcNew;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public ResponseDto saveProject(ProjectReqDtl project) {

		UserDetails user = this.userDao.getUserById(project.getUserId());
		for (Project p : user.getProjects()) {
			if (p.getName().equals(project.getName())) {
				ResponseDto dto = new ResponseDto();
				dto.setStatus("EXIST");
				return dto;
			}
		}

		Project prj = new Project();
		prj.setName(project.getName());
		prj.setDescription(project.getDescription());
		prj.setClusterHome(project.getClusterHome());
		prj.setClusterHost(project.getClusterHost());
		prj.setClusterPassword(project.getClusterPwd());
		prj.setClusterPort(project.getClusterPort());
		prj.setClusterUser(project.getClusterUser());

		user.getProjects().add(prj);

		Set<UserDetails> users = new HashSet<UserDetails>();
		prj.setUsers(users);

		UserDetails newUser = this.userDao.saveUser(user);
		if (newUser != null) {
			return ServiceUtils.getDto(newUser);
		}

		ResponseDto dto = new ResponseDto();
		dto.setStatus("ERROR");
		return dto;

	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public List<String> getRecordTypes() {
		List<RecordType> list = this.projectDao.getAllRecordType();
		List<String> lst = new ArrayList<String>();
		for (RecordType rc : list) {
			lst.add(rc.getName());
		}

		return lst;
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public List<String> getSourceTypes() {
		List<SourceType> list = this.projectDao.getAllSourceType();
		List<String> lst = new ArrayList<String>();
		for (SourceType rc : list) {
			lst.add(rc.getName());
		}

		return lst;
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public long saveSourceMetaData(SourceMetaDto data) {
		SourceMetaData val = new SourceMetaData();
		val.setDelimiter(data.getDelimiter());
		val.setDescription(data.getDescription());
		val.setMetaName(data.getMetaName());
		val.setPassword(data.getPassword());
		RecordType rt = new RecordType();
		rt.setName(data.getRecordType());
		val.setRecordType(rt);
		val.setSource(data.getSource());
		SourceType st = new SourceType();
		st.setName(data.getSourceType());
		val.setSourceType(st);
		val.setUser(data.getUser());
		Project p = new Project();
		p.setId(data.getProjectId());
		val.setProject(p);

		Set<ColumnDetail> cdSet = new HashSet<ColumnDetail>();
		for (ColumnDto dc : data.getColumnTable()) {
			ColumnDetail cd = new ColumnDetail();
			cd.setName(dc.getName());
			cd.setPos(dc.getPos());
			cd.setSensitiveFlag(dc.getSensitiveFlag());
			cd.setSourceMetaData(val);
			DataType dt = new DataType();
			dt.setName(dc.getDataType());
			cd.setDateType(dt);

			cdSet.add(cd);
		}
		val.setColumns(cdSet);

		System.out.println("Src Meta:" + val);
		return this.projectDao.saveSourceMetaData(val);
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public SourceConfDto getSourceConfig() {
		List<RecordType> rts = this.projectDao.getAllRecordType();
		List<DataType> dts = this.projectDao.getAllDataType();
		List<SourceType> sts = this.projectDao.getAllSourceType();

		SourceConfDto dto = new SourceConfDto();
		for (RecordType rt : rts) {
			dto.addRecordType(rt.getName());
		}
		for (DataType dt : dts) {
			dto.addDataType(dt.getName());
		}
		for (SourceType st : sts) {
			dto.addSourceType(st.getName());
		}

		return dto;
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public SourceMetaDto getSourceMetaData(long id) {
		SourceMetaData smd = this.projectDao.getSourceMetaData(id);
		return ServiceUtils.getSourceMetaDto(smd);
	}

	public List<String> getJobNamesForProject(long projectId) {
		List<JobDetails> jdList = this.projectDao.getJobs(projectId);

		List<String> list = new ArrayList<String>();
		if (jdList != null) {
			for (JobDetails jd : jdList) {
				list.add(jd.getJobId() + " - " + jd.getName());
			}
		}
		return list;
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public List<JobDetails> getJobsForProject(long projectId) {
		List<JobDetails> jdList = this.projectDao.getJobs(projectId);
		System.out.println("****************************");
		System.out.println("jdList> " + jdList);
		System.out.println("****************************");

		return jdList;
	}

	@Override
	public List<JobDetails> getSubWfsForProject(long projectId) {
		List<JobDetails> jdList = this.projectDao.getSubWorkflows(projectId);
		System.out.println("****************************");
		System.out.println("Sub WFs> " + jdList);
		System.out.println("****************************");

		return jdList;
	}
	
	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveService(String json) {
		logger.debug("Entered saveService");
		JSONObject jsonService = new JSONObject(json);
		String serviceName = jsonService.getString("name");
		long projectId = jsonService.getLong("projectId");

		ServiceDetail sd = this.projectDao.getService(projectId, serviceName);
		if (sd != null) {
			return -1;
		}

		String type = jsonService.getString("type");
		String code = jsonService.getString("code");
		String returnCategory = jsonService.getString("returnCategory");
		String desc = jsonService.getString("description");
		String imprts = jsonService.getString("imports");
		
		ServiceDetail sDetail = new ServiceDetail();
		sDetail.setCode(code);
		sDetail.setName(serviceName);
		sDetail.setDescription(desc);
		sDetail.setReturnCategory(returnCategory);
		sDetail.setType(type);
		sDetail.setProjectId(projectId);
		sDetail.setImports(imprts);
		
		JSONArray arrParams = jsonService.getJSONArray("params");
		Set<ServiceParams> params = new HashSet<ServiceParams>();
		int s = arrParams.length();
		for (int i = 0; i < s; i++) {
			JSONObject objP = arrParams.getJSONObject(i);
			ServiceParams sp = new ServiceParams();
			sp.setName(objP.getString("name"));
			sp.setDataType(objP.getString("type"));
			sp.setPos(objP.getInt("pos"));
			sp.setServiceDetail(sDetail);
			params.add(sp);
		}
		sDetail.setParams(params);

		JSONArray arrRet = jsonService.getJSONArray("returnType");
		Set<ServiceRetType> returns = new HashSet<ServiceRetType>();
		s = arrRet.length();
		for (int i = 0; i < s; i++) {
			JSONObject objR = arrRet.getJSONObject(i);
			ServiceRetType srt = new ServiceRetType();
			srt.setName(objR.getString("name"));
			srt.setDataType(objR.getString("dataType"));
			srt.setSensitiveFlag(objR.getBoolean("sensitiveFlag"));
			srt.setPos(objR.getInt("pos"));
			srt.setServiceDetail(sDetail);
			returns.add(srt);
		}
		sDetail.setRetTypes(returns);

		long id = this.projectDao.saveService(sDetail);

		logger.debug("Exiting saveService");
		return id;
	}

	@Override
	public JSONArray getService(long projectId) {
		logger.debug("Entered getService");
		List<ServiceDetail> list = this.projectDao.getServiceList(projectId, "service");
		
		Set<ServiceDetail> set = new HashSet<ServiceDetail>();
		for (ServiceDetail sd : list) {
			if (!set.contains(sd)) {
				set.add(sd);
			}
		}

		logger.debug("Exiting getService");
		return ServiceUtils.convertToJson(set);
	}

	@Override
	public JSONArray getUdf(long projectId) {
		logger.debug("Entered getUdf");
		List<ServiceDetail> list = this.projectDao.getServiceList(projectId, "udf");
		
		Set<ServiceDetail> set = new HashSet<ServiceDetail>();
		for (ServiceDetail sd : list) {
			if (!set.contains(sd)) {
				set.add(sd);
			}
		}
		
		
		logger.debug("Exiting getUdf");
		return ServiceUtils.convertToJson(set);
	}

	@Override
	public JSONObject getServiceDetail(long serviceId) {
		logger.debug("Entered getServiceDetail");
		ServiceDetail sd = this.projectDao.getServiceDetail(serviceId);
		logger.debug("Exiting getServiceDetail");
		
		return ServiceUtils.getJson(sd);
	}
}
