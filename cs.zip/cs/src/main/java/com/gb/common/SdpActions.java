package com.gb.common;

public interface SdpActions {
	int EXECUTE_JOB = 1;
	int CREATE_SQOOP_JOB = 2;
}
