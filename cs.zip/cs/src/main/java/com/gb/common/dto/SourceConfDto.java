package com.gb.common.dto;

import java.util.ArrayList;
import java.util.List;

public class SourceConfDto {
	List<String> sourceTypes = new ArrayList<String>();
	List<String> recordTypes = new ArrayList<String>();
	List<String> dataTypes = new ArrayList<String>();

	public List<String> getSourceTypes() {
		return sourceTypes;
	}

	public void setSourceTypes(List<String> sourceTypes) {
		this.sourceTypes = sourceTypes;
	}

	public List<String> getRecordTypes() {
		return recordTypes;
	}

	public void setRecordTypes(List<String> recordTypes) {
		this.recordTypes = recordTypes;
	}

	public List<String> getDataTypes() {
		return dataTypes;
	}

	public void setDataTypes(List<String> dataTypes) {
		this.dataTypes = dataTypes;
	}

	public void addDataType(String dataType) {
		this.dataTypes.add(dataType);
	}

	public void addSourceType(String sourceType) {
		this.sourceTypes.add(sourceType);
	}

	public void addRecordType(String recordType) {
		this.recordTypes.add(recordType);
	}
}
