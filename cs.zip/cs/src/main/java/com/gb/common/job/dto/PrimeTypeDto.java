package com.gb.common.job.dto;

public class PrimeTypeDto extends BaseDto {
	String dataType;
	String parentColumn;

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getParentColumn() {
		return parentColumn;
	}

	public void setParentColumn(String parentColumn) {
		this.parentColumn = parentColumn;
	}

	@Override
	public String getVariableName() {
		return this.name;
	}

	@Override
	public String getDataFrameName() {
		return this.name;
	}
}