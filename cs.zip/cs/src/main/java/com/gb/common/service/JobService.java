package com.gb.common.service;

import com.gb.spark.wf.dependency.mvn.DependencyList;

public interface JobService {
	void generateJob(String json, DependencyList dependencyList);

	long saveJob(String json);

	String getJob(String jobId);

	String getJob(long projectId, String jobName);

	String getSubWorkflow(long subWfId);
	
	String getSubWorkflowHeader(long subWfId);
}
