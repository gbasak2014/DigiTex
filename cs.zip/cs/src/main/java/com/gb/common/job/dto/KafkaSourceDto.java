package com.gb.common.job.dto;

import java.util.List;

public class KafkaSourceDto {
String name;
String componentType;
List<String> fields;
List<String> predecessor;
List<String> successors;
String recordType;

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getComponentType() {
	return componentType;
}
public void setComponentType(String componentType) {
	this.componentType = componentType;
}
public List<String> getFields() {
	return fields;
}
public void setFields(List<String> fields) {
	this.fields = fields;
}
public List<String> getPredecessor() {
	return predecessor;
}
public void setPredecessor(List<String> predecessor) {
	this.predecessor = predecessor;
}
public List<String> getSuccessors() {
	return successors;
}
public void setSuccessors(List<String> successors) {
	this.successors = successors;
}
public String getRecordType() {
	return recordType;
}
public void setRecordType(String recordType) {
	this.recordType = recordType;
}

}
