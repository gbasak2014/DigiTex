package com.gb.common.job.dto;

public class ArgParamEntry {
	String name;
	String type;
	int pos;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	@Override
	public String toString() {
		return "{" + this.name + ", " + this.type + ", " + this.pos + "}";
	}
}
