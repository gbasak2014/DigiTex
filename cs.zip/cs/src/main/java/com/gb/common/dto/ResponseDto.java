package com.gb.common.dto;

import java.util.Set;

public class ResponseDto {
	String status;
	String userName;
	String userId;
	Set<String> roles;
	Set<ProjectDto> projects;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Set<String> getRoles() {
		return roles;
	}

	public void setRoles(Set<String> roles) {
		this.roles = roles;
	}

	public Set<ProjectDto> getProjects() {
		return projects;
	}

	public void setProjects(Set<ProjectDto> projects) {
		this.projects = projects;
	}
}
