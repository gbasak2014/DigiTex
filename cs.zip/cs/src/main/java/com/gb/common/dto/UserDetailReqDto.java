package com.gb.common.dto;

import java.util.List;

public class UserDetailReqDto {
	String userId;
	String name;
	String email;
	String question1;
	String question2;
	String answer1;
	String answer2;
	String ptxt1;
	String ptxt2;

	Long projectId;
	String projectName;
	String projectDesc;
	String clusterUser;
	String clusterPwd;
	String clusterHost;
	String clusterPort;
	String clusterHome;

	
	List<String> roles;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getQuestion1() {
		return question1;
	}

	public void setQuestion1(String question1) {
		this.question1 = question1;
	}

	public String getQuestion2() {
		return question2;
	}

	public void setQuestion2(String question2) {
		this.question2 = question2;
	}

	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getPtxt1() {
		return ptxt1;
	}

	public void setPtxt1(String ptxt1) {
		this.ptxt1 = ptxt1;
	}

	public String getPtxt2() {
		return ptxt2;
	}

	public void setPtxt2(String ptxt2) {
		this.ptxt2 = ptxt2;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProjectDesc() {
		return projectDesc;
	}

	public void setProjectDesc(String projectDesc) {
		this.projectDesc = projectDesc;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getClusterUser() {
		return clusterUser;
	}

	public void setClusterUser(String clusterUser) {
		this.clusterUser = clusterUser;
	}

	public String getClusterPwd() {
		return clusterPwd;
	}

	public void setClusterPwd(String clusterPwd) {
		this.clusterPwd = clusterPwd;
	}

	public String getClusterHost() {
		return clusterHost;
	}

	public void setClusterHost(String clusterHost) {
		this.clusterHost = clusterHost;
	}

	public String getClusterPort() {
		return clusterPort;
	}

	public void setClusterPort(String clusterPort) {
		this.clusterPort = clusterPort;
	}

	public String getClusterHome() {
		return clusterHome;
	}

	public void setClusterHome(String clusterHome) {
		this.clusterHome = clusterHome;
	}

}
