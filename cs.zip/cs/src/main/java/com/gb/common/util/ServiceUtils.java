package com.gb.common.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.gb.common.dto.ColumnDto;
import com.gb.common.dto.ProjectDto;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.SourceMetaDto;
import com.gb.common.entity.ColumnDetail;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.JobParam;
import com.gb.common.entity.JobStep;
import com.gb.common.entity.Project;
import com.gb.common.entity.Role;
import com.gb.common.entity.ServiceDetail;
import com.gb.common.entity.ServiceParams;
import com.gb.common.entity.ServiceRetType;
import com.gb.common.entity.SourceMetaData;
import com.gb.common.entity.SubWfStep;
import com.gb.common.entity.SubWorkflow;
import com.gb.common.entity.UserDetails;

public class ServiceUtils {
	static final Logger logger = Logger.getLogger(ServiceUtils.class);

	public static UserDetails jsonToUserDetail(JSONObject udObj) {
		UserDetails ud = new UserDetails();

		ud.setUserId((String) getValue("userId", udObj));
		ud.setAnswer1((String) getValue("name", udObj));
		ud.setAnswer2((String) getValue("email", udObj));
		ud.setCountry((String) getValue("question1", udObj));
		ud.setName((String) getValue("question2", udObj));
		ud.setPwd((String) getValue("answer1", udObj));
		ud.setQuestion1((String) getValue("answer2", udObj));
		ud.setQuestion2((String) getValue("ptxt1", udObj));
		ud.setState((String) getValue("ptxt2", udObj));

		return ud;
	}

	/*
	 * public static Project jsonToProject(JSONObject pObj) { Project p = new
	 * Project(); p.setId((Long) getValue("id", pObj));
	 * p.setDescription((String) getValue("projectName", pObj));
	 * p.setName((String) getValue("projectDesc", pObj));
	 * 
	 * return p; }
	 * 
	 * public static Set<Role> jsonToRole(JSONArray arr) { Set<Role> roles = new
	 * HashSet<Role>();
	 * 
	 * for (int i = 0; i < arr.length(); i++) { JSONObject json = (JSONObject)
	 * arr.getJSONObject(i); Role r = new Role(); r.setId((Long) getValue("id",
	 * json)); r.setName((String) getValue("name", json)); roles.add(r); }
	 * 
	 * return roles; }
	 */
	public static Object getValue(String key, JSONObject json) {
		try {
			return json.get(key);
		} catch (Exception e) {
		}

		return null;
	}

	public static void main(String[] args) {
		String jsn = "{\"user\":{\"name\":\"Shourya\", \"grade\":\"1.X\"}}";
		JSONObject jo = new JSONObject(jsn);
		JSONObject ju = jo.getJSONObject("user");

		System.out.println(getValue("name", ju));
		System.out.println((Long) getValue("SYZ", ju));
	}

	public static ResponseDto getDto(UserDetails user) {
		ResponseDto dto = new ResponseDto();

		if (user != null) {
			dto.setUserId(user.getUserId());
			dto.setUserName(user.getName());

			Set<ProjectDto> projects = new HashSet<ProjectDto>();
			for (Project p : user.getProjects()) {
				ProjectDto pDto = new ProjectDto();
				pDto.setDescription(p.getDescription());
				pDto.setId(p.getId());
				pDto.setName(p.getName());
				pDto.setClusterHome(p.getClusterHome());
				pDto.setClusterHost(p.getClusterHost());
				pDto.setClusterPort(p.getClusterPort());
				pDto.setClusterPwd(p.getClusterPassword());
				pDto.setClusterUser(p.getClusterUser());

				projects.add(pDto);
			}
			dto.setProjects(projects);

			Set<String> roles = new HashSet<String>();
			Set<Role> rSet = user.getRoles();
			for (Role r : rSet) {
				roles.add(r.getName());
			}
			dto.setRoles(roles);
			dto.setStatus("SUCCESS");
		}

		return dto;
	}

	public static SourceMetaDto getSourceMetaDto(SourceMetaData src) {
		System.out.println("Entered getSourceMetaDto");
		System.out.println("---------------------------------------");
		System.out.println(src.toString());
		System.out.println("---------------------------------------");
		SourceMetaDto dto = new SourceMetaDto();
		List<ColumnDto> cols = new ArrayList<ColumnDto>();
		for (ColumnDetail cd : src.getColumns()) {
			ColumnDto col = new ColumnDto();
			col.setId(cd.getId());
			col.setDataType(cd.getDateType().getName());
			col.setName(cd.getName());
			col.setPos(cd.getPos());
			col.setSensitiveFlag(cd.getSensitiveFlag());
			cols.add(col);
		}

		dto.setColumnTable(cols);
		dto.setId(src.getId());
		dto.setDelimiter(src.getDelimiter());
		dto.setDescription(src.getDescription());
		dto.setMetaName(src.getMetaName());
		dto.setPassword(src.getPassword());
		dto.setProjectId(src.getProject().getId());
		dto.setRecordType(src.getRecordType() != null ? src.getRecordType().getName() : "NA");
		dto.setSource(src.getSource());
		dto.setSourceType(src.getSourceType().getName());
		dto.setUser(src.getUser());

		System.out.println("Exiting getSourceMetaDto");
		return dto;
	}

	public static void refreshJSON(JobDetails job, JSONObject json) {
		Map<String, Long> map = new HashMap<String, Long>();
		for (JobStep js : job.getSteps()) {
			String nm = js.getName();
			if (!map.containsKey(nm)) {
				map.put(nm, js.getTaskId());
			}
		}

		System.out.println("********************************************************************");
		for (String sNm : map.keySet()) {
			try {
				JSONObject obj = json.getJSONObject(sNm);
				obj.put("id", map.get(sNm));
				System.out.println(sNm + "<>" + map.get(sNm));
			} catch (Exception e) {
				logger.error("ERROR Setting json Task ID");
				logger.error(e.getMessage());
			}
		}
		System.out.println("********************************************************************");
	}

	public static JSONObject getJSON(JobDetails job) {
		logger.debug("Entered getJSON");
		JSONObject json = new JSONObject();

		JSONObject start = null;
		for (JobStep step : job.getSteps()) {
			String name = step.getName();
			long id = step.getTaskId();
			JSONObject obj = new JSONObject(step.getCode());
			obj.put("id", id);
			json.put(name, obj);

			if ("start".equalsIgnoreCase(name)) {
				start = obj;
			}
		}

		if (start != null) {
			JSONArray arr = new JSONArray();
			int i = 0;
			for (JobParam jp : job.getParams()) {
				JSONObject obj = new JSONObject();
				obj.put("id", jp.getParamId());
				obj.put("param", jp.getParamKey());
				obj.put("type", jp.getParamType());
				arr.put(i, obj);
				i++;
			}
			start.put("params", arr);
			start.put("jobId", job.getJobId());
			start.put("jobDesc", job.getDescription());
			start.put("projectId", job.getProjectId());
			start.put("jobType", job.getType());
			start.put("jobName", job.getName());
		}

		logger.debug("Exiting getJSON");
		return json;
	}

	public static JSONObject getHeaderJSON(JobDetails job) {
		logger.debug("Entered getHeaderJSON");
		JSONObject json = new JSONObject();

		Map<String, JobStep> map = new HashMap<String, JobStep>();
		for (JobStep stp : job.getSteps()) {
			map.put(stp.getName(), stp);
		}

		JobStep start = map.get("start");
		long id = start.getTaskId();
		JSONObject startJson = new JSONObject(start.getCode());
		startJson.put("id", id);

		if (start != null) {
			JSONArray arr = new JSONArray();
			int i = 0;
			for (JobParam jp : job.getParams()) {
				JSONObject obj = new JSONObject();
				obj.put("id", jp.getParamId());
				obj.put("param", jp.getParamKey());
				obj.put("type", jp.getParamType());
				arr.put(i, obj);
				i++;
			}
			startJson.put("params", arr);
			startJson.put("jobId", job.getJobId());
			startJson.put("jobDesc", job.getDescription());
			startJson.put("projectId", job.getProjectId());
			startJson.put("subWfName", job.getName());
		}
		json.put("start", startJson);

		JSONArray arr = startJson.getJSONArray("successors");
		int s = arr.length();
		for (int i = 0; i < s; i++) {
			String sName = arr.getString(i);
			JobStep step = map.get(sName);
			id = step.getTaskId();
			JSONObject obj = new JSONObject(step.getCode());
			obj.put("id", id);
			json.put(sName, obj);
		}

		if (map.get("end") != null) {
			JobStep end = map.get("end");
			JSONObject endJson = new JSONObject(end.getCode());
			endJson.put("id", end.getTaskId());
			json.put("end", endJson);
		}

		logger.debug("Exiting getHeaderJSON");
		return json;
	}

	public static String getJSON(SubWorkflow sWf) {
		logger.debug("Entered getJSON");
		JSONObject json = new JSONObject();
		JSONObject wfDtl = new JSONObject(sWf.getCode());
		wfDtl.put("id", sWf.getSubWfId());
		json.put("subWfDetail", wfDtl);

		JSONObject start = null;
		for (SubWfStep step : sWf.getSteps()) {
			String name = step.getName();
			long id = step.getTaskId();
			JSONObject obj = new JSONObject(step.getCode());
			obj.put("id", id);
			json.put(name, obj);

			if ("start".equalsIgnoreCase(name)) {
				start = obj;
			}
		}

		if (start != null) {
			start.put("jobId", sWf.getJobDetails().getJobId());
			start.put("jobName", sWf.getName());
			start.put("jobDesc", sWf.getDescription());
			start.put("projectId", sWf.getJobDetails().getProjectId());
		}

		logger.debug("Exiting getJSON");
		return json.toString();
	}

	public static List<JobParam> refreshJobParams(JobDetails job, JSONObject start) {
		logger.debug("Entered refreshJobParams");
		Set<JobParam> params = job.getParams();
		if (params == null) {
			params = new HashSet<JobParam>();
			job.setParams(params);
		}

		Map<String, JSONObject> paramMap = new HashMap<String, JSONObject>();
		JSONArray pArr = start.getJSONArray("params");
		for (int i = 0; i < pArr.length(); i++) {
			JSONObject obj = pArr.getJSONObject(i);
			String key = obj.getString("param");
			paramMap.put(key, obj);
		}

		List<JobParam> rl = new ArrayList<JobParam>();
		// Update existing parameters
		for (JobParam jp : params) {
			JSONObject obj = paramMap.remove(jp.getParamKey());
			if (obj != null) {
				String val = obj.getString("type");
				jp.setParamType(val);
				jp.setVersion(jp.getVersion() + 1);
			} else {
				rl.add(jp);
			}
		}

		// Remove existing extra parameters
		params.removeAll(rl);

		// Add new parameters
		for (JSONObject obj : paramMap.values()) {
			String key = obj.getString("param");
			String val = obj.getString("type");
			JobParam jpNew = new JobParam();
			jpNew.setParamKey(key);
			jpNew.setParamType(val);
			jpNew.setJobDetails(job);
			params.add(jpNew);
		}

		logger.debug("Params>>" + job.getParams());
		logger.debug("Exiting refreshJobParams");

		// Return extra parameters which will be deleted.
		return rl;
	}

	public static List<JobStep> refreshJobSteps(JobDetails job, Map<String, JSONObject> taskMap) {
		logger.debug("Entered refreshJobSteps");
		Map<String, JSONObject> tmpMap = new HashMap<String, JSONObject>();
		tmpMap.putAll(taskMap);

		Set<JobStep> steps = job.getSteps();
		if (steps == null) {
			steps = new HashSet<JobStep>();
			job.setSteps(steps);
		}

		List<JobStep> rl = new ArrayList<JobStep>();
		// Update existing steps
		for (JobStep js : steps) {
			JSONObject stp = tmpMap.remove(js.getName());
			if (stp != null) {
				js.setCode(stp.toString());
				js.setVersion(js.getVersion() + 1);
			} else {
				rl.add(js);
			}
		}
		// Remove existing extra steps
		steps.removeAll(rl);

		// Add new steps
		for (String stpNm : tmpMap.keySet()) {
			JSONObject task = taskMap.get(stpNm);
			JobStep stp = new JobStep();
			stp.setCode(task.toString());
			stp.setName(stpNm);
			stp.setJobDetails(job);
			stp.setVersion(0);
			steps.add(stp);
		}

		logger.debug("Steps >>" + job.getSteps());
		logger.debug("Exiting refreshJobSteps");

		// Return extra steps which will be deleted.
		return rl;
	}

	public static void refreshSubWfSteps(SubWorkflow sWf, Map<String, JSONObject> taskMap) {
		logger.debug("Entered refreshSubWfSteps");
		Map<String, JSONObject> tmpMap = new HashMap<String, JSONObject>();
		tmpMap.putAll(taskMap);

		Set<SubWfStep> steps = sWf.getSteps();
		if (steps == null) {
			steps = new HashSet<SubWfStep>();
			sWf.setSteps(steps);
		}

		List<SubWfStep> rl = new ArrayList<SubWfStep>();
		// Update existing steps
		for (SubWfStep js : steps) {
			JSONObject stp = tmpMap.remove(js.getName());
			if (stp != null) {
				js.setSubWorkflow(sWf);
				js.setCode(stp.toString());
				js.setVersion(js.getVersion() + 1);
			} else {
				js.setSubWorkflow(null);
				rl.add(js);
			}
		}
		// Remove existing extra steps
		steps.removeAll(rl);

		// Add new steps
		for (String stpNm : tmpMap.keySet()) {
			JSONObject task = taskMap.get(stpNm);
			SubWfStep stp = new SubWfStep();
			stp.setCode(task.toString());
			stp.setName(stpNm);
			stp.setSubWorkflow(sWf);
			stp.setVersion(0);
			steps.add(stp);
		}

		logger.debug("SUB WF Steps >>" + sWf.getSteps());
		logger.debug("Exiting refreshSubWfSteps");
	}

	public static JSONArray convertToJson(Set<ServiceDetail> set) {
		JSONArray arr = new JSONArray();
		for (ServiceDetail sd : set) {
			arr.put(getJson(sd));
		}

		return arr;
	}

	public static JSONObject getJson(ServiceDetail sd) {
		JSONObject obj = new JSONObject();
		obj.put("id", sd.getId());
		obj.put("name", sd.getName());
		obj.put("description", sd.getDescription());
		obj.put("retCategory", sd.getReturnCategory());

		Set<ServiceParams> params = sd.getParams();
		JSONArray arrP = new JSONArray();
		for (ServiceParams sp : params) {
			JSONObject oSp = new JSONObject();
			oSp.put("id", sp.getId());
			oSp.put("name", sp.getName());
			oSp.put("dataType", sp.getDataType());
			oSp.put("pos", sp.getPos());
			arrP.put(oSp);
		}
		obj.put("params", arrP);

		Set<ServiceRetType> ret = sd.getRetTypes();
		JSONArray arrR = new JSONArray();
		for (ServiceRetType rt : ret) {
			JSONObject oRt = new JSONObject();
			oRt.put("id", rt.getId());
			oRt.put("name", rt.getName());
			oRt.put("dataType", rt.getDataType());
			oRt.put("pos", rt.getPos());
			oRt.put("sensitive", rt.getSensitiveFlag());
			arrR.put(oRt);
		}
		obj.put("returnTypes", arrR);

		return obj;
	}

}
