package com.mdm.gb.common.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;

import com.mdm.gb.common.entity.DBSource;
import com.mdm.gb.common.entity.FileSource;
import com.mdm.gb.common.entity.SourceSystem;

@Component(value = "mdmDao")
public class MdmDaoImpl extends AbstractDao implements MdmDao {

	@Override
	public SourceSystem getSourceSystem(long ssId) {
		SourceSystem ss = (SourceSystem) this.getById(SourceSystem.class, ssId);
		return ss;
	}

	@Override
	public long saveSourceSystem(SourceSystem sourceSystem) {
		long ssId = (long) this.save(sourceSystem);
		return ssId;
	}

	@Override
	public List<SourceSystem> getSourceSystemList(long projectId) {

		Criteria cr = this.getSession().createCriteria(SourceSystem.class);
		cr.add(Restrictions.eq("projectId", projectId));

		List<SourceSystem> list = cr.list();
		
		return list;
	}

	@Override
	public DBSource getDBSource(long id) {
		DBSource dbs = (DBSource) this.getById(DBSource.class, id);
		return dbs;
	}

	@Override
	public FileSource getFileSource(long id) {
		FileSource fs = (FileSource) this.getById(FileSource.class, id);
		return fs;
	}

	@Override
	public long saveDBSource(DBSource dbs) {
		long id = (long) this.save(dbs);
		return id;
	}

	@Override
	public long saveFileSource(FileSource fs) {
		long id = (long) this.save(fs);
		return id;
	}

	@Override
	public Serializable save(Object entity) {
		return super.save(entity);
	}

}
