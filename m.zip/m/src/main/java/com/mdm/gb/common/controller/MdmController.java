package com.mdm.gb.common.controller;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mdm.gb.common.MessageUtils;
import com.mdm.gb.common.dto.DBSourceSystem;
import com.mdm.gb.common.dto.FileSourceSystem;
import com.mdm.gb.common.dto.SourceSystemDto;
import com.mdm.gb.common.service.MdmService;

@Controller
@RequestMapping("/metadata")
public class MdmController {
	static final Logger logger = Logger.getLogger(MdmController.class);
	
	@Resource(name = "mdmService")
	MdmService mdmService;

	@RequestMapping(value = "/sourcesystem/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getSourceSystems(@PathVariable long projectId) {
		logger.debug("Entered getSourceSystems");
		String resp = this.mdmService.getSourceSystems(projectId);
		logger.debug("Response: " + resp);
		logger.debug("Exiting getSourceSystems");
		return resp;
	}

	@RequestMapping(value = "/ssdetail/{ssId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getSourceSystemDetail(@PathVariable long ssId) {
		logger.debug("Entered getSourceSystems");
		String resp = this.mdmService.getSourceSystemDetail(ssId);
		logger.debug("Response: " + resp);
		logger.debug("Exiting getSourceSystems");
		return resp;
	}

	@RequestMapping(value = "/savess", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String saveSourceSystems(@RequestBody SourceSystemDto data) {
		logger.debug("Entered saveSourceSystems");
		try {
			long ssId = this.mdmService.saveSourceSystem(data);
			return this.mdmService.getSourceSystemDetail(ssId);
		} catch (Exception e) {
		}

		logger.debug("Exiting saveSourceSystems");
		return MessageUtils.getResponseMessage("SUCCESS", "Error saving Source System");
	}

	@RequestMapping(value = "/savedbsources", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String saveDBSources(@RequestBody DBSourceSystem data) {
		logger.debug("Entered saveDBSources");
		logger.debug("DATA>>>>" + data);
		try {
			long ssId = this.mdmService.saveDBSources(data);
			logger.debug("----------------------------Saved DB Sources--------------------- ssId: " + ssId);
			return this.mdmService.getSourceSystemDetail(ssId);

		} catch (Exception e) {
		}

		logger.debug("Exiting saveDBSources");
		return MessageUtils.getResponseMessage("ERROR", "Error saving DB Source!!");
	}

	@RequestMapping(value = "/savefilesources", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String saveFileSources(@RequestBody FileSourceSystem data) {
		logger.debug("Entered saveFileSources");
		logger.debug("DATA>>>>" + data);
		try {
			long ssId = this.mdmService.saveFileSources(data);
			logger.debug("----------------------------Saved File Sources--------------------- ssId: " + ssId);
			return this.mdmService.getSourceSystemDetail(ssId);

		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Exiting saveFileSources");
		return MessageUtils.getResponseMessage("ERROR", "Error saving File Sources!!");
	}	
	
	
	@RequestMapping(value = "/gettables", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getAllTables(@RequestBody String reqJson) {
		logger.debug("Entered getSourceSystems");
		String resp = this.mdmService.getTables(reqJson);
		logger.debug("Request: " + reqJson);
		logger.debug("Response:" + resp);
		logger.debug("Exiting getSourceSystems");
		return resp;
	}

	@RequestMapping(value = "/gettablestruct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getTablesStructure(@RequestBody String reqJson) {
		logger.debug("Entered getTablesStructure");
		String resp = this.mdmService.getTableStructure(reqJson);
		logger.debug("Request: " + reqJson);
		logger.debug("Response: " + resp);
		logger.debug("Exiting getTablesStructure");
		return resp;
	}

	@RequestMapping(value = "/getalltablestruct", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String getAllTablesStructure(@RequestBody String reqJson) {
		logger.debug("Entered getAllTablesStructure");
		String resp = this.mdmService.getAllTableStructure(reqJson);
		logger.debug("Request: " + reqJson);
		logger.debug("Response: " + resp);
		logger.debug("Exiting getAllTablesStructure");
		return resp;
	}

	@RequestMapping(value = "/importfile", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String importFileStructure(@RequestBody String reqJson) {
		logger.debug("Entered importFileStructure");
		JSONObject req = new JSONObject(reqJson);

		String resp = this.mdmService.importFileStruct(req.getLong("sourceSystem"), req.getString("excelPath"));

		logger.debug("Request: " + reqJson);
		logger.debug("Response: " + resp);
		logger.debug("Exiting importFileStructure");
		return resp;
	}

}