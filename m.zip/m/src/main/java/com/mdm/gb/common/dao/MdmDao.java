package com.mdm.gb.common.dao;

import java.util.List;

import com.mdm.gb.common.entity.DBSource;
import com.mdm.gb.common.entity.FileSource;
import com.mdm.gb.common.entity.SourceSystem;

public interface MdmDao {
	List<SourceSystem> getSourceSystemList(long projectId);

	SourceSystem getSourceSystem(long ssId);

	long saveSourceSystem(SourceSystem sourceSystem);

	long saveFileSource(FileSource fs);

	long saveDBSource(DBSource dbs);

	FileSource getFileSource(long id);

	DBSource getDBSource(long id);

}
