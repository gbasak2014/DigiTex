package com.mdm.gb.common.dto;

public class TableCat {
	String type;
	String name;

	public TableCat() {
	}
	
	public TableCat(String name, String type) {
		this.name = name;
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	/*@Override
	public String toString() {
		return "{name:" + this.name + ", type:" + this.type + "}";
	}*/
}
