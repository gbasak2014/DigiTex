package com.mdm.gb.common.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

@Entity
@Table(name = "COLUMN_DETAIL")
public class ColumnDetail {
	@Id
	@Column(name = "COLUMN_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;

	String name;
	String dataType;
	Boolean sensitiveFlag;
	Integer pos;
	Integer length;

	@ManyToOne
	@JoinColumn(name = "FILE_ID")
	FileSource fileSource;

	@ManyToOne
	@JoinColumn(name = "DB_ID")
	DBSource dbSource;

	@Version
	@Column(name = "VERSION")
	long version;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Boolean getSensitiveFlag() {
		return sensitiveFlag;
	}

	public void setSensitiveFlag(Boolean sensitiveFlag) {
		this.sensitiveFlag = sensitiveFlag;
	}

	public Integer getPos() {
		return pos;
	}

	public void setPos(Integer pos) {
		this.pos = pos;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	public FileSource getFileSource() {
		return fileSource;
	}

	public void setFileSource(FileSource fileSource) {
		this.fileSource = fileSource;
	}

	public DBSource getDbSource() {
		return dbSource;
	}

	public void setDbSource(DBSource dbSource) {
		this.dbSource = dbSource;
	}

	public Long getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "{" + this.pos + ", " + this.name + "}";
	}
}
