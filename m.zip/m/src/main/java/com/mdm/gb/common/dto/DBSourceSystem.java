package com.mdm.gb.common.dto;

import java.util.List;

public class DBSourceSystem {
	long sourceSystem;
	List<DBSourceDto> tables;

	public long getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(long sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public List<DBSourceDto> getTables() {
		return tables;
	}

	public void setTables(List<DBSourceDto> tables) {
		this.tables = tables;
	}

	@Override
	public String toString() {
		return "{" + this.sourceSystem + ", " + this.tables + "}";
	}
}
