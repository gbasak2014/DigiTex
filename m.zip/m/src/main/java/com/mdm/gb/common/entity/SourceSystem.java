package com.mdm.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

@Entity
@Table(name = "META_DATA", uniqueConstraints = @UniqueConstraint(columnNames = { "technicalName", "PROJECT_ID" }))
public class SourceSystem {
	@Id
	@Column(name = "SOURCE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;

	String technicalName;
	String businessName;
	String description;
	String purpose;

	String owner;
	String approver;

	String status;

	@Version
	@Column(name = "VERSION")
	long version;

	@Column(name = "PROJECT_ID")
	long projectId;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "sourceSystem", orphanRemoval = true)
	Set<FileSource> fileSources;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "sourceSystem", orphanRemoval = true)
	Set<DBSource> dbSources;

	public String getTechnicalName() {
		return technicalName;
	}

	public void setTechnicalName(String technicalName) {
		this.technicalName = technicalName;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public long getProjectId() {
		return projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	public Set<FileSource> getFileSources() {
		return fileSources;
	}

	public void setFileSources(Set<FileSource> fileSources) {
		this.fileSources = fileSources;
	}

	public Set<DBSource> getDbSources() {
		return dbSources;
	}

	public void setDbSources(Set<DBSource> dbSources) {
		this.dbSources = dbSources;
	}

	public Long getId() {
		return id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}
}
