package com.mdm.gb.common;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

import com.mdm.gb.common.dto.ColumnDto;
import com.mdm.gb.common.dto.FileSourceDto;
import com.mdm.gb.common.dto.SourceSystemDto;
import com.mdm.gb.common.entity.ColumnDetail;
import com.mdm.gb.common.entity.DBSource;
import com.mdm.gb.common.entity.FileSource;
import com.mdm.gb.common.entity.SourceSystem;

public class JSONUtils {
	public static JSONArray getJSONArray(Collection<SourceSystemDto> list) {
		JSONArray arr = new JSONArray();

		for (SourceSystemDto ss : list) {
			arr.put(getJSONObject(ss));
		}

		return arr;
	}

	public static JSONObject getJSONObject(SourceSystemDto ss) {
		JSONObject obj = new JSONObject();
		obj.put("id", ss.getId());
		obj.put("technicalName", ss.getTechnicalName());
		obj.put("businessName", ss.getBusinessName());
		obj.put("description", ss.getDescription());
		obj.put("purpose", ss.getPurpose());
		obj.put("owner", ss.getOwner());
		obj.put("status", ss.getStatus());
		obj.put("approver", ss.getApprover());

		return obj;
	}
	
	public static JSONObject getJSONObject(SourceSystem ss) {
		JSONObject obj = new JSONObject();
		obj.put("id", ss.getId());
		obj.put("technicalName", ss.getTechnicalName());
		obj.put("businessName", ss.getBusinessName());
		obj.put("description", ss.getDescription());
		obj.put("purpose", ss.getPurpose());
		obj.put("owner", ss.getOwner());
		obj.put("status", ss.getStatus());
		obj.put("approver", ss.getApprover());

		return obj;
	}

	public static JSONObject getColumnJson(ColumnDetail cd) {
		JSONObject obj = new JSONObject();
		obj.put("id", cd.getId());
		obj.put("name", cd.getName());
		obj.put("dataType", cd.getDataType());
		obj.put("length", cd.getLength());
		obj.put("pos", cd.getPos());
		obj.put("sensitiveFlag", cd.getSensitiveFlag());

		return obj;
	}

	public static JSONObject getFileSourceJson(FileSource fSrc) {
		JSONObject obj = new JSONObject();
		obj.put("id", fSrc.getId());
		obj.put("version", fSrc.getVersion());
		obj.put("delimiter", fSrc.getDelimiter());
		obj.put("description", fSrc.getDescription());
		obj.put("fileFormat", fSrc.getFormat());
		obj.put("name", fSrc.getName());
		obj.put("path", fSrc.getPath());
		obj.put("rootElement", fSrc.getRootElement());
		obj.put("status", fSrc.getStatus());

		JSONArray arr = new JSONArray();
		int i = 0;
		for (ColumnDetail cd : fSrc.getColumnDetail()) {
			arr.put(i, getColumnJson(cd));
			i++;
		}
		obj.put("columns", arr);

		return obj;
	}

	public static JSONObject getDBSourceJson(DBSource dbSrc, long ssId) {
		JSONObject obj = new JSONObject();
		obj.put("id", dbSrc.getId());
		obj.put("version", dbSrc.getVersion());
		obj.put("description", dbSrc.getDescription());
		obj.put("host", dbSrc.getHost());
		obj.put("db", dbSrc.getDb());
		obj.put("tableName", dbSrc.getTableName());
		obj.put("pwd", dbSrc.getPassword());
		obj.put("dbType", dbSrc.getType());
		obj.put("status", dbSrc.getStatus());
		obj.put("user", dbSrc.getUser());
		obj.put("sourceSystem", ssId);
		
		JSONArray arr = new JSONArray();
		int i = 0;
		for (ColumnDetail cd : dbSrc.getColumnDetail()) {
			arr.put(i, getColumnJson(cd));
			i++;
		}
		obj.put("columns", arr);

		return obj;
	}

	public static JSONObject getSourceSystemDetail(SourceSystem sourceSystem) {
		JSONObject ssObj = getJSONObject(sourceSystem);

		Collection<FileSource> lstFile = sourceSystem.getFileSources();
		Collection<DBSource> lstDb = sourceSystem.getDbSources();

		JSONArray arrFile = new JSONArray();
		int i = 0;
		for (FileSource fs : lstFile) {
			arrFile.put(i, getFileSourceJson(fs));
			i++;
		}

		JSONArray arrDb = new JSONArray();
		i = 0;
		for (DBSource fs : lstDb) {
			arrDb.put(i, getDBSourceJson(fs, sourceSystem.getId()));
			i++;
		}

		ssObj.put("fileSources", arrFile);
		ssObj.put("dbSources", arrDb);

		return ssObj;
	}

	public static JSONObject getSrcJSON(Map<String, List<ColumnDto>> tblCols, String host, String db, String user, String pwd, String dbType) {
		JSONObject ssObj = new JSONObject();
		JSONArray arrTbl = new JSONArray();
		ssObj.put("dbSources", arrTbl);

		for (String tt : tblCols.keySet()) {
			JSONObject objTbl = new JSONObject();
			arrTbl.put(objTbl);
			objTbl.put("id", -1);
			objTbl.put("version", -1);
			objTbl.put("db", db);
			objTbl.put("description", "");
			objTbl.put("host", host);
			objTbl.put("pwd", pwd);
			objTbl.put("sourceSystem", -1);
			objTbl.put("status", "NEW");
			objTbl.put("dbType", dbType);
			objTbl.put("user", user);
			objTbl.put("tableName", tt);

			JSONArray arr = new JSONArray();
			objTbl.put("columns", arr);
			for (ColumnDto cd : tblCols.get(tt)) {
				JSONObject col = new JSONObject();
				col.put("id", -1);
				col.put("name", cd.getName());
				col.put("dataType", cd.getDataType());
				col.put("length", cd.getLength());
				col.put("pos", cd.getPos());
				col.put("sensitiveFlag", cd.getSensitiveFlag());
				arr.put(col);
			}
		}

		return ssObj;
	}

	public static JSONObject getFileJSON(List<FileSourceDto> list)
	{
		JSONObject ssObj = new JSONObject();
		JSONArray arrTbl = new JSONArray(list);
		ssObj.put("fileSources", arrTbl);

		return ssObj;
	}
	
	public static JSONObject getDbJSON(Set<DBSource> dbSet, long ssId) {
		JSONObject ssObj = new JSONObject();
		JSONArray arrTbl = new JSONArray();
		ssObj.put("dbSources", arrTbl);
		
		for (DBSource db : dbSet) {
			JSONObject objTbl = new JSONObject();
			arrTbl.put(objTbl);
			
			objTbl.put("id", db.getId());
			objTbl.put("version", db.getVersion());
			objTbl.put("db", db.getDb());
			objTbl.put("description", db.getDescription());
			objTbl.put("host", db.getHost());
			objTbl.put("pwd", db.getPassword());
			objTbl.put("sourceSystem", ssId);
			objTbl.put("status", db.getStatus());
			objTbl.put("dbType", db.getType());
			objTbl.put("user", db.getUser());
			objTbl.put("tableName", db.getTableName());
			
			JSONArray arr = new JSONArray();
			objTbl.put("columns", arr);
			for (ColumnDetail cd : db.getColumnDetail()) {
				JSONObject col = new JSONObject();
				col.put("id", cd.getId());
				col.put("name", cd.getName());
				col.put("dataType", cd.getDataType());
				col.put("length", cd.getLength());
				col.put("pos", cd.getPos());
				col.put("sensitiveFlag", cd.getSensitiveFlag());
				arr.put(col);
			}
		}

		return ssObj;
	}
}
