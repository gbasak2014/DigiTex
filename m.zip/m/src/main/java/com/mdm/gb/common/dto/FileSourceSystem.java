package com.mdm.gb.common.dto;

import java.util.List;

public class FileSourceSystem {
	long sourceSystem;
	List<FileSourceDto> files;

	public long getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(long sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public List<FileSourceDto> getFiles() {
		return files;
	}

	public void setFiles(List<FileSourceDto> files) {
		this.files = files;
	}

	@Override
	public String toString() {
		return "{" + this.sourceSystem + ", " + this.files + "}";
	}
}
