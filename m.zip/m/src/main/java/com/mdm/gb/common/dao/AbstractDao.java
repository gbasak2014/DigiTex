package com.mdm.gb.common.dao;

import java.io.Serializable;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class AbstractDao {
	@Autowired
	SessionFactory sessionFactory;

	static final Logger logger = Logger.getLogger(AbstractDao.class);
	
	public Session getSession() {
		
		logger.debug("Entered getSession");
		Session session;
		try {
			logger.debug("Get existing session");
			session = sessionFactory.getCurrentSession();
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("Open new session");
			session = sessionFactory.openSession();
		}
		logger.debug("Exiting getSession");

		return session;
	}

	public void persist(Object entity) {
		this.getSession().persist(entity);
	}

	public Serializable save(Object entity) {
		return this.getSession().save(entity);
	}

	public void update(Object entity) {
		this.getSession().saveOrUpdate(entity);
	}

	public void delete(Object entity) {
		this.getSession().delete(entity);
	}

	public Object getById(Class clazz, Serializable id) {
		return this.getSession().get(clazz, id);
	}

	public List getAll(Class clazz) {
		return this.getSession().createCriteria(clazz).list();
	}
}
