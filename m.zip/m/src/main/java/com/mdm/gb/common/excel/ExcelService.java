package com.mdm.gb.common.excel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.mdm.gb.common.dto.ColumnDto;
import com.mdm.gb.common.dto.FileSourceDto;

public class ExcelService {
	String getString(Cell cell) {
		return cell != null ? cell.getStringCellValue() : "";
	}

	int getInt(Cell cell) {
		return cell != null ? (int) cell.getNumericCellValue() : -1;
	}

	boolean getBoolean(Cell cell) {
		return cell != null ? cell.getBooleanCellValue() : false;
	}

	ColumnDto getColumns(FileSourceDto fileSource, List<ColumnDto> cols, Row row) {
		// File Name ID Name Data Type length pos sensitive
		ColumnDto cd = new ColumnDto();
		String name = getString(row.getCell(2));
		String dataType = getString(row.getCell(3));
		int len = getInt(row.getCell(4));
		int pos = getInt(row.getCell(5));
		boolean sensitive = getBoolean(row.getCell(6));

		cd.setDataType(dataType);
		cd.setLength(len);
		cd.setName(name);
		cd.setPos(pos);
		cd.setSensitiveFlag(sensitive);

		return cd;
	}

	void populateColumns(XSSFSheet sheet, List<FileSourceDto> list) {

		Map<String, FileSourceDto> map = new HashMap<String, FileSourceDto>();
		for (FileSourceDto fs : list) {
			map.put(fs.getName(), fs);
		}

		int lastRow = sheet.getLastRowNum();
		for (int r = 5; r <= lastRow; r++) {
			Row row = sheet.getRow(r);
			String fileName = row != null ? getString(row.getCell(0)) : null;
			if (fileName != null && fileName.trim().length() > 0) {

				if (map.containsKey(fileName)) {
					FileSourceDto fs = map.get(fileName);
					List<ColumnDto> cols = fs.getColumns();
					if (cols == null) {
						cols = new ArrayList<ColumnDto>();
						fs.setColumns(cols);
					}

					cols.add(getColumns(fs, cols, row));
				}

			}
		}
	}

	public List<FileSourceDto> getFileSourceFromExcel(long ssId, String path) throws Exception {
		List<FileSourceDto> list = new ArrayList<FileSourceDto>();
		XSSFWorkbook book = new XSSFWorkbook(path);
		XSSFSheet sheet = book.getSheet("file");

		int lastRow = sheet.getLastRowNum();
		for (int r = 5; r <= lastRow; r++) {
			Row row = sheet.getRow(r);

			String name = getString(row.getCell(1));
			String description = getString(row.getCell(2));
			String filePath = getString(row.getCell(3));
			String format = getString(row.getCell(4));
			String delimiter = getString(row.getCell(5));
			String rootElement = getString(row.getCell(6));
			String status = getString(row.getCell(7));

			FileSourceDto fs = new FileSourceDto();
			fs.setName(name);
			fs.setDescription(description);
			fs.setPath(filePath);
			fs.setDelimiter(delimiter);
			fs.setRootElement(rootElement);
			fs.setStatus(status);
			fs.setFileFormat(format);
			fs.setSourceSystem(ssId);

			list.add(fs);
		}

		sheet = book.getSheet("columns");
		populateColumns(sheet, list);
		book.close();

		return list;
	}

	public static void main(String[] args) throws Exception {
		String str = "<pre>{12345}</pre>";
		System.out.println(str.replace("<pre>{", "{").replace("}</pre>", "}"));
		
	}
}
