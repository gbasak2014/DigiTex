package com.mdm.gb.common;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.Driver;

import oracle.jdbc.driver.OracleDriver;

public class DBConnectionFactory {
	public static Connection getOracleConnection(String host, String db, String user, String pwd) throws Exception {
		String driver = OracleDriver.class.getName();
		String url = "jdbc:oracle:thin://" + host + ":1521:" + db;
		Class.forName(driver);
		return DriverManager.getConnection(url, user, pwd);
	}

	public static Connection getMysqlConnection(String host, String db, String user, String pwd) throws Exception {
		String driver = Driver.class.getName();
		String url = "jdbc:mysql://" + host + "/" + db;
		Class.forName(driver);
		return DriverManager.getConnection(url, user, pwd);
	}
}
