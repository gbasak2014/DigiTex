package com.mdm.gb.common.dto;

import java.util.List;

public class FileSourceDto {

	long id;
	String name;
	String description;
	String path;
	String delimiter;
	String rootElement;
	String status;
	long version;
	String fileFormat;
	long sourceSystem;
	List<ColumnDto> columns;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getRootElement() {
		return rootElement;
	}

	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}

	public long getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public long getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(long sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<ColumnDto> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnDto> columns) {
		this.columns = columns;
	}

	@Override
	public String toString() {
		return "{" + this.id + ", " + this.name + ", " + this.sourceSystem + ", " + this.columns + "}";
	}
}
