package com.mdm.gb.common.service;

import java.util.List;

import com.mdm.gb.common.dto.DBSourceDto;
import com.mdm.gb.common.dto.DBSourceSystem;
import com.mdm.gb.common.dto.FileSourceDto;
import com.mdm.gb.common.dto.FileSourceSystem;
import com.mdm.gb.common.dto.SourceSystemDto;

public interface MdmService {
	String getTables(String json);

	String getTableStructure(String json);

	String addFileSources(List<FileSourceDto> lstFileSource);

	long saveDBSources(DBSourceSystem dbSourceSystem);

	long saveFileSources(FileSourceSystem fileSourceSystem);
	
	long saveSourceSystem(SourceSystemDto sourceSystem);

	long saveFileSource(FileSourceDto fileSource);

	long saveDBSource(DBSourceDto dbSource);

	String getSourceSystems(long projectId);

	String getSourceSystemDetail(long ssId);

	String getAllTableStructure(String json);

	String getTableStruct(long ssId);

	String importFileStruct(long ssId, String excelPath);
	
}
