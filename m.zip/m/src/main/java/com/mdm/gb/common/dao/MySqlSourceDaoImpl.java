package com.mdm.gb.common.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mdm.gb.common.DBConnectionFactory;
import com.mdm.gb.common.MessageUtils;
import com.mdm.gb.common.dto.ColumnDto;
import com.mdm.gb.common.dto.TableCat;

/**
 * DAO implementation to extract tables meta data of MySql data sources
 * 
 * @author Gouranga
 *
 */
public class MySqlSourceDaoImpl implements SourceDao {
	@Override
	public List<TableCat> listTables(String host, String db, String user, String pwd) throws Exception {
		Connection conn = DBConnectionFactory.getMysqlConnection(host, db, user, pwd);
		ResultSet rs = conn.getMetaData().getTables(null, null, "%", new String[] { "TABLE", "VIEW" });
		List<TableCat> list = new ArrayList<TableCat>();

		while (rs.next()) {
			list.add(new TableCat(rs.getString(3), rs.getString(4)));
		}
		conn.close();

		return list;
	}

	@Override
	public List<ColumnDto> getTableStructure(String host, String db, String table, String user, String pwd) throws Exception {
		Connection conn = DBConnectionFactory.getMysqlConnection(host, db, user, pwd);
		ResultSet rs = conn.getMetaData().getColumns(null, null, table, "%");
		List<ColumnDto> list = new ArrayList<ColumnDto>();

		/*
		 * 3.TABLE_NAME String => table name 4.COLUMN_NAME String => column name
		 * 5.DATA_TYPE int => SQL type from java.sql.Types 7.COLUMN_SIZE int =>
		 * column size. 17.ORDINAL_POSITION int => index of column in table
		 * (starting at 1)
		 */
		while (rs.next()) {
			list.add(new ColumnDto(rs.getString(4), rs.getString(6), rs.getInt(7), rs.getInt(17)));
		}
		conn.close();
		return list;
	}

	@Override
	public Map<String, List<ColumnDto>> getAlltableStructure(String host, String db, String user, String pwd) throws Exception {

		Map<String, List<ColumnDto>> map1 = new HashMap<String, List<ColumnDto>>();

		Connection conn = DBConnectionFactory.getMysqlConnection(host, db, user, pwd);

		ResultSet rs = conn.getMetaData().getColumns(null, null, "%", "%");

		/*
		 * 3.TABLE_NAME String => table name 4.COLUMN_NAME String => column name
		 * 5.DATA_TYPE int => SQL type from java.sql.Types 7.COLUMN_SIZE int =>
		 * column size. 17.ORDINAL_POSITION int => index of column in table
		 * (starting at 1)
		 */
		while (rs.next()) {
			String tableName = rs.getString(3);
			List<ColumnDto> cols;
			if (map1.containsKey(tableName)) {
				cols = map1.get(tableName);
			} else {
				cols = new ArrayList<ColumnDto>();
				map1.put(tableName, cols);
			}

			cols.add(new ColumnDto(rs.getString(4), rs.getString(6), rs.getInt(7), rs.getInt(17)));
		}
		conn.close();
		
		return map1;

	}

	public static void main(String[] args) throws Exception {
		System.out.println("aaaa");
		MySqlSourceDaoImpl aa = new MySqlSourceDaoImpl();

		String ss = MessageUtils.getResponseMessage("SUCCESS", aa.getAlltableStructure("localhost", "mdm_db", "mdm", "mdm"));
		System.out.println("------------------------------");
		System.out.println(ss);
	}
}
