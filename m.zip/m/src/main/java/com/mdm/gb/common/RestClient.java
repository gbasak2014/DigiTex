package com.mdm.gb.common;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;

public class RestClient {

	static HttpURLConnection getConnection(String cnnUrl, String method) throws Exception {
		URL url = new URL(cnnUrl);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setDoOutput(true);

		conn.setRequestMethod(method);

		conn.setRequestProperty("Content-Type", "application/json");
		return conn;
	}

	public static void main(String[] args) {
		System.out.println("Started...................");
		try {
			String url = "http://localhost:8080/mdm/metadata/getalltablestruct";
			HttpURLConnection cnn = getConnection(url, "POST");

			JSONObject json = new JSONObject();
			json.put("dbType", "MYSQL");
			json.put("db", "mdm_db");
			json.put("user", "mdm");
			json.put("pwd", "mdm");
			json.put("host", "localhost");
			json.put("table", "column_detail");
			
			OutputStream os = cnn.getOutputStream();
			os.write(json.toString().getBytes());
			os.flush();

			BufferedReader br = new BufferedReader(new InputStreamReader(cnn.getInputStream()));
			String line = br.readLine();
			System.out.println(line);
			System.out.println("Done...........................");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main1(String[] args) {

		JSONParser p = new JSONParser();
		Gson g = new Gson();
	}
}
