package com.mdm.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

@Entity
@Table(name = "SOURCE_DB", uniqueConstraints = @UniqueConstraint(columnNames = { "tableName", "SS_ID" }))
public class DBSource {
	@Id
	@Column(name = "DB_SRC_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;

	String tableName;
	String description;
	String host;
	String db;
	String user;
	String password;
	String type;
	String status;
	
	@Version
	@Column(name = "VERSION")
	long version;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "dbSource", orphanRemoval = true)
	Set<ColumnDetail> columnDetail;

	@ManyToOne
	@JoinColumn(name = "SS_ID")
	SourceSystem sourceSystem;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public SourceSystem getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public Long getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<ColumnDetail> getColumnDetail() {
		return columnDetail;
	}

	public void setColumnDetail(Set<ColumnDetail> columnDetail) {
		this.columnDetail = columnDetail;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getDb() {
		return db;
	}

	public void setDb(String db) {
		this.db = db;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public void setId(Long id) {
		this.id = id;
	}

}
