package com.mdm.gb.common.dto;

import java.util.List;

public class DBSourceDto {

	long id;//

	String tableName;//
	String description; //
	String host; //
	String user;//
	String password;//
	String type;//
	String status;//
	String db;//
	long sourceSystem;
	long version; //
	List<ColumnDto> columns;//

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(long sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getDb() {
		return db;
	}

	public void setDb(String db) {
		this.db = db;
	}

	public List<ColumnDto> getColumns() {
		return columns;
	}

	public void setColumns(List<ColumnDto> columns) {
		this.columns = columns;
	}

	@Override
	public String toString() {
		return "{" + this.id + "," + this.tableName + ", " + this.columns + "}";
	}
}
