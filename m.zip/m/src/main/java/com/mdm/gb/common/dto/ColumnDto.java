package com.mdm.gb.common.dto;

public class ColumnDto {
	long id;
	String name;
	String dataType;
	int pos;
	boolean sensitiveFlag;
	int length;

	public ColumnDto() {
	}

	public ColumnDto(String name, String dataType, int length, int pos) {
		this.name = name;
		this.dataType = dataType;
		this.pos = pos - 1;
		this.length = length;
		this.sensitiveFlag = false;
		this.id = -1;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Boolean getSensitiveFlag() {
		return sensitiveFlag;
	}

	public void setSensitiveFlag(Boolean sensitiveFlag) {
		this.sensitiveFlag = sensitiveFlag;
	}

	public Integer getLength() {
		return length;
	}

	public void setLength(Integer length) {
		this.length = length;
	}

	@Override
	public String toString() {
		return "{" + this.id + ", " + this.pos + ", " + this.name + ", " + this.dataType + ", " + this.length + "}";
	}
}
