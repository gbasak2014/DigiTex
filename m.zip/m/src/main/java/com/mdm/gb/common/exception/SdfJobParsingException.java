package com.mdm.gb.common.exception;

public class SdfJobParsingException extends SdfException {
	private static final long serialVersionUID = -4801036067921507307L;

	public SdfJobParsingException(String message) {
		super(message);
	}

}
