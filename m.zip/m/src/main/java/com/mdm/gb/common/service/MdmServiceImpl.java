package com.mdm.gb.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.mdm.gb.common.JSONUtils;
import com.mdm.gb.common.MessageUtils;
import com.mdm.gb.common.ServiceUtils;
import com.mdm.gb.common.SourceDaoFactory;
import com.mdm.gb.common.dao.MdmDao;
import com.mdm.gb.common.dao.SourceDao;
import com.mdm.gb.common.dto.ColumnDto;
import com.mdm.gb.common.dto.DBSourceDto;
import com.mdm.gb.common.dto.DBSourceSystem;
import com.mdm.gb.common.dto.FileSourceDto;
import com.mdm.gb.common.dto.FileSourceSystem;
import com.mdm.gb.common.dto.SourceSystemDto;
import com.mdm.gb.common.dto.TableCat;
import com.mdm.gb.common.entity.ColumnDetail;
import com.mdm.gb.common.entity.DBSource;
import com.mdm.gb.common.entity.FileSource;
import com.mdm.gb.common.entity.SourceSystem;
import com.mdm.gb.common.excel.ExcelService;

@Service(value = "mdmService")
public class MdmServiceImpl implements MdmService {
	static final Logger logger = Logger.getLogger(MdmServiceImpl.class);

	@Autowired
	@Qualifier("mdmDao")
	MdmDao mdmDao;

	@Override
	public String getTables(String json) {
		logger.debug("Entered getTables");
		JSONObject obj = new JSONObject(json);
		String dbType = obj.getString("dbType");

		SourceDao dao = SourceDaoFactory.getDaoImpl(dbType);
		String resp = null;
		try {
			String host = obj.getString("host");
			String db = obj.getString("db");
			String user = obj.getString("user");
			String pwd = obj.getString("pwd");

			List<TableCat> list = dao.listTables(host, db, user, pwd);
			resp = MessageUtils.getResponseMessage("SUCCESS", list);

		} catch (Exception e) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting table name from source");
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting table name from source");
		}

		logger.debug("Exiting getTables");
		return resp;
	}

	@Override
	public String getTableStructure(String json) {
		logger.debug("Entered getTableStructure");
		JSONObject obj = new JSONObject(json);
		String dbType = obj.getString("dbType");
		SourceDao dao = SourceDaoFactory.getDaoImpl(dbType);
		String resp = null;
		try {
			String host = obj.getString("host");
			String db = obj.getString("db");
			String table = obj.getString("table");
			String user = obj.getString("user");
			String pwd = obj.getString("pwd");
			List<ColumnDto> cols = dao.getTableStructure(host, db, table, user, pwd);
			resp = MessageUtils.getResponseMessage("SUCCESS", cols);

		} catch (Exception e) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting table structure from source");
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting table structure from source");
		}

		logger.debug("Exiting getTableStructure");
		return resp;
	}

	@Override
	public String getAllTableStructure(String json) {
		logger.debug("Entered getAllTableStructure");
		JSONObject obj = new JSONObject(json);
		String dbType = obj.getString("dbType");

		SourceDao dao = SourceDaoFactory.getDaoImpl(dbType);
		String resp = null;
		try {
			String host = obj.getString("host");
			String db = obj.getString("db");
			String user = obj.getString("user");
			String pwd = obj.getString("pwd");
			Map<String, List<ColumnDto>> tblCols = dao.getAlltableStructure(host, db, user, pwd);
			resp = MessageUtils.getResponseMessage("SUCCESS", JSONUtils.getSrcJSON(tblCols, host, db, user, pwd, dbType));

		} catch (Exception e) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting all table structure from source");
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting all table structure from source");
		}

		logger.debug("Exiting getAllTableStructure");
		return resp;
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public String getSourceSystems(long projectId) {
		logger.debug("Entered getSourceSystems");
		String resp = null;
		try {
			List<SourceSystem> list = this.mdmDao.getSourceSystemList(projectId);
			Map<Long, SourceSystemDto> map = new HashMap<Long, SourceSystemDto>();
			for (SourceSystem ss : list) {
				if (!map.containsKey(ss.getId())) {
					SourceSystemDto dto = new SourceSystemDto();
					dto.setApprover(ss.getApprover());
					dto.setBusinessName(ss.getBusinessName());
					dto.setDescription(ss.getDescription());
					dto.setId(ss.getId());
					dto.setOwner(ss.getOwner());
					dto.setProjectId(ss.getProjectId());
					dto.setPurpose(ss.getPurpose());
					dto.setStatus(ss.getStatus());
					dto.setTechnicalName(ss.getTechnicalName());
					dto.setVersion(ss.getVersion());
					map.put(ss.getId(), dto);
				}
			}

			JSONArray arr = JSONUtils.getJSONArray(map.values());
			if (arr.length() > 0) {
				resp = MessageUtils.getResponseMessage("SUCCESS", arr);
			} else {
				resp = MessageUtils.getResponseMessage("ERROR", "No Source System for thr project");
			}
		} catch (Exception e) {
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting source system!!");
		}

		logger.debug("Exiting getSourceSystems");
		return resp;
	}

	@Override
	public String getSourceSystemDetail(long ssId) {
		logger.debug("Entered getSourceSystemDetail");
		String resp = null;
		try {
			SourceSystem ss = this.mdmDao.getSourceSystem(ssId);
			JSONObject jsonSs = JSONUtils.getSourceSystemDetail(ss);
			logger.debug("Response:" + jsonSs);

			resp = MessageUtils.getResponseMessage("SUCCESS", jsonSs);

		} catch (Exception e) {
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error getting source system!!");
		}

		logger.debug("Exiting getSourceSystemDetail");

		return resp;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveDBSource(DBSourceDto dto) {
		logger.debug("Entered saveDBSource");
		DBSource dbSource = null;

		long id = -1;
		if (dto.getId() <= 0) {
			dbSource = new DBSource();
			SourceSystem ss = this.mdmDao.getSourceSystem(dto.getSourceSystem());
			dbSource.setSourceSystem(ss);
			dbSource.setColumnDetail(ServiceUtils.getColumnList(dto.getColumns(), dbSource));

		} else {
			dbSource = this.mdmDao.getDBSource(dto.getId());
			Set<ColumnDetail> cols = dbSource.getColumnDetail();
			Map<String, ColumnDto> map = new HashMap<String, ColumnDto>();
			for (ColumnDto cd : dto.getColumns()) {
				map.put(cd.getName(), cd);
			}

			for (ColumnDetail col : cols) {
				ColumnDto cd = map.remove(col.getName());
				if (cd != null) {
					col.setDataType(cd.getDataType());
					col.setLength(cd.getLength());
					col.setPos(cd.getPos());
					col.setSensitiveFlag(cd.getSensitiveFlag());
				} else {
					col.setDbSource(null);
					col.setFileSource(null);
				}
			}

			for (Entry<String, ColumnDto> e : map.entrySet()) {
				ColumnDto cc = e.getValue();
				ColumnDetail cd = new ColumnDetail();
				cd.setDataType(cc.getDataType());
				cd.setDbSource(dbSource);
				cd.setLength(cc.getLength());
				cd.setName(cc.getName());
				cd.setPos(cc.getPos());
				cd.setSensitiveFlag(cc.getSensitiveFlag());
				cols.add(cd);
			}
		}

		dbSource.setDescription(dto.getDescription());
		dbSource.setHost(dto.getHost());
		dbSource.setTableName(dto.getTableName());
		dbSource.setPassword(dto.getPassword());
		dbSource.setStatus(dto.getStatus());
		dbSource.setType(dto.getType());
		dbSource.setUser(dto.getUser());
		dbSource.setVersion(dto.getVersion());

		if (dto.getId() <= 0) {
			id = this.mdmDao.saveDBSource(dbSource);
		} else {
			id = dto.getId();
		}

		logger.debug("Exiting saveDBSource");
		return id;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveFileSource(FileSourceDto dto) {
		logger.debug("Entered saveFileSource");
		FileSource fileSource = null;
		long id = -1;

		if (dto.getId() <= 0) {
			fileSource = new FileSource();
			SourceSystem ss = this.mdmDao.getSourceSystem(dto.getSourceSystem());
			fileSource.setSourceSystem(ss);
			fileSource.setColumnDetail(ServiceUtils.getColumnList(dto.getColumns(), fileSource));
		} else {
			fileSource = this.mdmDao.getFileSource(dto.getId());
			Set<ColumnDetail> cols = fileSource.getColumnDetail();
			Map<String, ColumnDto> map = new HashMap<String, ColumnDto>();
			for (ColumnDto cd : dto.getColumns()) {
				map.put(cd.getName(), cd);
			}

			for (ColumnDetail col : cols) {
				ColumnDto cd = map.remove(col.getName());
				if (cd != null) {
					col.setDataType(cd.getDataType());
					col.setLength(cd.getLength());
					col.setPos(cd.getPos());
					col.setSensitiveFlag(cd.getSensitiveFlag());
				} else {
					col.setDbSource(null);
					col.setFileSource(null);
				}
			}

			for (Entry<String, ColumnDto> e : map.entrySet()) {
				ColumnDto cc = e.getValue();
				ColumnDetail cd = new ColumnDetail();
				cd.setDataType(cc.getDataType());
				cd.setFileSource(fileSource);
				cd.setLength(cc.getLength());
				cd.setName(cc.getName());
				cd.setPos(cc.getPos());
				cd.setSensitiveFlag(cc.getSensitiveFlag());
				cols.add(cd);
			}
		}

		fileSource.setDelimiter(dto.getDelimiter());
		fileSource.setDescription(dto.getDescription());

		if (dto.getId() <= 0) {
			id = this.mdmDao.saveFileSource(fileSource);
		} else {
			id = dto.getId();
		}

		logger.debug("Exiting saveFileSource");
		return id;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveSourceSystem(SourceSystemDto dto) {
		logger.debug("Entered saveSourceSystem");

		SourceSystem sourceSystem = null;
		long id = -1;
		if (dto.getId() <= 0) {
			sourceSystem = new SourceSystem();
		} else {
			sourceSystem = this.mdmDao.getSourceSystem(dto.getId());
			id = sourceSystem.getId();
		}

		sourceSystem.setApprover(dto.getApprover());
		sourceSystem.setBusinessName(dto.getBusinessName());
		sourceSystem.setDescription(dto.getDescription());
		sourceSystem.setOwner(dto.getOwner());
		sourceSystem.setProjectId(dto.getProjectId());
		sourceSystem.setPurpose(dto.getPurpose());
		sourceSystem.setStatus(dto.getStatus());
		sourceSystem.setTechnicalName(dto.getTechnicalName());

		if (dto.getId() <= 0) {
			id = this.mdmDao.saveSourceSystem(sourceSystem);
		}

		logger.debug("Exiting saveSourceSystem");

		return id;
	}

	public String addDBSources(List<DBSourceDto> lstDbSource) {
		logger.debug("Entered addDBSources");

		logger.debug("Exiting addDBSources");
		return MessageUtils.getResponseMessage("SUCCESS", "DB Sources added");
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveDBSources(DBSourceSystem dbSourceSystem) {
		logger.debug("Entered saveDBSources");
		long ssId = dbSourceSystem.getSourceSystem();

		SourceSystem sourceSystem = this.mdmDao.getSourceSystem(ssId);

		ServiceUtils.populateDBSourceList(dbSourceSystem.getTables(), sourceSystem);

		logger.debug("Exiting saveDBSources");

		return sourceSystem.getId();
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveFileSources(FileSourceSystem fileSourceSystem) {
		logger.debug("Entered saveFileSources");
		long ssId = fileSourceSystem.getSourceSystem();
		SourceSystem sourceSystem = this.mdmDao.getSourceSystem(ssId);

		ServiceUtils.populateFileSourceList(fileSourceSystem.getFiles(), sourceSystem);
		logger.debug("Exiting saveFileSources");

		return sourceSystem.getId();
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public String addFileSources(List<FileSourceDto> lstFileSource) {
		logger.debug("Entered addFileSources");

		logger.debug("Exiting addFileSources");
		return MessageUtils.getResponseMessage("SUCCESS", "File Sources added");
	}

	@Override
	@Transactional(value = TxType.SUPPORTS)
	public String getTableStruct(long ssId) {
		logger.debug("Entered getTableStruct");
		SourceSystem ss = this.mdmDao.getSourceSystem(ssId);

		Set<DBSource> tbls = ss.getDbSources();

		logger.debug("Exiting getTableStruct");

		return null;
	}

	@Override
	public String importFileStruct(long ssId, String excelPath) {
		logger.debug("Entered importFileStruct");
		String resp = null;
		ExcelService excelService = new ExcelService();
		try {
			List<FileSourceDto> list = excelService.getFileSourceFromExcel(ssId, excelPath);
			resp = MessageUtils.getResponseMessage("SUCCESS", JSONUtils.getFileJSON(list));
		} catch (Exception e) {
		}

		if (resp == null) {
			resp = MessageUtils.getResponseMessage("ERROR", "Error Parsing file source from Excel");
		}
		logger.debug("Exiting importFileStruct");
		return resp;
	}
}
