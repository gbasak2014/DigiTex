package com.mdm.gb.common;

import org.json.JSONObject;

public class MessageUtils {
	public static String getResponseMessage(String status, Object data) {
		JSONObject obj = new JSONObject();
		obj.put("status", status);
		obj.put("data", data);

		return obj.toString();
	}
}
