package com.mdm.gb.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.mdm.gb.common.dto.ColumnDto;
import com.mdm.gb.common.dto.DBSourceDto;
import com.mdm.gb.common.dto.FileSourceDto;
import com.mdm.gb.common.entity.ColumnDetail;
import com.mdm.gb.common.entity.DBSource;
import com.mdm.gb.common.entity.FileSource;
import com.mdm.gb.common.entity.SourceSystem;

public class ServiceUtils {
	static final Logger logger = Logger.getLogger(ServiceUtils.class);

	public static Set<ColumnDetail> getColumnList(Collection<ColumnDto> cols, DBSource dbSource) {
		logger.debug("Entered getColumnList");
		Set<ColumnDetail> set = new HashSet<ColumnDetail>();

		for (ColumnDto cd : cols) {
			ColumnDetail col = new ColumnDetail();
			col.setDataType(cd.getDataType());
			col.setDbSource(dbSource);
			col.setLength(cd.getLength());
			col.setName(cd.getName());
			col.setPos(cd.getPos());
			col.setSensitiveFlag(cd.getSensitiveFlag());
			set.add(col);
		}
		logger.debug("Exiting getColumnList");
		return set;
	}

	public static Set<ColumnDetail> getColumnList(Collection<ColumnDto> cols, FileSource fileSource) {
		logger.debug("Entered getColumnList");
		Set<ColumnDetail> set = new HashSet<ColumnDetail>();

		for (ColumnDto cd : cols) {
			ColumnDetail col = new ColumnDetail();
			col.setDataType(cd.getDataType());
			col.setFileSource(fileSource);
			col.setLength(cd.getLength());
			col.setName(cd.getName());
			col.setPos(cd.getPos());
			col.setSensitiveFlag(cd.getSensitiveFlag());
			set.add(col);
		}
		logger.debug("Exiting getColumnList");
		return set;
	}

	static void updateDBSrc(DBSource tbl, DBSourceDto dto, SourceSystem sourceSystem) {
		logger.debug("Entered updateDBSrc");
		tbl.setDb(dto.getDb());
		tbl.setDescription(dto.getDescription());
		tbl.setHost(dto.getHost());
		tbl.setPassword(dto.getPassword());
		tbl.setSourceSystem(sourceSystem);
		tbl.setStatus(dto.getStatus());
		tbl.setTableName(dto.getTableName());
		tbl.setType(dto.getType());
		tbl.setUser(dto.getUser());

		Set<ColumnDetail> cols = tbl.getColumnDetail();
		if (cols == null) {
			cols = new HashSet<ColumnDetail>();
			tbl.setColumnDetail(cols);
		}

		List<ColumnDetail> tmpCols = new ArrayList<ColumnDetail>(cols);
		Map<String, ColumnDto> map = new HashMap<String, ColumnDto>();
		for (ColumnDto cd : dto.getColumns()) {
			map.put(cd.getName(), cd);
		}

		for (ColumnDetail col : tmpCols) {
			if (map.containsKey(col.getName())) {
				ColumnDto cd = map.remove(col.getName());
				col.setDbSource(tbl);
				updateColumn(col, cd);
			} else {
				cols.remove(col);
				col.setDbSource(null);
				col.setFileSource(null);
			}
		}

		for (ColumnDto cd : map.values()) {
			ColumnDetail col = new ColumnDetail();
			col.setDbSource(tbl);
			updateColumn(col, cd);
			cols.add(col);
		}

		logger.debug("Exiting updateDBSrc");
	}

	static void updateFileSrc(FileSource fs, FileSourceDto dto, SourceSystem sourceSystem) {
		logger.debug("Entered updateFileSrc");
		fs.setDelimiter(dto.getDelimiter());
		fs.setDescription(dto.getDescription());
		fs.setFormat(dto.getFileFormat());
		fs.setName(dto.getName());
		fs.setPath(dto.getPath());
		fs.setRootElement(dto.getRootElement());
		fs.setSourceSystem(sourceSystem);

		Set<ColumnDetail> cols = fs.getColumnDetail();
		if (cols == null) {
			cols = new HashSet<ColumnDetail>();
			fs.setColumnDetail(cols);
		}

		List<ColumnDetail> tmpCols = new ArrayList<ColumnDetail>(cols);
		Map<String, ColumnDto> map = new HashMap<String, ColumnDto>();
		for (ColumnDto cd : dto.getColumns()) {
			map.put(cd.getName(), cd);
		}

		for (ColumnDetail col : tmpCols) {
			if (map.containsKey(col.getName())) {
				ColumnDto cd = map.remove(col.getName());
				col.setFileSource(fs);
				updateColumn(col, cd);
			} else {
				cols.remove(col);
				col.setDbSource(null);
				col.setFileSource(null);
			}
		}

		for (ColumnDto cd : map.values()) {
			ColumnDetail col = new ColumnDetail();
			col.setFileSource(fs);
			updateColumn(col, cd);
			cols.add(col);
		}

		logger.debug("Exiting updateFileSrc");
	}

	static void updateColumn(ColumnDetail col, ColumnDto dto) {
		logger.debug("Entered updateColumn");
		col.setDataType(dto.getDataType());
		col.setLength(dto.getLength());
		col.setName(dto.getName());
		col.setPos(dto.getPos());
		col.setSensitiveFlag(dto.getSensitiveFlag());
		logger.debug("Exiting updateColumn");
	}

	public static void populateDBSourceList(List<DBSourceDto> list, SourceSystem sourceSystem) {
		logger.debug("Entered populateDBSourceList");
		Set<DBSource> set = sourceSystem.getDbSources();
		if (set == null) {
			set = new HashSet<DBSource>();
			sourceSystem.setDbSources(set);
		}

		List<DBSource> tmpTbls = new ArrayList<>(set);
		Map<String, DBSourceDto> map = new HashMap<String, DBSourceDto>();
		for (DBSourceDto dto : list) {
			map.put(dto.getTableName(), dto);
		}

		for (DBSource tbl : tmpTbls) {
			if (map.containsKey(tbl.getTableName())) {
				DBSourceDto dto = map.remove(tbl.getTableName());
				updateDBSrc(tbl, dto, sourceSystem);
			} else {
				set.remove(tbl);
				tbl.setSourceSystem(null);
				tbl.setColumnDetail(null);
			}

		}

		for (DBSourceDto dto : map.values()) {
			DBSource tbl = new DBSource();
			updateDBSrc(tbl, dto, sourceSystem);
			set.add(tbl);
		}
		logger.debug("Exiting populateDBSourceList");
	}

	public static void populateFileSourceList(List<FileSourceDto> list, SourceSystem sourceSystem) {
		logger.debug("Entered populateFileSourceList");
		Set<FileSource> set = sourceSystem.getFileSources();
		if (set == null) {
			set = new HashSet<FileSource>();
			sourceSystem.setFileSources(set);
		}

		List<FileSource> tmpfiles = new ArrayList<FileSource>(set);
		Map<String, FileSourceDto> map = new HashMap<String, FileSourceDto>();
		for (FileSourceDto dto : list) {
			map.put(dto.getName(), dto);
		}

		for (FileSource fs : tmpfiles) {
			if (map.containsKey(fs.getName())) {
				FileSourceDto dto = map.get(fs.getName());
				updateFileSrc(fs, dto, sourceSystem);
			} else {
				set.remove(fs);
				fs.setSourceSystem(null);
				fs.setColumnDetail(null);
			}
		}

		for (FileSourceDto dto : map.values()) {
			FileSource fs = new FileSource();
			updateFileSrc(fs, dto, sourceSystem);
			set.add(fs);
		}

		logger.debug("Exiting populateFileSourceList");

	}
}
