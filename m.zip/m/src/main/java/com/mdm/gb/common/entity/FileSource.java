package com.mdm.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.Version;

@Entity
@Table(name = "SOURCE_FILE", uniqueConstraints = @UniqueConstraint(columnNames = { "name", "SS_ID" }))
public class FileSource {
	@Id
	@Column(name = "FILE_SRC_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	long id;

	String name;
	String description;
	String path;
	String delimiter;
	String rootElement;
	String status;
	String format;

	@Version
	@Column(name = "VERSION")
	long version;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "fileSource", orphanRemoval = true)
	Set<ColumnDetail> columnDetail;

	@ManyToOne
	@JoinColumn(name = "SS_ID")
	SourceSystem sourceSystem;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getRootElement() {
		return rootElement;
	}

	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}

	public SourceSystem getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(SourceSystem sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public long getId() {
		return id;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Set<ColumnDetail> getColumnDetail() {
		return columnDetail;
	}

	public void setColumnDetail(Set<ColumnDetail> columnDetail) {
		this.columnDetail = columnDetail;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	@Override
	public String toString() {
		return "{" + this.name + ", " + this.columnDetail + "}";
	}
}
