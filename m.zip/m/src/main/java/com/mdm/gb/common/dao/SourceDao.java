package com.mdm.gb.common.dao;

import java.util.List;
import java.util.Map;

import com.mdm.gb.common.dto.ColumnDto;
import com.mdm.gb.common.dto.TableCat;

/**
 * DAO to extract meta data from source databases
 * 
 * @author Gouranga
 *
 */
public interface SourceDao {
	/**
	 * Get list of table name from the specified database
	 * 
	 * @param host
	 * @param db
	 * @param user
	 * @param pwd
	 * @return
	 * @throws Exception
	 */
	List<TableCat> listTables(String host, String db, String user, String pwd) throws Exception;

	/**
	 * Get table structure of table from source database
	 * 
	 * @param host
	 * @param db
	 * @param table
	 * @param user
	 * @param pwd
	 * @return
	 * @throws Exception
	 */
	List<ColumnDto> getTableStructure(String host, String db, String table, String user, String pwd) throws Exception;

	/**
	 * Get all tables and it's structure from source database
	 * 
	 * @param host
	 * @param db
	 * @param user
	 * @param pwd
	 * @return
	 * @throws Exception
	 */
	Map<String, List<ColumnDto>> getAlltableStructure(String host, String db, String user, String pwd) throws Exception;

}
