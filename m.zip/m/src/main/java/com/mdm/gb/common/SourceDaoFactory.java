package com.mdm.gb.common;

import com.mdm.gb.common.dao.MySqlSourceDaoImpl;
import com.mdm.gb.common.dao.SourceDao;

public class SourceDaoFactory {
	public static SourceDao getDaoImpl(String db)
	{
		if ("MYSQL".equalsIgnoreCase(db))
		{
			return new MySqlSourceDaoImpl();
		}
		
		return new MySqlSourceDaoImpl();
	}
}
