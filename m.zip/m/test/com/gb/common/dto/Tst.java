package com.gb.common.dto;

import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

public class Tst {

	public static void main(String[] args) {

		System.out.println("aaaaaaaaaaaaaaaaaa111111111111...........");
		String json = JSONReq.getRequest();
		JSONParser jp = new JSONParser();
		JSONObject jo = new JSONObject(json);
		
		
		
		System.out.println(jo.get("end"));
		
	}

}
