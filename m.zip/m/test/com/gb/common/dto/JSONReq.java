package com.gb.common.dto;

public class JSONReq {
	public static String getRequest()
	{
		return "{  " +
				"   \"start\":{  " +
				"      \"name\":\"StartWorkflow\"," +
				"      \"componentType\":0," +
				"      \"successors\":[  " +
				"         \"srcRDBMS\"," +
				"         \"srcHive\"," +
				"         \"srcHDFS\"," +
				"         \"srcLOCAL\"," +
				"         \"srcHBASE\"," +
				"         \"srcFLUME\"," +
				"         \"srcKAFKA\"," +
				"         \"srcSTREAMFILE\"" +
				"      ]" +
				"   }," +
				"   \"srcLOCAL\":{  " +
				"      \"name\":\"srcLOCAL\"," +
				"      \"componentType\":12," +
				"      \"fields\":[  " +
				"         \"XX\"," +
				"         \"YY\"," +
				"         \"ZZ\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Join1\"" +
				"      ]," +
				"      \"sourcePath\":\"/xx/yy\"," +
				"      \"fileType\":\"XML\"," +
				"      \"delimiter\":\"EMP\"," +
				"      \"deleteSource\":\"true\"," +
				"      \"renameSource\":\"false\"," +
				"      \"renameSuffix\":\"\"" +
				"   }," +
				"   \"srcHDFS\":{  " +
				"      \"name\":\"srcHDFS\"," +
				"      \"componentType\":11," +
				"      \"fields\":[  " +
				"         \"AA\"," +
				"         \"BB\"," +
				"         \"CC\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Join1\"" +
				"      ]," +
				"      \"sourcePath\":\"/a/a/a$YYYY$MM$DD$HH\"," +
				"      \"fileType\":\"JSON\"," +
				"      \"delimiter\":\"\"," +
				"      \"deleteSource\":\"false\"," +
				"      \"renameSource\":\"true\"," +
				"      \"renameSuffix\":\"DONE\"" +
				"   }," +
				"   \"srcHive\":{  " +
				"      \"name\":\"srcHive\"," +
				"      \"componentType\":13," +
				"      \"fields\":[  " +
				"         \"HEID\"," +
				"         \"HNAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"filter2\"" +
				"      ]," +
				"      \"schema\":\"HSCM\"," +
				"      \"table\":\"HEMP\"" +
				"   }," +
				"   \"srcRDBMS\":{  " +
				"      \"name\":\"srcRDBMS\"," +
				"      \"componentType\":14," +
				"      \"fields\":[  " +
				"         \"EID\"," +
				"         \"NAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"filter1\"" +
				"      ]" +
				"   }," +
				"   \"srcHBASE\":{  " +
				"      \"name\":\"srcHBASE\"," +
				"      \"componentType\":15," +
				"      \"fields\":[  " +
				"         \"AA#CC1\"," +
				"         \"AA#CC2\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Join2\"" +
				"      ]" +
				"   }," +
				"   \"srcFLUME\":{  " +
				"      \"name\":\"srcFLUME\"," +
				"      \"componentType\":20," +
				"      \"fields\":[  " +
				"         \"AA\"," +
				"         \"BB\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Join2\"" +
				"      ]," +
				"      \"host\":\"F_HOST\"," +
				"      \"port\":9999," +
				"      \"interval\":1," +
				"      \"recordType\":\"JSON\"," +
				"      \"delimiter\":\",\"" +
				"   }," +
				"   \"srcKAFKA\":{  " +
				"      \"name\":\"srcKAFKA\"," +
				"      \"componentType\":17," +
				"      \"fields\":[  " +
				"         \"aa\"," +
				"         \"bb\"," +
				"         \"cc\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Join3\"" +
				"      ]," +
				"      \"brokers\":\"BRKR\"," +
				"      \"topics\":\"TPC\"," +
				"      \"interval\":1," +
				"      \"recordType\":\"JSON\"," +
				"      \"delimiter\":\"\"" +
				"   }," +
				"   \"srcSTREAMFILE\":{  " +
				"      \"name\":\"srcSTREAMFILE\"," +
				"      \"componentType\":19," +
				"      \"fields\":[  " +
				"         \"a\"," +
				"         \"b\"," +
				"         \"d\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"StartWorkflow\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Join3\"" +
				"      ]," +
				"      \"path\":\"/xxx/yyy\"," +
				"      \"recordType\":\"Delimited\"," +
				"      \"delimiter\":\"#\"," +
				"      \"interval\":0" +
				"   }," +
				"   \"filter1\":{  " +
				"      \"name\":\"filter1\"," +
				"      \"componentType\":102," +
				"      \"fields\":[  " +
				"         \"EID\"," +
				"         \"NAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"srcRDBMS\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Target_delimitted\"" +
				"      ]," +
				"      \"condition\":[  " +
				"         {  " +
				"            \"column\":\"NAME\"," +
				"            \"condition\":\"Contain\"," +
				"            \"value\":\"AA\"," +
				"            \"type\":\"none\"" +
				"         }," +
				"         {  " +
				"            \"column\":\"EID\"," +
				"            \"condition\":\"Greater Than\"," +
				"            \"value\":\"111\"," +
				"            \"type\":\"AND\"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"filter2\":{  " +
				"      \"name\":\"filter2\"," +
				"      \"componentType\":102," +
				"      \"fields\":[  " +
				"         \"HEID\"," +
				"         \"HNAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"srcHive\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"EndWorkflow\"" +
				"      ]," +
				"      \"condition\":[  " +
				"         {  " +
				"            \"column\":\"HEID\"," +
				"            \"condition\":\"Start With\"," +
				"            \"value\":\"E0\"," +
				"            \"type\":\"none\"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"Join1\":{  " +
				"      \"name\":\"Join1\"," +
				"      \"componentType\":104," +
				"      \"fields\":[  " +
				"         \"srcHDFS_AA\"," +
				"         \"srcHDFS_BB\"," +
				"         \"srcHDFS_CC\"," +
				"         \"srcLOCAL_XX\"," +
				"         \"srcLOCAL_YY\"," +
				"         \"srcLOCAL_ZZ\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"srcHDFS\"," +
				"         \"srcLOCAL\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"transformation1\"" +
				"      ]," +
				"      \"transformations\":[  " +
				"         {  " +
				"            \"index\":0," +
				"            \"transform\":\"srcHDFS.AA\"," +
				"            \"targetField\":\"srcHDFS_AA\"" +
				"         }," +
				"         {  " +
				"            \"index\":1," +
				"            \"transform\":\"srcHDFS.BB\"," +
				"            \"targetField\":\"srcHDFS_BB\"" +
				"         }," +
				"         {  " +
				"            \"index\":2," +
				"            \"transform\":\"srcHDFS.CC\"," +
				"            \"targetField\":\"srcHDFS_CC\"" +
				"         }," +
				"         {  " +
				"            \"index\":3," +
				"            \"transform\":\"srcLOCAL.XX\"," +
				"            \"targetField\":\"srcLOCAL_XX\"" +
				"         }," +
				"         {  " +
				"            \"index\":4," +
				"            \"transform\":\"srcLOCAL.YY\"," +
				"            \"targetField\":\"srcLOCAL_YY\"" +
				"         }," +
				"         {  " +
				"            \"index\":5," +
				"            \"transform\":\"srcLOCAL.ZZ\"," +
				"            \"targetField\":\"srcLOCAL_ZZ\"" +
				"         }" +
				"      ]," +
				"      \"join\":[  " +
				"         {  " +
				"            \"leftSchema\":\"srcHDFS\"," +
				"            \"rightSchema\":\"srcLOCAL\"," +
				"            \"leftColumn\":\"AA\"," +
				"            \"rightColumn\":\"XX\"," +
				"            \"joinType\":\"INNER JOIN\"," +
				"            \"joinCondition\":\" = \"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"Join3\":{  " +
				"      \"name\":\"Join3\"," +
				"      \"componentType\":104," +
				"      \"fields\":[  " +
				"         \"srcKAFKA_aa\"," +
				"         \"srcKAFKA_bb\"," +
				"         \"srcKAFKA_cc\"," +
				"         \"srcSTREAMFILE_a\"," +
				"         \"srcSTREAMFILE_b\"," +
				"         \"srcSTREAMFILE_d\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"srcKAFKA\"," +
				"         \"srcSTREAMFILE\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"EndWorkflow\"" +
				"      ]," +
				"      \"transformations\":[  " +
				"         {  " +
				"            \"index\":0," +
				"            \"transform\":\"srcKAFKA.aa\"," +
				"            \"targetField\":\"srcKAFKA_aa\"" +
				"         }," +
				"         {  " +
				"            \"index\":1," +
				"            \"transform\":\"srcKAFKA.bb\"," +
				"            \"targetField\":\"srcKAFKA_bb\"" +
				"         }," +
				"         {  " +
				"            \"index\":2," +
				"            \"transform\":\"srcKAFKA.cc\"," +
				"            \"targetField\":\"srcKAFKA_cc\"" +
				"         }," +
				"         {  " +
				"            \"index\":3," +
				"            \"transform\":\"srcSTREAMFILE.a\"," +
				"            \"targetField\":\"srcSTREAMFILE_a\"" +
				"         }," +
				"         {  " +
				"            \"index\":4," +
				"            \"transform\":\"srcSTREAMFILE.b\"," +
				"            \"targetField\":\"srcSTREAMFILE_b\"" +
				"         }," +
				"         {  " +
				"            \"index\":5," +
				"            \"transform\":\"srcSTREAMFILE.d\"," +
				"            \"targetField\":\"srcSTREAMFILE_d\"" +
				"         }" +
				"      ]," +
				"      \"join\":[  " +
				"         {  " +
				"            \"leftSchema\":\"srcKAFKA\"," +
				"            \"rightSchema\":\"srcSTREAMFILE\"," +
				"            \"leftColumn\":\"aa\"," +
				"            \"rightColumn\":\"a\"," +
				"            \"joinType\":\"LEFT OUTER JOIN\"," +
				"            \"joinCondition\":\" = \"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"Join2\":{  " +
				"      \"name\":\"Join2\"," +
				"      \"componentType\":104," +
				"      \"fields\":[  " +
				"         \"srcHBASE_AA#CC1\"," +
				"         \"srcHBASE_AA#CC2\"," +
				"         \"srcFLUME_AA\"," +
				"         \"srcFLUME_BB\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"srcHBASE\"," +
				"         \"srcFLUME\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"srt1\"" +
				"      ]," +
				"      \"transformations\":[  " +
				"         {  " +
				"            \"index\":0," +
				"            \"transform\":\"srcHBASE.AA#CC1\"," +
				"            \"targetField\":\"srcHBASE_AA#CC1\"" +
				"         }," +
				"         {  " +
				"            \"index\":1," +
				"            \"transform\":\"srcHBASE.AA#CC2\"," +
				"            \"targetField\":\"srcHBASE_AA#CC2\"" +
				"         }," +
				"         {  " +
				"            \"index\":2," +
				"            \"transform\":\"srcFLUME.AA\"," +
				"            \"targetField\":\"srcFLUME_AA\"" +
				"         }," +
				"         {  " +
				"            \"index\":3," +
				"            \"transform\":\"srcFLUME.BB\"," +
				"            \"targetField\":\"srcFLUME_BB\"" +
				"         }" +
				"      ]," +
				"      \"join\":[  " +
				"         {  " +
				"            \"leftSchema\":\"srcHBASE\"," +
				"            \"rightSchema\":\"srcFLUME\"," +
				"            \"leftColumn\":\"AA#CC1\"," +
				"            \"rightColumn\":\"AA\"," +
				"            \"joinType\":\"INNER JOIN\"," +
				"            \"joinCondition\":\" = \"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"transformation1\":{  " +
				"      \"name\":\"transformation1\"," +
				"      \"componentType\":101," +
				"      \"fields\":[  " +
				"         \"FULL_NAME\"," +
				"         \"DATE\"," +
				"         \"srcLOCAL_YY\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"Join1\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"Group1\"" +
				"      ]," +
				"      \"transformations\":[  " +
				"         {  " +
				"            \"index\":0," +
				"            \"transform\":\"Concat($srcHDFS_AA, $srcHDFS_BB)\"," +
				"            \"targetField\":\"FULL_NAME\"" +
				"         }," +
				"         {  " +
				"            \"index\":1," +
				"            \"transform\":\"FORMAT($srcHDFS_CC, yyyyMMdd\"," +
				"            \"targetField\":\"DATE\"" +
				"         }," +
				"         {  " +
				"            \"index\":2," +
				"            \"transform\":\"srcLOCAL_YY\"," +
				"            \"targetField\":\"srcLOCAL_YY\"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"Group1\":{  " +
				"      \"name\":\"Group1\"," +
				"      \"componentType\":103," +
				"      \"fields\":[  " +
				"         \"DT_CNT\"," +
				"         \"FULL_NAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"transformation1\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"SourceJSON\"" +
				"      ]," +
				"      \"groupByColumns\":\"FULL_NAME\"," +
				"      \"transformations\":[  " +
				"         {  " +
				"            \"index\":0," +
				"            \"transform\":\"COUNT($DATE)\"," +
				"            \"targetField\":\"DT_CNT\"" +
				"         }," +
				"         {  " +
				"            \"index\":1," +
				"            \"transform\":\"FULL_NAME\"," +
				"            \"targetField\":\"FULL_NAME\"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"srt1\":{  " +
				"      \"name\":\"srt1\"," +
				"      \"componentType\":106," +
				"      \"fields\":[  " +
				"         \"srcHBASE_AA#CC1\"," +
				"         \"srcHBASE_AA#CC2\"," +
				"         \"srcFLUME_AA\"," +
				"         \"srcFLUME_BB\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"Join2\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"SourceJSON\"" +
				"      ]," +
				"      \"orderBy\":[  " +
				"         {  " +
				"            \"column\":\"srcHBASE_AA#CC1\"," +
				"            \"order\":\"ASC\"" +
				"         }," +
				"         {  " +
				"            \"column\":\"srcHBASE_AA#CC2\"," +
				"            \"order\":\"ASC\"" +
				"         }" +
				"      ]" +
				"   }," +
				"   \"SourceJSON\":{  " +
				"      \"name\":\"SourceJSON\"," +
				"      \"componentType\":206," +
				"	  \"path\":\"/aaa/bbb/\"," +
				"      \"fields\":[  " +
				"         \"DT_CNT\"," +
				"         \"FULL_NAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"Group1\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"EndWorkflow\"" +
				"      ]," +
				"      \"root\":\"RT\"" +
				"   }," +
				"   \"Target_delimitted\":{  " +
				"      \"name\":\"Target_delimitted\"," +
				"      \"componentType\":207," +
				"      \"fields\":[  " +
				"         \"EID\"," +
				"         \"NAME\"" +
				"      ]," +
				"      \"predecessor\":[  " +
				"         \"filter1\"" +
				"      ]," +
				"      \"successors\":[  " +
				"         \"EndWorkflow\"" +
				"      ]," +
				"      \"delim\":\"##\"" +
				"   }," +
				"   \"end\":{  " +
				"      \"name\":\"EndWorkflow\"," +
				"      \"componentType\":1," +
				"      \"predecessors\":[  " +
				"         \"Target_delimitted\"," +
				"         \"filter2\"," +
				"         \"SourceJSON\"," +
				"         \"SourceJSON\"," +
				"         \"Join3\"" +
				"      ]" +
				"   }" +
				"}";
	}
}
